# cproject —— 由 AutoShop 工程重建的 C 工程（可编译、可单步）

> **自动生成，请勿手改**：由 `tools/il2c.py` + `tools/il2c_project.py` + `tools/st2c.py`
> 依据 `artifacts/`（AutoShop 编译输出 IL、变量表、提取出的 ST 源码）生成。
> 统计：程序 35 个、功能块 11 个、FB 实例 65 个、变量 972 个、ST 块 3 个、未翻译条目 0 条。

## 1. 它解决什么问题

梯形图和 IL 都不便于"跨功能跳转阅读"。这里把**每个子程序/FB 变成 C 函数**、
**每个工程变量变成 C 变量**，于是 VS Code 里可以：

| 操作 | 用途 |
|---|---|
| `F12` / `Shift+F12` | 跳转到定义 / 查所有引用 —— **读"谁改了这个变量"最快的方式** |
| `Ctrl+Shift+O` | 文件大纲（一个程序 = 一个函数） |
| `Ctrl+Shift+F` | 全工程搜索变量名（如 `g_x撕膜位OK料`） |
| 断点 + 单步 | `make && ./plc_sim` 后逐周期观察逻辑 |

## 2. 目录

```
cproject/
├─ include/
│   ├─ plc.h          语义层：类型、边沿 RE/FE、定时器 TON/TACC、位打包、轴结构
│   ├─ symbols.h      工程变量 → C 变量（含原地址注释）
│   ├─ enums.h        工程枚举（project/UpLoad/*.enum）
│   ├─ fb.h           FB 结构体 + 调用原型（引脚 = 指针形参）
│   └─ fb_instances.h 64 个 FB 实例（36 个气缸、10 条皮带、5 台电缸、设备状态机…）
├─ src/
│   ├─ plc_scan.c     plc_scan()/plc_init()：按 MAIN 的调用顺序执行子程序（文件名避开 MAIN.c）
│   ├─ <程序名>.c      每个 LD 子程序一个函数
│   ├─ <FB名>.c       每个功能块一个函数（实例共用一份体）
│   ├─ st_blocks.c    ST 块（_STB101/_STB102/_STB87）逐行译成 C，保留 ST 原文注释
│   ├─ fb_instances.c / symbols.c / plc_helpers.c / library_shims.c
├─ sim/              仿真侧（非 PLC 逻辑）：扫描循环 + 机械/轴替身
└─ Makefile
```

## 3. 编译运行

```bash
# 便携工具链（本机已就绪）：
#   C:\Users\<你>\AppData\Local\Temp\toolchain\w64devkit\bin\gcc.exe
cd cproject
mingw32-make            # 或 make
./plc_sim 5000          # 5000 个扫描周期，默认 1ms/周期
```

## 4. 阅读约定（与 AutoShop 对照）

| 生成代码 | 原工程 |
|---|---|
| `void SBR_02自动撕膜机构(void)` | 子程序 `SBR_02自动撕膜机构.LD` |
| `气缸_FB_t 撕膜位阻挡气缸;` + `气缸_FB_call(&…, …)` | FB 实例（图纸化引脚绑定） |
| 指针形参 `plc_bit *原位感应` | FB 引脚：绑定了外部变量就指向外部变量，`-` 则指向实例成员 |
| `if (条件) { … }` | 一个网络（rung） |
| `/* IL:6403 CALL_FB … */` | 网络对应的 IL 原文（可在 `artifacts/il/` 定位） |
| `RE(e1,x)` / `FE(e1,x)` | 上升沿/下降沿触点（`LDP/ANDP`、`LDF/ANDF`、`MEP/MEF`） |
| `TON(&q,&et,K800,cond,0,dt_ms)` / `TACC` | `TONR`（消抖/超时）/ `TACR`（累计） |
| `PACK_BITS/UNPACK_BITS`、`BLKMOV/FILL/WSHIFT` | `BITW/WBIT`、`BMOV/FMOV/WSFL` |
| `MC_*` `TCP_*` `ETC_*` | 外部耦合指令 → `library_shims.c` |

## 5. 类型推断（重要）

变量类型由**两处证据**推断，代码里全部可追溯：

1. `artifacts/text/VarNameAndAddr.csv.txt` 的**字节长度**（已用相邻变量地址差验证：
   如 `HMI_轴1定位位置`=800B，下一变量地址差正好 0x320）；
2. 该符号在 IL 里的**使用方式**（`OUT/SET/…` → 位；`MOV/ADD` → 16 位；`DMOV/DADD` → 32 位；`DEMOV/FLT` → 浮点）。
   - 位软元件在该 PLC 的地址空间里**占 1 字节/位**（`g_x轴不在暂停位` 长度=1B 可证）。

因此 `symbols.h` 里的类型是"可编译 + 可读"的近似；**若要与原工程逐位一致，以 `artifacts/text/VarNameAndAddr.csv.txt` 为准**。

## 6. 保真度

| 部分 | 保真度 |
|---|---|
| 位逻辑、边沿、定时器、比较、数据运算、数组、位打包 | **逐指令还原**（可编译执行） |
| 功能块（含引脚绑定、实例存储） | **逐指令还原**，引脚按绑定语义以指针传递 |
| ST 块 `_STB101/_STB102/_STB87` | **译自工程内嵌的真实 ST 源码**（`artifacts/st/`），逐行附原文注释 |
| `MC_*`（运动控制） | 调用形态保留 + 最小可运行等效；轴运动由 `sim/` 积分 |
| `TCP_*`、`ETC_WRITEPARAMETER_COE` | 仅保留调用形态（协议栈不还原） |
| 未实例化的 6 个 FB（`FB_PID`/`FB_静置料仓`…）及其 ST（`_STB76/77/85/93/127/128`） | 未生成 C，但 **ST 源码已存 `artifacts/st/`** |

## 7. 已知偏差

- 定时器/边沿的静态状态按**调用点**保存，与原 PLC 一致；但 FB 内部的"局部变量"在本工程里译成
  `static`（跨实例共享）——已核对：仅 `FB_扫码检测旧码` 用到，且其值在单次调用内即被重置，**无可观测差异**；
- `SBR_A9_来料检测` 在原工程被 `LDI M8000` 旁路，仍照原样生成；
- 生成器无法翻译的指令会留 `/* TODO */` 注释并计入第 1 节统计（当前 0 条）。
