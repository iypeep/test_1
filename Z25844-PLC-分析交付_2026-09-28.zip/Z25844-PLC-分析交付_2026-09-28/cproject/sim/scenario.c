#include "sim.h"

/* 演示场景：把设备状态机推到"自动"，观察 撕膜位进料 的 工位状态字/流程推进。
   真实产线启动条件复杂得多，本函数只用于演示 C 工程可单步执行。 */
void sim_scenario(int cycle, void *ctx) {
    (void)ctx;
    if (cycle == 1) { 设备状态机.IB_手自动切换 = 1; 设备状态机.IB_启动按钮 = 1; }
    if (cycle == 3) { 设备状态机.IB_启动按钮 = 0; }
    if (cycle == 5) { HMI_自动中[0] = 1; }
}
