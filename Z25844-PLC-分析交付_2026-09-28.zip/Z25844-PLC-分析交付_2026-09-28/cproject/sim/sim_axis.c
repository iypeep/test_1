#include "sim.h"
#include <math.h>

/* 轴替身：使能后按 fSetPosition 积分位置，到位后置 PLCopen 状态字 bit10。
   真实工程里位置由 EtherCAT 伺服/电缸反馈，这里只是让逻辑跑起来。 */
void sim_axis_step(int32_t dt) {
    (void)dt;
    /* 下料Y轴伺服（下料Y轴 的轴对象） */
    if (下料Y轴伺服.wPLCOpenState & 0x0001) {
        double d = 下料Y轴伺服.fSetPosition - 下料Y轴伺服.fActPosition;
        if (fabs(d) > 0.5) { 下料Y轴伺服.fActPosition += (d > 0 ? 5.0 : -5.0); 下料Y轴伺服.wPLCOpenState &= (short)~0x0400; }
        else { 下料Y轴伺服.wPLCOpenState |= 0x0400; }
    }
}
