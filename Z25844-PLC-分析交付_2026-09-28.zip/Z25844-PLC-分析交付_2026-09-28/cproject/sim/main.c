#include "sim.h"
#include <stdio.h>
#include <stdlib.h>

/* 扫描循环：dt_ms 默认 1ms（与 AutoShop 工程的 TONR 时间基准一致）。 */
int main(int argc, char **argv) {
    long cycles = (argc > 1) ? atol(argv[1]) : 2000;
    dt_ms = (argc > 2) ? atoi(argv[2]) : 1;
    plc_init();
    for (long i = 0; i < cycles; i++) {
        M8011 = (plc_bit)((i % 10) < 5);      /* 10ms 时钟 */
        M8013 = (plc_bit)((i % 1000) < 500);  /* 1s 时钟 */
        sim_scenario(i, NULL);            /* 演示场景：推到"手动/自动"，观察工位状态字推进 */
        plc_scan();
        sim_machine_step(dt_ms);
        sim_axis_step(dt_ms);
    }
    sim_print_state();
    return 0;
}
