#pragma once
#include "fb.h"

/* ST 块原型（st_blocks.c 定义；被 FB/程序通过 EXECUTE 调用）。*/
void _STB87(FB_扫码检测旧码_t *self, int16_t *IF_新码, int16_t *IF_检查长度);
void _STB101(void);
void _STB102(void);
