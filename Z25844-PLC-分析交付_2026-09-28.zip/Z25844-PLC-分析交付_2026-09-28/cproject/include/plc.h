#pragma once
/* =========================================================================
 * plc.h —— PLC 语义层
 * 本 C 工程由 tools/il2c.py + il2c_project.py 从 AutoShop 工程的编译输出 IL 重建。
 * 目标：按扫描周期语义还原工程逻辑，使代码可读、可跳转、可单步调试。
 * 边界：EtherCAT/机器人/视觉/运动控制等外部耦合部分以库替身呈现（library_shims.c）。
 * ========================================================================= */
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

typedef uint8_t plc_bit;      /* 位软元件：X / Y / M / S / T / C … */
typedef int16_t plc_word;     /* 16 位字：D / W 区 */
typedef int32_t plc_dword;    /* 32 位双字 */

extern int32_t dt_ms;         /* 扫描周期(ms)，默认 1（与工程 TONR 时间基准一致） */

/* 边沿检测：每个调用点保存一份状态（等价于 PLC 的边沿触点） */
static inline plc_bit RE(plc_bit *state, plc_bit x) { plc_bit r = (plc_bit)(x && !*state); *state = x; return r; }
static inline plc_bit FE(plc_bit *state, plc_bit x) { plc_bit r = (plc_bit)(!x && *state); *state = x; return r; }

/* 定时器：PT 单位 ms（工程实测 K500 = 500ms）
 *   TON  = TONR：条件断开即复位（消抖/超时）
 *   TACC = TACR：条件断开保持累计（运行时间累计） */
void TON(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt);
void TACC(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt);

/* 数据/数组操作（MOV/BMOV/FMOV/WSFL/BITW/WBIT…） */
void BLKMOV(void *dst, void *src, int n);
void BLKMOV32(void *dst, void *src, int n);
void FILL(void *dst, int32_t v, int n);
void WSHIFT(void *dst, int n, int32_t v);
void STRCPY(void *dst, const char *src);
int  STRLEN(const void *src);
void WTODW(void *dw, void *w, int n);
int32_t PACK_BITS(void *bitbase, int n);
void UNPACK_BITS(void *bitbase, int32_t v, int n);
int32_t PACK_BITS32(void *bitbase, int n);
void UNPACK_BITS32(void *bitbase, int32_t v, int n);
void RTC_READ(void *dst);
void RTC_WRITE(void *src);
void PLS_(plc_bit *y);
void FILLB(void *dst, int v, int n);            /* 位数组填充 */
/* 除法：PLC 在除数为 0 时会报运算错误停机；C 侧为能连续单步，除零返回 0（见 cproject/README 偏差表） */
int16_t DIV16(int32_t a, int32_t b);
int32_t DIV32(int32_t a, int32_t b);
double  DIVF(double a, double b);
int16_t MOD16(int32_t a, int32_t b);
int32_t MOD32(int32_t a, int32_t b);
void FILL32(void *dst, int32_t v, int n);       /* 32 位数组填充 */

/* 字软元件的按位访问（AutoShop 里写作 D0.3 / etc控制字.9） */
#define BIT_R(w, n)      ((((int32_t)(w)) >> (n)) & 1)
#define BIT_SET(w, n)    ((w) = (plc_word)((w) | (1 << (n))))
#define BIT_CLR(w, n)    ((w) = (plc_word)((w) & ~(1 << (n))))
#define BIT_W(w, n, v)   ((v) ? BIT_SET(w, n) : BIT_CLR(w, n))

/* 外部耦合指令（library_shims.c 提供替身；真实执行在伺服/协议栈侧） */
void MC_POWER(void *a0, ...);
void MC_HOME(void *a0, ...);
void MC_JOG(void *a0, ...);
void MC_MOVEABSOLUTE(void *a0, ...);
void MC_MOVERELATIVE(void *a0, ...);
void MC_STOP(void *a0, ...);
void MC_RESET(void *a0, ...);
void MC_SETPOSITION(void *a0, ...);
void MC_READACTUALPOSITION(void *a0, ...);
void MC_READAXISERROR(void *a0, ...);
void MC_READDIGITALINPUT(void *a0, ...);
void TCP_CONNECT(void *a0, ...);
void TCP_SEND(void *a0, ...);
void TCP_RECEIVE(void *a0, ...);
void ETC_WRITEPARAMETER_COE(void *a0, ...);

/* 轴数据结构（原 Axis_FB 的 Axis 引脚，对应 CiA402 对象） */
typedef struct {
    double fActPosition;      /* 当前位置 0x6064 */
    double fSetPosition;      /* 目标位置 0x607A */
    plc_word wPLCOpenState;   /* PLCopen 状态字 */
} mca_axis_info_t;
