#pragma once

/* 自动生成：工程枚举（project/UpLoad/*.enum）。*/

#define 上相机X轴10 10   /* 上相机X轴10 */
#define 下料Y轴0 0   /* 下料Y轴0 */
#define 伺服轴13 13   /* 伺服轴13 */
#define 伺服轴14 14   /* 伺服轴14 */
#define 伺服轴15 15   /* 伺服轴15 */
#define 伺服轴16 16   /* 伺服轴16 */
#define 伺服轴17 17   /* 伺服轴17 */
#define 伺服轴18 18   /* 伺服轴18 */
#define 伺服轴19 19   /* 伺服轴19 */
#define 伺服轴20 20   /* 伺服轴20 */
#define 伺服轴21 21   /* 伺服轴21 */
#define 伺服轴22 22   /* 伺服轴22 */
#define 伺服轴23 23   /* 伺服轴23 */
#define 伺服轴24 24   /* 伺服轴24 */
#define 伺服轴25 25   /* 伺服轴25 */
#define 伺服轴26 26   /* 伺服轴26 */
#define 伺服轴27 27   /* 伺服轴27 */
#define 伺服轴28 28   /* 伺服轴28 */
#define 伺服轴29 29   /* 伺服轴29 */
#define 伺服轴30 30   /* 伺服轴30 */
#define 伺服轴31 31   /* 伺服轴31 */
#define 前R轴4 4   /* 前R轴4 */
#define 前Y1轴1 1   /* 前Y1轴1 */
#define 前Y2轴2 2   /* 前Y2轴2 */
#define 前Z轴3 3   /* 前Z轴3 */
#define 后R轴9 9   /* 后R轴9 */
#define 后X轴5 5   /* 后X轴5 */
#define 后Y1轴6 6   /* 后Y1轴6 */
#define 后Y2轴7 7   /* 后Y2轴7 */
#define 后Z轴8 8   /* 后Z轴8 */
#define 料仓AZ轴11 11   /* 料仓AZ轴11 */
#define 料仓BZ轴12 12   /* 料仓BZ轴12 */
