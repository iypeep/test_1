#pragma once
#include "fb.h"

/* 自动生成：FB 实例（来自各程序里的 CALL_FB）。*/

/* ==== Axis_FB：1 个 ==== */
extern Axis_FB_t 下料Y轴;
/* ==== ETC电缸：5 个 ==== */
extern ETC电缸_t FL右Y电缸;
extern ETC电缸_t FL右Z电缸;
extern ETC电缸_t FL左X电缸;
extern ETC电缸_t FL左Y电缸;
extern ETC电缸_t FL左Z电缸;
/* ==== FB_位置比较比较：1 个 ==== */
extern FB_位置比较比较_t FBI_001;
/* ==== FB_扫码检测旧码：2 个 ==== */
extern FB_扫码检测旧码_t 扫码枪1对比;
extern FB_扫码检测旧码_t 扫码枪2对比;
/* ==== FB_检测信号：1 个 ==== */
extern FB_检测信号_t 来料检测0;
/* ==== FB_门禁气源三色灯：1 个 ==== */
extern FB_门禁气源三色灯_t 门禁三色灯;
/* ==== IO皮带FB：10 个 ==== */
extern IO皮带FB_t AOI出料皮带;
extern IO皮带FB_t NG皮带电机;
extern IO皮带FB_t 下料皮带电机1;
extern IO皮带FB_t 下料皮带电机2;
extern IO皮带FB_t 下料皮带电机3;
extern IO皮带FB_t 下料皮带电机4;
extern IO皮带FB_t 撕膜皮带电机;
extern IO皮带FB_t 机器人1位皮带电机;
extern IO皮带FB_t 机器人2位皮带电机;
extern IO皮带FB_t 检测位皮带电机;
/* ==== 扫码枪FB：2 个 ==== */
extern 扫码枪FB_t 扫码枪1;
extern 扫码枪FB_t 扫码枪2;
/* ==== 气缸_FB：36 个 ==== */
extern 气缸_FB_t CCD检测位压合升降气缸;
extern 气缸_FB_t CCD检测位压合平移气缸;
extern 气缸_FB_t CCD检测位横向定位气缸;
extern 气缸_FB_t CCD检测位纵向定位气缸;
extern 气缸_FB_t CCD检测位阻挡气缸;
extern 气缸_FB_t CCD检测位顶升气缸;
extern 气缸_FB_t FL侧边光源平移气缸;
extern 气缸_FB_t FL夹紧气缸;
extern 气缸_FB_t 下料位横向定位气缸;
extern 气缸_FB_t 下料位阻挡气缸;
extern 气缸_FB_t 下料位顶升气缸;
extern 气缸_FB_t 下料机械手升降气缸;
extern 气缸_FB_t 下料机械手夹爪气缸;
extern 气缸_FB_t 撕膜位FPC夹膜气缸;
extern 气缸_FB_t 撕膜位FPC扶正升降气缸;
extern 气缸_FB_t 撕膜位FPC扶正平移气缸;
extern 气缸_FB_t 撕膜位FPC撕膜升降气缸;
extern 气缸_FB_t 撕膜位FPC撕膜平移气缸;
extern 气缸_FB_t 撕膜位横向定位气缸;
extern 气缸_FB_t 撕膜位纵向定位气缸;
extern 气缸_FB_t 撕膜位阻挡气缸;
extern 气缸_FB_t 撕膜位顶升气缸;
extern 气缸_FB_t 机器人1位抚平定位气缸;
extern 气缸_FB_t 机器人1位横向定位气缸;
extern 气缸_FB_t 机器人1位纵向定位气缸;
extern 气缸_FB_t 机器人1位阻挡气缸;
extern 气缸_FB_t 机器人1位顶升气缸;
extern 气缸_FB_t 机器人1爪手升降气缸;
extern 气缸_FB_t 机器人1爪手夹头气缸;
extern 气缸_FB_t 机器人2位抚平定位气缸;
extern 气缸_FB_t 机器人2位横向定位气缸;
extern 气缸_FB_t 机器人2位纵向定位气缸;
extern 气缸_FB_t 机器人2位阻挡气缸;
extern 气缸_FB_t 机器人2位顶升气缸;
extern 气缸_FB_t 机器人2爪手升降气缸;
extern 气缸_FB_t 机器人2爪手夹头气缸;
/* ==== 真空_FB：4 个 ==== */
extern 真空_FB_t 下料真空;
extern 真空_FB_t 废料真空;
extern 真空_FB_t 机器人1真空;
extern 真空_FB_t 机器人2真空;
/* ==== 设备状态：1 个 ==== */
extern 设备状态_t 设备状态机;
