#pragma once
#include "plc.h"

/* 自动生成：变量表里以【结构体】使用的对象（如 产能.ib_投料信号）。
   成员类型按使用方式推断（位/16 位/32 位/浮点）。*/

typedef struct {
    plc_bit bSlaveRunState;
    plc_bit wALState;
} _ECATSlave_t;

typedef struct {
    plc_bit Connected;
} _EthIPScanner_t;

typedef struct {
    int16_t ErrorSlvAddr;
} _MbMst_t;

typedef struct {
    int16_t ErrorSlvAddr;
} _MbMst3_t;

typedef struct {
    plc_bit ib_投料信号;
} 产能_t;

typedef struct {
    int32_t od_夜班产能OK产量;
    int32_t od_夜班产能总产量;
    int32_t od_白班产能OK产量;
    int32_t od_白班产能总产量;
} 当天小时产能_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} AOI出料皮带_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} CCD检测位压合升降气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} CCD检测位压合平移气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} CCD检测位横向定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} CCD检测位纵向定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} CCD检测位阻挡气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} CCD检测位顶升气缸_t;

typedef struct {
    plc_bit QB_不满足;
    plc_bit QB_满足;
} FBI_001_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} FL侧边光源平移气缸_t;

typedef struct {
    plc_bit 反向点动;
    plc_bit 当前速度;
    plc_bit 正向点动;
} FL右Y电缸_t;

typedef struct {
    plc_bit 反向点动;
    plc_bit 当前速度;
    plc_bit 正向点动;
} FL右Z电缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} FL夹紧气缸_t;

typedef struct {
    plc_bit 当前速度;
} FL左X电缸_t;

typedef struct {
    plc_bit 反向点动;
    plc_bit 当前速度;
    plc_bit 正向点动;
} FL左Y电缸_t;

typedef struct {
    plc_bit 反向点动;
    plc_bit 当前速度;
    plc_bit 正向点动;
} FL左Z电缸_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} NG皮带电机_t;

typedef struct {
    plc_bit HMI_定位OK;
    plc_bit JOG条件;
    plc_bit 初始化找原;
    plc_bit 定位方向;
    plc_bit 急停;
    plc_bit 相对定位OK;
    plc_bit 自动JOG正;
    plc_bit 自动JOG负;
    plc_bit 自动JOG速度;
    plc_bit 自动互锁;
    int16_t 自动定位ID;
    plc_bit 轴使能OK;
    plc_bit 轴找原OK;
} 下料Y轴_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 出位Y;
    plc_bit 出位感应;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 原位Y;
    plc_bit 原位感应;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 下料位横向定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 下料位阻挡气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 下料位顶升气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 下料机械手升降气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 下料机械手夹爪气缸_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 下料皮带电机1_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 下料皮带电机2_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 下料皮带电机3_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 下料皮带电机4_t;

typedef struct {
    plc_bit 开真空OK;
    plc_bit 开真空Y;
    plc_bit 真空检测;
    plc_bit 破真空OK;
    plc_bit 破真空Y;
    plc_bit 空跑模式;
    plc_bit 自动下去吸料检测屏蔽;
} 下料真空_t;

typedef struct {
    plc_bit 开真空OK;
    plc_bit 真空检测;
    plc_bit 破真空OK;
    plc_bit 破真空Y;
    plc_bit 空跑模式;
    plc_bit 自动下去吸料检测屏蔽;
} 废料真空_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位FPC夹膜气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位FPC扶正升降气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位FPC扶正平移气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位FPC撕膜升降气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位FPC撕膜平移气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位横向定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位纵向定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位阻挡气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 撕膜位顶升气缸_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 撕膜皮带电机_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人1位抚平定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人1位横向定位气缸_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 机器人1位皮带电机_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人1位纵向定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人1位阻挡气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人1位顶升气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人1爪手升降气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 出位感应;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 原位Y;
    plc_bit 原位感应;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人1爪手夹头气缸_t;

typedef struct {
    plc_bit 开真空OK;
    plc_bit 破真空OK;
    plc_bit 破真空Y;
    plc_bit 空跑模式;
    plc_bit 自动下去吸料检测屏蔽;
} 机器人1真空_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人2位抚平定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人2位横向定位气缸_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 机器人2位皮带电机_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人2位纵向定位气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人2位阻挡气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人2位顶升气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 出位感应;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 原位感应;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人2爪手升降气缸_t;

typedef struct {
    plc_bit 出位OK;
    plc_bit 出位感应;
    plc_bit 单控双控;
    plc_bit 原位OK;
    plc_bit 原位Y;
    plc_bit 原位感应;
    plc_bit 屏蔽到位延时;
    plc_bit 手动条件;
} 机器人2爪手夹头气缸_t;

typedef struct {
    plc_bit 开真空OK;
    plc_bit 破真空OK;
    plc_bit 破真空Y;
    plc_bit 空跑模式;
    plc_bit 自动下去吸料检测屏蔽;
} 机器人2真空_t;

typedef struct {
    plc_bit ix_检测信号;
    plc_bit qx_检测信号;
} 来料检测0_t;

typedef struct {
    plc_bit i_x手动一起反转运行;
    plc_bit i_x手动模式;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动模式;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动高低速切换;
    plc_bit 皮带1反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2反转方向;
    plc_bit 皮带2正转;
    plc_bit 皮带2速度切换;
} 检测位皮带电机_t;

typedef struct {
    plc_bit HMI_复位;
    plc_bit QB_初始化中;
    plc_bit QB_半自动中;
    plc_bit QB_手动中;
    plc_bit QB_自动中;
    plc_bit QB_自动暂停中;
    plc_bit QF_设备状态;
    plc_bit i_x联机模式;
} 设备状态机_t;

typedef struct {
    plc_bit i_xNG下料提示;
    plc_bit i_x前门禁信号常闭;
    plc_bit i_x后门禁信号常闭;
    plc_bit i_x照明;
    plc_bit o_x照明;
    plc_bit o_x红灯;
    plc_bit o_x蜂鸣器;
} 门禁三色灯_t;

