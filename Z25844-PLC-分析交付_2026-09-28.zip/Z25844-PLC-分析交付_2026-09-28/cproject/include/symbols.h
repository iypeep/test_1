#pragma once
#include "plc.h"

/* 自动生成：工程符号 → C 变量（名称与 AutoShop 工程一致，便于逐行对照梯形图）。
   类型由**变量表字节数 + 代码里的使用方式**推断，见 cproject/README.md「类型推断」。*/

/* ========== EtherCAT 过程数据与系统区（65 个） ========== */
extern int32_t _IQ11_0;  /* 0X2105910  Output port to which signals are allcated */
extern int32_t _IQ11_1;  /* 0X2105920  Numerical data flag */
extern int32_t _IQ11_11;  /* 0X21059C0  Pushing force for positioning */
extern int32_t _IQ11_14;  /* 0X2105A10  Positioning width */
extern int32_t _IQ11_15;  /* 0X2105A30  Signal allocated to the input port */
extern int32_t _IQ11_17;  /* 0X2105A50  Current position */
extern int32_t _IQ11_18;  /* 0X2105A70  Current speed */
extern int32_t _IQ11_2;  /* 0X2105908  Start flag */
extern int32_t _IQ11_3;  /* 0X2105930  Operation Method */
extern int32_t _IQ11_4;  /* 0X2105940  Speed */
extern int32_t _IQ11_5;  /* 0X2105950  Target position */
extern int32_t _IQ11_6;  /* 0X2105970  Acceleration */
extern int32_t _IQ11_7;  /* 0X2105980  Deceleration */
extern int32_t _IQ3_0;  /* 0X2103FC0  Output port to which signals are allcated */
extern int32_t _IQ3_1;  /* 0X21043B0  Numerical data flag */
extern int32_t _IQ3_11;  /* 0X2104440  Pushing force for positioning */
extern int32_t _IQ3_14;  /* 0X2104590  Positioning width */
extern int32_t _IQ3_15;  /* 0X2104990  Signal allocated to the input port */
extern int32_t _IQ3_17;  /* 0X21049B0  Current position */
extern int32_t _IQ3_18;  /* 0X21049D0  Current speed */
extern int32_t _IQ3_2;  /* 0X2101758  Start flag */
extern int32_t _IQ3_3;  /* 0X2101778  Operation Method */
extern int32_t _IQ3_4;  /* 0X21043C0  Speed */
extern int32_t _IQ3_5;  /* 0X21043D0  Target position */
extern int32_t _IQ3_6;  /* 0X21043F0  Acceleration */
extern int32_t _IQ3_7;  /* 0X2104400  Deceleration */
extern int32_t _IQ5_0;  /* 0X2104A30  Output port to which signals are allcated */
extern int32_t _IQ5_1;  /* 0X2104A40  Numerical data flag */
extern int32_t _IQ5_11;  /* 0X2104AE0  Pushing force for positioning */
extern int32_t _IQ5_14;  /* 0X2104B30  Positioning width */
extern int32_t _IQ5_15;  /* 0X2104B50  Signal allocated to the input port */
extern int32_t _IQ5_17;  /* 0X2104B70  Current position */
extern int32_t _IQ5_18;  /* 0X2104B90  Current speed */
extern int32_t _IQ5_2;  /* 0X2104A28  Start flag */
extern int32_t _IQ5_3;  /* 0X2104A50  Operation Method */
extern int32_t _IQ5_4;  /* 0X2104A60  Speed */
extern int32_t _IQ5_5;  /* 0X2104A70  Target position */
extern int32_t _IQ5_6;  /* 0X2104A90  Acceleration */
extern int32_t _IQ5_7;  /* 0X2104AA0  Deceleration */
extern int32_t _IQ7_0;  /* 0X2104C10  Output port to which signals are allcated */
extern int32_t _IQ7_1;  /* 0X2104C20  Numerical data flag */
extern int32_t _IQ7_11;  /* 0X21050E0  Pushing force for positioning */
extern int32_t _IQ7_14;  /* 0X2105130  Positioning width */
extern int32_t _IQ7_15;  /* 0X2105150  Signal allocated to the input port */
extern int32_t _IQ7_17;  /* 0X2105170  Current position */
extern int32_t _IQ7_18;  /* 0X2105190  Current speed */
extern int32_t _IQ7_2;  /* 0X2104BE8  Start flag */
extern int32_t _IQ7_3;  /* 0X2104C30  Operation Method */
extern int32_t _IQ7_4;  /* 0X2104C40  Speed */
extern int32_t _IQ7_5;  /* 0X2104C50  Target position */
extern int32_t _IQ7_6;  /* 0X2104C70  Acceleration */
extern int32_t _IQ7_7;  /* 0X21050A0  Deceleration */
extern int32_t _IQ9_0;  /* 0X21051F0  Output port to which signals are allcated */
extern int32_t _IQ9_1;  /* 0X2105200  Numerical data flag */
extern int32_t _IQ9_11;  /* 0X2105800  Pushing force for positioning */
extern int32_t _IQ9_14;  /* 0X2105850  Positioning width */
extern int32_t _IQ9_15;  /* 0X2105870  Signal allocated to the input port */
extern int32_t _IQ9_17;  /* 0X2105890  Current position */
extern int32_t _IQ9_18;  /* 0X21058B0  Current speed */
extern int32_t _IQ9_2;  /* 0X21051E8  Start flag */
extern int32_t _IQ9_3;  /* 0X2105210  Operation Method */
extern int32_t _IQ9_4;  /* 0X2105220  Speed */
extern int32_t _IQ9_5;  /* 0X2105230  Target position */
extern int32_t _IQ9_6;  /* 0X2105250  Acceleration */
extern int32_t _IQ9_7;  /* 0X2105260  Deceleration */

/* ========== HMI 交互量（上位机/触摸屏读写）（217 个） ========== */
extern plc_bit HMI_AOI1FL定位拍照触发;  /* 0X21000EF */
extern plc_bit HMI_AOI1检测拍照触发;  /* 0X2003FB */
extern plc_bit HMI_AOI2检测拍照触发;  /* 0X2003FC */
extern int16_t HMI_FPC重拍次数;  /* 0X504C20 */
extern plc_bit HMI_下料Y轴屏蔽;  /* 0X2003FE */
extern plc_bit HMI_保压动作屏蔽;  /* 0X2003F7 */
extern int32_t HMI_保压延时;  /* 0X504BE0 */
extern plc_bit HMI_停止;  /* 0X200007 */
extern plc_bit HMI_写入配方;  /* 0X2000B8 */
extern plc_bit HMI_初始化[10];  /* 0X200028 */
extern plc_bit HMI_初始化中[10];  /* 0X21001D0 */
extern plc_bit HMI_初始化完成[10];  /* 0X20001E */
extern int16_t HMI_初始化流程[80];  /* 0X5000A0 */
extern plc_bit HMI_半自动模式;  /* 0X20003C */
extern plc_bit HMI_单步选择[10];  /* 0X200014 */
extern int32_t HMI_压力实时显示值[80];  /* 0X2103FD0 */
extern plc_bit HMI_反向点动[32];  /* 0X10073A */
extern plc_bit HMI_反限位[32];  /* 0X1007D0 */
extern plc_bit HMI_启动;  /* 0X200006 */
extern plc_bit HMI_回原超时;  /* 0X200008 */
extern plc_bit HMI_复位;  /* 0X200003 */
extern plc_bit HMI_工位屏蔽[10];  /* 0X200032 */
extern int16_t HMI_工位状态字[80];  /* 0X504C50 */
extern plc_bit HMI_左右Y同时到下压位;  /* 0X210019F */
extern plc_bit HMI_左右Y同时到推入位;  /* 0X21001BF */
extern plc_bit HMI_左右Z同时到下压位;  /* 0X21001AF */
extern plc_bit HMI_左右Z同时到推入位;  /* 0X21001CF */
extern plc_bit HMI_弹窗变量[20];  /* 0X200044 */
extern plc_bit HMI_弹窗忽略[20];  /* 0X20006C */
extern plc_bit HMI_弹窗确认[20];  /* 0X200058 */
extern int32_t HMI_当前配方号;  /* 0X504DA0 */
extern plc_bit HMI_手动光源控制[10];  /* 0X2000AE */
extern plc_bit HMI_手自动切换;  /* 0X200005 */
extern int32_t HMI_扫码枪1NG重扫次数;  /* 0X2000070 */
extern int32_t HMI_扫码枪1当前条码;  /* 0X401900 */
extern plc_bit HMI_扫码枪1手动扫码触发;  /* 0X2000AA */
extern int32_t HMI_扫码枪2NG重扫次数;  /* 0X2000080 */
extern int32_t HMI_扫码枪2当前条码;  /* 0X401B80 */
extern plc_bit HMI_扫码枪2手动扫码触发;  /* 0X2000AB */
extern plc_bit HMI_扫码枪屏蔽;  /* 0X2003F1 */
extern plc_bit HMI_插FL动作屏蔽;  /* 0X2003F3 */
extern plc_bit HMI_插FL视觉屏蔽;  /* 0X2003FA */
extern int32_t HMI_撕膜位皮带出料延时;  /* 0X504B20 */
extern int32_t HMI_撕膜位皮带进料延时;  /* 0X504B00 */
extern plc_bit HMI_撕膜动作屏蔽;  /* 0X2003F8 */
extern plc_bit HMI_故障清除;  /* 0X200001 */
extern plc_bit HMI_断使能[32];  /* 0X10076C */
extern int16_t HMI_暂停位置[512];  /* 0X40E100 */
extern plc_bit HMI_暂停标记;  /* 0X20000E */
extern plc_bit HMI_未整机回原;  /* 0X200004 */
extern plc_bit HMI_机器人1EPD动作屏蔽;  /* 0X2003F9 */
extern plc_bit HMI_机器人1EPD视觉屏蔽;  /* 0X2003F5 */
extern int32_t HMI_机器人1位皮带出料延时;  /* 0X504B60 */
extern int32_t HMI_机器人1位皮带进料延时;  /* 0X504B40 */
extern int16_t HMI_机器人1速度百分比;  /* 0X504C00 */
extern plc_bit HMI_机器人2TP动作屏蔽;  /* 0X2003F4 */
extern plc_bit HMI_机器人2TP吸视觉屏蔽;  /* 0X2003F6 */
extern plc_bit HMI_机器人2TP插视觉屏蔽;  /* 0X2003FD */
extern int32_t HMI_机器人2位皮带出料延时;  /* 0X504BA0 */
extern int32_t HMI_机器人2位皮带进料延时;  /* 0X504B80 */
extern plc_bit HMI_机器人2夹头气缸屏蔽;  /* 0X2003FF */
extern plc_bit HMI_机器人2插入屏蔽;  /* 0X21000EE */
extern int16_t HMI_机器人2速度百分比;  /* 0X504C40 */
extern int16_t HMI_来料检测延时报警[800];  /* 0X5044C0 */
extern plc_bit HMI_来料检测报警屏蔽[50];  /* 0X100E10 */
extern int16_t HMI_来料检测有效延时[800];  /* 0X503E80 */
extern int32_t HMI_检测位出料延时;  /* 0X504D80 */
extern int32_t HMI_检测位皮带进料延时;  /* 0X504BC0 */
extern plc_bit HMI_检测来料报警[32];  /* 0X1010CC */
extern plc_bit HMI_检测相机屏蔽;  /* 0X2003F2 */
extern plc_bit HMI_正向点动[32];  /* 0X100708 */
extern plc_bit HMI_正寸动[32];  /* 0X1008CA */
extern plc_bit HMI_正限位[32];  /* 0X10079E */
extern int16_t HMI_气缸到位延时[1600];  /* 0X410680 */
extern int16_t HMI_气缸到位延时报警[1600];  /* 0X40FA00 */
extern plc_bit HMI_气缸动位屏蔽[100];  /* 0X100D48 */
extern plc_bit HMI_气缸动位报警[100];  /* 0X101194 */
extern plc_bit HMI_气缸原位屏蔽[100];  /* 0X100CE4 */
extern plc_bit HMI_气缸原位报警[100];  /* 0X101130 */
extern plc_bit HMI_气缸变化标志[100];  /* 0X10125C */
extern plc_bit HMI_气缸手动控制[100];  /* 0X100BB8 */
extern plc_bit HMI_没有整机回原;  /* 0X200009 */
extern plc_bit HMI_流通模式;  /* 0X200401 */
extern plc_bit HMI_清料模式;  /* 0X200002 */
extern int32_t HMI_点动速度[80];  /* 0X50DCA0 */
extern plc_bit HMI_点动速度修改[10];  /* 0X2100110 */
extern plc_bit HMI_点动速度统一修改;  /* 0X210018F */
extern plc_bit HMI_电缸10在当前位[15];  /* 0X21001B0 */
extern plc_bit HMI_电缸10定位[15];  /* 0X2100160 */
extern int32_t HMI_电缸10定位位置;  /* 0X50C800 */
extern plc_bit HMI_电缸1在当前位[10];  /* 0X2101460 */
extern plc_bit HMI_电缸1定位[10];  /* 0X2100660 */
extern plc_bit HMI_电缸2在当前位[10];  /* 0X2101470 */
extern plc_bit HMI_电缸2定位[10];  /* 0X2100670 */
extern plc_bit HMI_电缸3在当前位[10];  /* 0X2101480 */
extern plc_bit HMI_电缸3定位[10];  /* 0X2100680 */
extern plc_bit HMI_电缸4在当前位[10];  /* 0X2101490 */
extern plc_bit HMI_电缸4定位[10];  /* 0X2101440 */
extern plc_bit HMI_电缸5在当前位[10];  /* 0X21014A0 */
extern plc_bit HMI_电缸5定位[10];  /* 0X2101450 */
extern plc_bit HMI_电缸6在当前位[15];  /* 0X2100170 */
extern int32_t HMI_电缸6定位;  /* 0X2100120 */
extern int32_t HMI_电缸6定位位置[120];  /* 0X50BB80 */
extern plc_bit HMI_电缸7在当前位[15];  /* 0X2100180 */
extern plc_bit HMI_电缸7定位[15];  /* 0X2100130 */
extern int32_t HMI_电缸7定位位置[120];  /* 0X50BEA0 */
extern plc_bit HMI_电缸8在当前位[15];  /* 0X2100190 */
extern plc_bit HMI_电缸8定位[15];  /* 0X2100140 */
extern int32_t HMI_电缸8定位位置;  /* 0X50C1C0 */
extern plc_bit HMI_电缸9在当前位[15];  /* 0X21001A0 */
extern plc_bit HMI_电缸9定位[15];  /* 0X2100150 */
extern int32_t HMI_电缸9定位位置[120];  /* 0X50C4E0 */
extern plc_bit HMI_电缸Y一起正向点动;  /* 0X21000E5 */
extern plc_bit HMI_电缸Y一起负向点动;  /* 0X21000E6 */
extern plc_bit HMI_电缸Z一起正向点动;  /* 0X21000E7 */
extern plc_bit HMI_电缸Z一起负向点动;  /* 0X21000E8 */
extern plc_bit HMI_电缸使能[10];  /* 0X2100518 */
extern plc_bit HMI_电缸使能完成[10];  /* 0X2105CC0 */
extern int16_t HMI_电缸关盖速度;  /* 0X50DE40 */
extern int16_t HMI_电缸加减速度[80];  /* 0X50DC00 */
extern plc_bit HMI_电缸原点复位[10];  /* 0X2100528 */
extern plc_bit HMI_电缸反向点动[10];  /* 0X2105CB0 */
extern int16_t HMI_电缸定位低速;  /* 0X50DE00 */
extern int16_t HMI_电缸定位高速;  /* 0X50DDE0 */
extern int16_t HMI_电缸当前位置[160];  /* 0X50CB20 */
extern plc_bit HMI_电缸报警中[10];  /* 0X200241 */
extern plc_bit HMI_电缸报警复位[10];  /* 0X2100650 */
extern plc_bit HMI_电缸暂停[10];  /* 0X2100640 */
extern plc_bit HMI_电缸正向点动[10];  /* 0X2105CA0 */
extern int32_t HMI_电缸点动速度;  /* 0X50DE20 */
extern plc_bit HMI_电缸运动中[10];  /* 0X2105CE0 */
extern plc_bit HMI_电缸运行启动[10];  /* 0X2100630 */
extern int16_t HMI_电缸速度[80];  /* 0X50DAC0 */
extern plc_bit HMI_皮带1手动单独正转[10];  /* 0X200082 */
extern plc_bit HMI_皮带2手动单独正转[10];  /* 0X20008C */
extern plc_bit HMI_皮带手动一起正转[10];  /* 0X200096 */
extern int16_t HMI_真空吸延时[1600];  /* 0X411F80 */
extern plc_bit HMI_真空屏蔽[100];  /* 0X100DAC */
extern plc_bit HMI_真空手动控制[100];  /* 0X100C1C */
extern plc_bit HMI_真空报警[100];  /* 0X1011F8 */
extern int16_t HMI_真空报警延时[1600];  /* 0X411300 */
extern int16_t HMI_真空破延时[1600];  /* 0X412C00 */
extern plc_bit HMI_空跑模式;  /* 0X2003ED */
extern plc_bit HMI_自动中[10];  /* 0X21000B0 */
extern int16_t HMI_自动流程[160];  /* 0X21078A0 */
extern plc_bit HMI_自动跳转[10];  /* 0X21001E0 */
extern plc_bit HMI_视觉只触发;  /* 0X210067B */
extern plc_bit HMI_设备报警;  /* 0X200000 */
extern int32_t HMI_设备状态机;  /* 0X2100210 */
extern int16_t HMI_设备运行模式;  /* 0X2100200 */
extern plc_bit HMI_负寸动[32];  /* 0X1008FC */
extern int16_t HMI_轴10定位位置[400];  /* 0X405AA0 */
extern int16_t HMI_轴11定位位置[400];  /* 0X405DC0 */
extern int16_t HMI_轴12定位位置[400];  /* 0X4060E0 */
extern int16_t HMI_轴13定位位置[400];  /* 0X406400 */
extern int16_t HMI_轴14定位位置[400];  /* 0X406720 */
extern int16_t HMI_轴15定位位置[400];  /* 0X406A40 */
extern int16_t HMI_轴16定位位置[400];  /* 0X406D60 */
extern int16_t HMI_轴17定位位置[400];  /* 0X407080 */
extern int16_t HMI_轴18定位位置[400];  /* 0X4073A0 */
extern int16_t HMI_轴19定位位置[400];  /* 0X4076C0 */
extern plc_bit HMI_轴1定位[25];  /* 0X100064 */
extern int16_t HMI_轴1定位位置[400];  /* 0X403E80 */
extern int32_t HMI_轴1读取位置;  /* 0X10039D */
extern int16_t HMI_轴20定位位置[400];  /* 0X4079E0 */
extern int16_t HMI_轴21定位位置[400];  /* 0X407D00 */
extern int16_t HMI_轴22定位位置[400];  /* 0X408020 */
extern int16_t HMI_轴23定位位置[400];  /* 0X408340 */
extern int16_t HMI_轴24定位位置[400];  /* 0X408660 */
extern int16_t HMI_轴25定位位置[400];  /* 0X408980 */
extern int16_t HMI_轴26定位位置[400];  /* 0X408CA0 */
extern int16_t HMI_轴27定位位置[400];  /* 0X408FC0 */
extern int16_t HMI_轴28定位位置[400];  /* 0X4092E0 */
extern int16_t HMI_轴29定位位置[400];  /* 0X409600 */
extern int16_t HMI_轴2定位位置[400];  /* 0X4041A0 */
extern int16_t HMI_轴30定位位置[400];  /* 0X409920 */
extern int16_t HMI_轴31定位位置[400];  /* 0X409C40 */
extern int16_t HMI_轴32定位位置[400];  /* 0X409F60 */
extern int16_t HMI_轴3定位位置[400];  /* 0X4044C0 */
extern int16_t HMI_轴4定位位置[400];  /* 0X4047E0 */
extern int16_t HMI_轴5定位位置[400];  /* 0X404B00 */
extern int16_t HMI_轴6定位位置[400];  /* 0X404E20 */
extern int16_t HMI_轴7定位位置[400];  /* 0X405140 */
extern int16_t HMI_轴8定位位置[400];  /* 0X405460 */
extern int16_t HMI_轴9定位位置[400];  /* 0X405780 */
extern int16_t HMI_轴减速度[512];  /* 0X40C800 */
extern int16_t HMI_轴加速度[512];  /* 0X40C1C0 */
extern plc_bit HMI_轴原点[32];  /* 0X100866 */
extern plc_bit HMI_轴回原[32];  /* 0X1006D6 */
extern plc_bit HMI_轴回原OK[32];  /* 0X100834 */
extern int16_t HMI_轴当前位置[512];  /* 0X40CE40 */
extern int16_t HMI_轴手动速度[512];  /* 0X40A8C0 */
extern plc_bit HMI_轴报警[32];  /* 0X100FA0 */
extern plc_bit HMI_轴没使能[32];  /* 0X100FD2 */
extern int16_t HMI_轴自动高速[512];  /* 0X40BB80 */
extern plc_bit HMI_轴运行中[32];  /* 0X100802 */
extern plc_bit HMI_载具空跑模式;  /* 0X2000AC */
extern int32_t HMI_选择配方号;  /* 0X504DC0 */
extern int16_t HMI_配方写入结果;  /* 0X504DE0 */
extern plc_bit HMI_驱动通讯报警[32];  /* 0X101004 */
extern int16_t HMI回原偏移[512];  /* 0X40E740 */
extern int16_t HMI寸动位置[512];  /* 0X40ED80 */
extern plc_bit HMI当天产能清零;  /* 0X20000D */
extern int32_t h_f总NG数;  /* 0X50B5E0 */
extern int32_t h_f总OK数;  /* 0X50B5C0 */
extern int32_t h_f总产能;  /* 0X50B5A0 */
extern int32_t h_f总良率;  /* 0X50B600 */
extern int16_t h_i设备状态;  /* 0X500000  1手动2自动模式3自动中 */
extern plc_bit h_xpc联机模式;  /* 0X200400  1=PC联机 */
extern plc_bit h_x上游联机开启;  /* 0X2003EF  0屏蔽1开启 */
extern plc_bit h_x下游联机开启;  /* 0X2003EB  0屏蔽1开启 */
extern plc_bit h_x安全门屏蔽;  /* 0X2003E8  0开启1屏蔽 */
extern plc_bit h_x急停;  /* 0X20000B */
extern plc_bit h_x总产能清零;  /* 0X200040 */
extern plc_bit h_x维修中;  /* 0X20003F */
extern plc_bit h_x维修模式;  /* 0X2003EE */
extern plc_bit h_x蜂鸣器屏蔽;  /* 0X2003E9  0开启1屏蔽 */

/* ========== 主控标志与报警（201 个） ========== */
extern int32_t Gi_部件状态计数;  /* 0X21000D0 */
extern plc_bit err_AOI检测工位条码检测对比不一致报警;  /* 0X20023F */
extern plc_bit err_FLAOI工位acf上传数据反馈结果超时报警;  /* 0X210148F */
extern plc_bit err_FL拍照NG提示;  /* 0X210011E */
extern plc_bit err_FL拍照结构反馈超时提示;  /* 0X210013F */
extern plc_bit err_NG皮带满料提示;  /* 0X200239 */
extern plc_bit err_TP工位acf上传压力数据反馈结果超时报警;  /* 0X210148E */
extern plc_bit err_epd工位acf上传压力数据反馈结果超时报警;  /* 0X210148B */
extern plc_bit err_pc软件未打开;  /* 0X20023D */
extern plc_bit err_x前急停报警;  /* 0X2001F9 */
extern plc_bit err_x前门禁报警;  /* 0X2001F4 */
extern plc_bit err_x右门禁报警;  /* 0X2001F7 */
extern plc_bit err_x后急停报警;  /* 0X2001FA */
extern plc_bit err_x后门禁报警;  /* 0X2001F5 */
extern plc_bit err_x左门禁报警;  /* 0X2001F6 */
extern plc_bit err_x急停3报警;  /* 0X2001FB */
extern plc_bit err_x急停4报警;  /* 0X2001FC */
extern plc_bit err_x正限位报警[32];  /* 0X1013EC */
extern plc_bit err_x气源报警;  /* 0X2001F8 */
extern plc_bit err_x负限位报警[32];  /* 0X10141E */
extern plc_bit err_x轴不在暂停位置[32];  /* 0X1013BA */
extern plc_bit err_上位机ACF通讯连接失败报警;  /* 0X210149E */
extern plc_bit err_下料Y轴防撞不能运行;  /* 0X20020E */
extern plc_bit err_下料机械手夹爪有料感应异常报警;  /* 0X20023C */
extern plc_bit err_压力传感器485通讯报警[10];  /* 0X200226 */
extern plc_bit err_扫码枪1扫码NG;  /* 0X200209 */
extern plc_bit err_扫码枪1接收超时;  /* 0X200208 */
extern plc_bit err_扫码枪1连接超时;  /* 0X20020A */
extern plc_bit err_扫码枪2扫码NG;  /* 0X20020C */
extern plc_bit err_扫码枪2接收超时;  /* 0X20020B */
extern plc_bit err_扫码枪2连接超时;  /* 0X20020D */
extern plc_bit err_撕膜位进料此产品不允许过站报警;  /* 0X20023E */
extern plc_bit err_撕膜工位acf上传ct反馈结果超时报警;  /* 0X210147F */
extern plc_bit err_撕膜工位acf进站上传条码反馈结果超时报警;  /* 0X210147D */
extern plc_bit err_断电重启FL右Z电缸需手动回原点提示;  /* 0X210067A */
extern plc_bit err_断电重启FL左Z电缸需手动回原点提示;  /* 0X210066F */
extern plc_bit err_机器人1EIP通讯报警;  /* 0X210145C */
extern plc_bit err_机器人1电池没电报警;  /* 0X200231 */
extern plc_bit err_机器人1系统报警;  /* 0X200230 */
extern plc_bit err_机器人2EIP通讯报警;  /* 0X210145D */
extern plc_bit err_机器人2电池没电报警;  /* 0X200233 */
extern plc_bit err_机器人2系统报警;  /* 0X200232 */
extern plc_bit err_气缸状态异常不允许启动[100];  /* 0X101324 */
extern plc_bit err_皮带电机报警[10];  /* 0X2001FD */
extern plc_bit err_视觉未连接;  /* 0X200225 */
extern plc_bit g_ax轴不在暂停位置[32];  /* 0X21045B0 */
extern plc_bit g_x485通讯报警延时;  /* 0X210000F */
extern double g_xAOI1定位偏移X;  /* 0X2105BF0 */
extern double g_xAOI1定位偏移X中转;  /* 0X2105C30 */
extern double g_xAOI1定位偏移Y;  /* 0X2105C10 */
extern double g_xAOI1定位偏移Y中转;  /* 0X2105C50 */
extern plc_bit g_xAOI检测位NG料;  /* 0X210059F */
extern plc_bit g_xAOI检测位OK料;  /* 0X210059E */
extern plc_bit g_xCCD检测位允许放料;  /* 0X21001DC */
extern double g_xDINT_AOI1定位偏移X;  /* 0X2105C70 */
extern double g_xDINT_AOI1定位偏移Y;  /* 0X2105D10 */
extern plc_bit g_xEPD位pc上传完成;  /* 0X210149C */
extern plc_bit g_xFLct开始[20];  /* 0X210BB10 */
extern plc_bit g_xFLct细分计时[20];  /* 0X210BAF0 */
extern plc_bit g_xFL抚平中;  /* 0X210015F */
extern plc_bit g_xFL抚平完成;  /* 0X210016F */
extern plc_bit g_xFL提前动作中;  /* 0X210068A */
extern plc_bit g_xFL提前动作完成;  /* 0X210068B */
extern plc_bit g_xTP位pc上传完成;  /* 0X210149D */
extern plc_bit g_xct计时开始[10];  /* 0X2101680 */
extern plc_bit g_x一段皮带有料;  /* 0X210063A */
extern plc_bit g_x三段皮带允许进料;  /* 0X21005AD */
extern plc_bit g_x三段皮带有料信号;  /* 0X210028A */
extern plc_bit g_x下NG料;  /* 0X21001FA */
extern plc_bit g_x下NG料中转;  /* 0X2100284 */
extern plc_bit g_x下OK料;  /* 0X21001EF */
extern plc_bit g_x下OK料中转;  /* 0X21001FF */
extern plc_bit g_x下料Y轴安全条件;  /* 0X210007C */
extern plc_bit g_x下料中;  /* 0X21001FD */
extern plc_bit g_x下料位接料中;  /* 0X2100286 */
extern plc_bit g_x下料位放ok料完成;  /* 0X210028D */
extern plc_bit g_x下料前段皮带进料延时;  /* 0X2100288 */
extern plc_bit g_x下料前段皮带进料延时1;  /* 0X2100507 */
extern plc_bit g_x下料前段皮带进料延时2;  /* 0X210050D */
extern plc_bit g_x下料前段皮带进料延时3;  /* 0X21005AE */
extern plc_bit g_x下料前段皮带进料延时4;  /* 0X21005AF */
extern plc_bit g_x下料前段皮带进料延时5;  /* 0X210063B */
extern plc_bit g_x下料前段皮带进料超时;  /* 0X21014AB */
extern plc_bit g_x下料前段皮带进料超时1;  /* 0X21014AC */
extern plc_bit g_x下料后端皮带出料延时;  /* 0X210028C */
extern plc_bit g_x下料后端皮带进料延时;  /* 0X210028E */
extern plc_bit g_x下料完成;  /* 0X21001FB */
extern plc_bit g_x二段皮带允许放料;  /* 0X210063C */
extern plc_bit g_x二段皮带有料;  /* 0X210063E */
extern plc_bit g_x保压中;  /* 0X21001ED */
extern plc_bit g_x保压完成;  /* 0X21001EE */
extern plc_bit g_x保压延时;  /* 0X21001FE */
extern plc_bit g_x停止;  /* 0X2100006 */
extern plc_bit g_x允许机械手放NG料;  /* 0X21002F5 */
extern plc_bit g_x光源控制[10];  /* 0X2101690 */
extern plc_bit g_x启动按钮延时;  /* 0X2100007 */
extern plc_bit g_x四段皮带允许放料;  /* 0X210028B */
extern plc_bit g_x复位;  /* 0X2105D09 */
extern plc_bit g_x急停;  /* 0X2100074 */
extern int32_t g_x扫码枪1NG字符;  /* 0X210E4C0 */
extern int32_t g_x扫码枪1发送数据;  /* 0X210E380 */
extern plc_bit g_x扫码枪1条码检测;  /* 0X210000B */
extern plc_bit g_x扫码枪1条码检测OK;  /* 0X2100076 */
extern plc_bit g_x扫码枪1条码重复;  /* 0X210007E */
extern plc_bit g_x扫码枪1自动扫码触发;  /* 0X2100078 */
extern int32_t g_x扫码枪2NG字符;  /* 0X210E740 */
extern int32_t g_x扫码枪2发送数据;  /* 0X211C040 */
extern plc_bit g_x扫码枪2条码检测;  /* 0X210007F */
extern plc_bit g_x扫码枪2条码检测OK;  /* 0X21000BD */
extern plc_bit g_x扫码枪2条码重复;  /* 0X21001DA */
extern plc_bit g_x扫码枪2自动扫码触发;  /* 0X210007A */
extern plc_bit g_x插FL中;  /* 0X21000E1 */
extern plc_bit g_x插FL完成;  /* 0X21000E4 */
extern plc_bit g_x撕膜中;  /* 0X210007B */
extern plc_bit g_x撕膜位NG料;  /* 0X2100495 */
extern plc_bit g_x撕膜位OK料;  /* 0X2100496 */
extern plc_bit g_x撕膜位pc上传完成;  /* 0X210149B */
extern plc_bit g_x撕膜位皮带出料延时;  /* 0X21000A1 */
extern plc_bit g_x撕膜位皮带有料;  /* 0X2100497 */
extern plc_bit g_x撕膜位皮带进料延时;  /* 0X210000C */
extern plc_bit g_x撕膜位皮带进料超时延时;  /* 0X210064D */
extern plc_bit g_x撕膜位进料中;  /* 0X21005AA */
extern plc_bit g_x撕膜完成;  /* 0X210007D */
extern plc_bit g_x有弹窗提示;  /* 0X21000AC */
extern plc_bit g_x机器人1EPD抚平动作完成;  /* 0X210050F */
extern plc_bit g_x机器人1EPD插识别ng;  /* 0X2100527 */
extern plc_bit g_x机器人1EPD插识别ok;  /* 0X2100526 */
extern plc_bit g_x机器人1FL插识别ng;  /* 0X2100525 */
extern plc_bit g_x机器人1FL插识别ok;  /* 0X2100524 */
extern plc_bit g_x机器人1FL插识别既非;  /* 0X210059C */
extern plc_bit g_x机器人1ct开始[20];  /* 0X21079E0 */
extern plc_bit g_x机器人1ct细分计时[20];  /* 0X2105D30 */
extern plc_bit g_x机器人1位NG料;  /* 0X210049E */
extern plc_bit g_x机器人1位OK料;  /* 0X210049D */
extern plc_bit g_x机器人1位允许放料;  /* 0X21000A0 */
extern plc_bit g_x机器人1位皮带出料延时;  /* 0X21000AE */
extern plc_bit g_x机器人1位皮带有料;  /* 0X210049F */
extern plc_bit g_x机器人1位皮带进料延时;  /* 0X21000A2 */
extern plc_bit g_x机器人1插接中;  /* 0X21000AA */
extern plc_bit g_x机器人1插接完成;  /* 0X21000AB */
extern plc_bit g_x机器人1程序复位完成;  /* 0X2100008 */
extern plc_bit g_x机器人2TP吸识别ng;  /* 0X2100535 */
extern plc_bit g_x机器人2TP吸识别ok;  /* 0X2100534 */
extern plc_bit g_x机器人2TP插识别ng;  /* 0X2100533 */
extern plc_bit g_x机器人2TP插识别ok;  /* 0X2100532 */
extern plc_bit g_x机器人2ct开始[20];  /* 0X2107A40 */
extern plc_bit g_x机器人2ct细分计时[20];  /* 0X2107A20 */
extern plc_bit g_x机器人2位NG料;  /* 0X2100505 */
extern plc_bit g_x机器人2位OK料;  /* 0X2100504 */
extern plc_bit g_x机器人2位允许放料;  /* 0X21000AD */
extern plc_bit g_x机器人2位皮带出料延时;  /* 0X21001DD */
extern plc_bit g_x机器人2位皮带有料;  /* 0X2100506 */
extern plc_bit g_x机器人2位皮带进料延时;  /* 0X21000BB */
extern plc_bit g_x机器人2插接中;  /* 0X21000BE */
extern plc_bit g_x机器人2插接完成;  /* 0X21000BF */
extern plc_bit g_x机器人2程序复位完成;  /* 0X210000A */
extern plc_bit g_x机器人程序复位[5];  /* 0X21002F8 */
extern plc_bit g_x检测位皮带出料延时;  /* 0X21000EB */
extern plc_bit g_x检测位皮带出料检测延时;  /* 0X21014BB */
extern plc_bit g_x检测位皮带进料延时;  /* 0X21001DE */
extern plc_bit g_x清料;  /* 0X2105D0E */
extern plc_bit g_x电缸回零完成[10];  /* 0X21014B0 */
extern plc_bit g_x自动启动;  /* 0X21000A8 */
extern plc_bit g_x自动启动中;  /* 0X21000AF */
extern plc_bit g_x自动机器人任务执行完成[5];  /* 0X2100511 */
extern plc_bit g_x自动机器人执行任务[5];  /* 0X2100508 */
extern plc_bit g_x自动电缸10定位[15];  /* 0X2105BE0 */
extern plc_bit g_x自动电缸1定位[10];  /* 0X21014D0 */
extern plc_bit g_x自动电缸2定位[10];  /* 0X21014E0 */
extern plc_bit g_x自动电缸3定位[10];  /* 0X21014F0 */
extern plc_bit g_x自动电缸4定位[10];  /* 0X2101500 */
extern plc_bit g_x自动电缸5定位[10];  /* 0X2101510 */
extern plc_bit g_x自动电缸6定位[15];  /* 0X21001C0 */
extern plc_bit g_x自动电缸7定位[15];  /* 0X2105BB0 */
extern plc_bit g_x自动电缸8定位[15];  /* 0X2105BC0 */
extern plc_bit g_x自动电缸9定位[15];  /* 0X2105BD0 */
extern plc_bit g_x自动电缸回零[10];  /* 0X21014C0 */
extern plc_bit g_x自动进入标志;  /* 0X2101D40 */
extern plc_bit g_x轴不在暂停位;  /* 0X21000BA */
extern plc_bit g_x轴使能待机状态;  /* 0X2100009 */
extern plc_bit g_x过道皮带进料中;  /* 0X21005AB */
extern plc_bit g_x进料第一段清料完成;  /* 0X2105D01 */
extern plc_bit g_x进料第二段清料完成;  /* 0X2105D02 */
extern plc_bit g_x进料第四清料完成;  /* 0X2105D04 */
extern plc_bit g_x退出自动待机状态延时;  /* 0X2101D41 */
extern plc_bit g_x通知FL提前动作;  /* 0X210067F */
extern plc_bit g_x通知下料;  /* 0X21001FC */
extern plc_bit g_x通知下料位接料;  /* 0X2100285 */
extern plc_bit g_x通知保压;  /* 0X21001EC */
extern plc_bit g_x通知插FL;  /* 0X21000E0 */
extern plc_bit g_x通知插FL抚平;  /* 0X210014F */
extern plc_bit g_x通知撕膜;  /* 0X2100079 */
extern plc_bit g_x通知机器人1EPD抚平动作;  /* 0X210050E */
extern plc_bit g_x通知机器人1插接;  /* 0X21000A3 */
extern plc_bit g_x通知机器人2插接;  /* 0X21000BC */
extern plc_bit g_x通道1允许放料延时;  /* 0X210036F */
extern plc_bit g_x通道2允许放料延时;  /* 0X210036E */
extern plc_bit g_x错开扫描周期延时1;  /* 0X21001EA */
extern plc_bit g_检测相机屏蔽延时;  /* 0X21001EB */
extern plc_bit gx_气缸条件不满足标记;  /* 0X21000A4 */
extern plc_bit gx_气缸自动控制[100];  /* 0X100E74 */

/* ========== 内部位与 EtherNet/IP W 区（14 个） ========== */
extern plc_bit M8000;  /* 0X6201800  程序运行标志，运行：ON，停止：OFF */
extern plc_bit M8002;  /* 0X6201802  程序运行第1个扫描周期标志，程序运行第1个扫描周期为ON，否则为OFF */
extern plc_bit M8011;  /* 0X6201820  10ms周期时钟 */
extern plc_bit M8013;  /* 0X6201822  1s周期时钟 */
extern plc_bit MAIN_暂停延时记录位置;  /* 0X21000A6 */
extern plc_bit MAIN_自动启动延时;  /* 0X21000A9 */
extern plc_bit MIAN_停机;  /* 0X2100000 */
extern plc_bit MIAN_故障清除;  /* 0X2100001 */
extern plc_bit MIAN_暂停记录位置标志;  /* 0X21000A7 */
extern plc_bit MIAN_气缸初始化[100];  /* 0X2100010 */
extern plc_bit MIAN_真空初始化[100];  /* 0X2100300 */
extern plc_bit MIAN_真空自动吸[100];  /* 0X2100430 */
extern plc_bit MIAN_真空自动破[100];  /* 0X21004A0 */
extern plc_bit MIAN_自动启动;  /* 0X2100004 */

/* ========== 机构数据与其它工程变量（211 个） ========== */
extern double AOI1定位偏移X;  /* 0X402660 */
extern double AOI1定位偏移Y;  /* 0X402680 */
extern int16_t AOI1检测触发拍照;  /* 0X402620 */
extern int16_t AOI1检测返回结果;  /* 0X402640  1OK2NG */
extern int16_t AOI2检测触发拍照;  /* 0X4026C0 */
extern int16_t AOI2检测返回结果;  /* 0X4026E0  1OK2NG */
extern int32_t AOI检测工位条码;  /* 0X403340 */
extern plc_bit CCD检测位产品检测光电延时;  /* 0X210053B */
extern plc_bit CT复位[10];  /* 0X21005A0 */
extern plc_bit CT计时开始[10];  /* 0X2100590 */
extern int16_t EPD工位PC_PLC反馈结果;  /* 0X41BC60  10 */
extern double EPD工位PLC_PC上传CT;  /* 0X41BF80 */
extern int32_t EPD工位PLC_PC上传条码;  /* 0X41BD00 */
extern int16_t EPD工位PLC_PC请求上传;  /* 0X41BBC0  10 */
extern int16_t FLAOI工位PC_PLC反馈结果;  /* 0X41C8E0 */
extern double FLAOI工位PLC_PC上传CT;  /* 0X41CC00 */
extern int32_t FLAOI工位PLC_PC上传条码;  /* 0X41C980 */
extern int16_t FLAOI工位PLC_PC请求上传;  /* 0X41C840 */
extern plc_bit FLCT复位[20];  /* 0X210BB30 */
extern plc_bit FL抚平位延时;  /* 0X21000EC */
extern plc_bit FL抚平位延时1;  /* 0X21000ED */
extern plc_bit FL拍照视觉反馈超时;  /* 0X210011F */
extern double FL设备CT[160];  /* 0X210BDD0 */
extern int32_t FL设备CT时间[160];  /* 0X210BB50 */
extern double FL设备CT浮点数[160];  /* 0X210C050 */
extern double FL设备_CT[160];  /* 0X502580 */
extern double FL设备_CT时间[160];  /* 0X210C550 */
extern int16_t NG数量;  /* 0X2105D60 */
extern plc_bit NG皮带检测光电1延时;  /* 0X21002F4 */
extern plc_bit NG皮带检测光电1延时1;  /* 0X21002FD */
extern plc_bit NG皮带检测光电1延时2;  /* 0X21002FE */
extern plc_bit NG皮带满料延时;  /* 0X2100365 */
extern int16_t OK数量;  /* 0X2105D50 */
extern plc_bit PC反馈结果延时;  /* 0X210147E */
extern plc_bit PC反馈结果延时1;  /* 0X210148A */
extern plc_bit PC反馈结果延时2;  /* 0X210148C */
extern plc_bit PC反馈结果延时3;  /* 0X210148D */
extern plc_bit PC反馈结果延时4;  /* 0X210149A */
extern double PLC_PC_EPD检测数据;  /* 0X41CCC0 */
extern int16_t PLC_PC_EPD检测结果;  /* 0X41CCA0 */
extern double PLC_PC_EPD检测角度结果;  /* 0X41CD80 */
extern double PLC_PC_FL检测数据;  /* 0X41CD40 */
extern int16_t PLC_PC_FL检测结果;  /* 0X41CD20 */
extern double PLC_PC_TP检测数据;  /* 0X41CD00 */
extern int16_t PLC_PC_TP检测结果;  /* 0X41CCE0 */
extern int16_t PLC_PC总结果;  /* 0X41CD60 */
extern plc_bit T1;  /* 0X21000E9 */
extern plc_bit T2;  /* 0X21000EA */
extern int16_t TP工位PC_PLC反馈结果;  /* 0X41C2A0 */
extern double TP工位PLC_PC上传CT;  /* 0X41C5C0 */
extern int32_t TP工位PLC_PC上传条码;  /* 0X41C340 */
extern int16_t TP工位PLC_PC请求上传;  /* 0X41C200 */
extern plc_bit TTT;  /* 0X210012F */
extern plc_bit TTTT;  /* 0X210067C */
extern plc_bit fl定位延时;  /* 0X210011A */
extern plc_bit fl定位延时1;  /* 0X210011D */
extern int32_t i;  /* 0X21000C0 */
extern int16_t i夜班上班时间;  /* 0X210F370 */
extern int16_t i夜班下班时间;  /* 0X210F380 */
extern int16_t i白班上班时间;  /* 0X210EEE0 */
extern int16_t i白班下班时间;  /* 0X210EEF0 */
extern plc_bit 上位机acf心跳延时;  /* 0X210149F */
extern plc_bit 下料位产品检测光电2延时;  /* 0X21005AC */
extern plc_bit 下料位产品检测光电3;  /* 0X210063D */
extern plc_bit 下料夹爪夹料异常延时;  /* 0X210036D */
extern plc_bit 下料机械手夹爪有料感应延时;  /* 0X2100536 */
extern plc_bit 下料机械手夹爪有料感应延时1;  /* 0X2100537 */
extern int32_t 中转;  /* 0X21044B0 */
extern int32_t 中转1;  /* 0X2104490 */
extern plc_bit 人工拿料延时;  /* 0X210145E */
extern plc_bit 从站在线状态[32];  /* 0X2100080 */
extern plc_bit 光源延时;  /* 0X2100538 */
extern plc_bit 光源延时1;  /* 0X2100539 */
extern plc_bit 光源延时2;  /* 0X210053A */
extern int32_t 前天小时产能;  /* 0X50A280 */
extern plc_bit 压力收集开始[10];  /* 0X2101A20 */
extern plc_bit 压力采集时间;  /* 0X21014AA */
extern plc_bit 四段皮带进料超时延时;  /* 0X210064B */
extern plc_bit 延时1;  /* 0X210144E */
extern plc_bit 延时10;  /* 0X210146F */
extern plc_bit 延时11;  /* 0X210147A */
extern plc_bit 延时12;  /* 0X210147B */
extern plc_bit 延时13;  /* 0X210147C */
extern plc_bit 延时2;  /* 0X210144F */
extern plc_bit 延时3;  /* 0X210145A */
extern plc_bit 延时4;  /* 0X210145B */
extern int16_t 弹窗集合;  /* 0X2101A30 */
extern int32_t 当前时间;  /* 0X21005B0 */
extern int32_t 当天OK数;  /* 0X2105D80 */
extern int32_t 当天总产能;  /* 0X50B560 */
extern int32_t 当天良率;  /* 0X50B580 */
extern int16_t 总结果;  /* 0X4028C0 */
extern int32_t 扫码枪1IP;  /* 0X21052A0 */
extern int32_t 扫码枪1扫码字符;  /* 0X210F060 */
extern int32_t 扫码枪1端口号;  /* 0X21052C0 */
extern int32_t 扫码枪2IP;  /* 0X21052F0 */
extern int32_t 扫码枪2端口号;  /* 0X2105310 */
extern plc_bit 报警复位关闭延时[5];  /* 0X2100498 */
extern plc_bit 插FPC2延时重拍;  /* 0X21002F7 */
extern plc_bit 插入延时;  /* 0X21000E2 */
extern plc_bit 插入延时1;  /* 0X21000E3 */
extern plc_bit 撕膜位产品检测光电2延时;  /* 0X210053F */
extern plc_bit 撕膜位产品检测光电2延时1;  /* 0X210059A */
extern plc_bit 撕膜位产品检测光电延时;  /* 0X210053E */
extern plc_bit 撕膜位进料中延时;  /* 0X210064A */
extern plc_bit 撕膜位进料延时;  /* 0X21001DB */
extern plc_bit 撕膜位进料延时1;  /* 0X2100366 */
extern int16_t 撕膜工位PC_PLC反馈结果;  /* 0X41B620  10 OK  =20NG =30ct上传ok */
extern double 撕膜工位PLC_PC上传CT;  /* 0X41B940 */
extern int32_t 撕膜工位PLC_PC上传条码;  /* 0X41B6C0 */
extern int16_t 撕膜工位PLC_PC请求上传;  /* 0X41B580  10上传 =30上传ct */
extern int32_t 撕膜进料工位条码;  /* 0X402BC0 */
extern int32_t 昨天小时产能;  /* 0X508FC0 */
extern plc_bit 机器人1CT复位[20];  /* 0X2107A00 */
extern plc_bit 机器人1EPD真空吸失败;  /* 0X20023A */
extern plc_bit 机器人1FPC1插拍照识别失败;  /* 0X200234 */
extern plc_bit 机器人1FPC2吸拍照识别失败;  /* 0X200235 */
extern plc_bit 机器人1FPC2插拍照识别失败;  /* 0X200236 */
extern int16_t 机器人1kreal控制流程;  /* 0X2104850 */
extern plc_bit 机器人1位产品检测光电延时;  /* 0X210053D */
extern int16_t 机器人1吸FPC2识别失败计数;  /* 0X2100540 */
extern int32_t 机器人1工位条码;  /* 0X402E40 */
extern plc_bit 机器人1延时[30];  /* 0X2101AC0 */
extern plc_bit 机器人1延时T[20];  /* 0X2101740 */
extern int16_t 机器人1插FPC1识别失败计数;  /* 0X2100580 */
extern int16_t 机器人1插FPC2识别失败计数;  /* 0X2100550 */
extern plc_bit 机器人1插FPC失败中转;  /* 0X2100516 */
extern plc_bit 机器人1插FPC失败蜂鸣器中转;  /* 0X2100522 */
extern double 机器人1设备CT[160];  /* 0X210A470 */
extern int32_t 机器人1设备CT时间[160];  /* 0X210A1F0 */
extern double 机器人1设备CT浮点数[160];  /* 0X210A6F0 */
extern double 机器人1设备_CT[160];  /* 0X502080 */
extern double 机器人1设备_CT时间[160];  /* 0X210ABF0 */
extern plc_bit 机器人2CT复位[20];  /* 0X2107A60 */
extern plc_bit 机器人2FPC吸拍照识别失败;  /* 0X200237 */
extern plc_bit 机器人2FPC插拍照识别失败;  /* 0X200238 */
extern plc_bit 机器人2TP真空吸失败;  /* 0X20023B */
extern int16_t 机器人2kreal控制流程;  /* 0X2104860 */
extern plc_bit 机器人2位产品检测光电延时;  /* 0X210053C */
extern plc_bit 机器人2吸FPC延时重拍;  /* 0X21002FF */
extern int16_t 机器人2吸FPC识别失败计数;  /* 0X2100560 */
extern int32_t 机器人2工位条码;  /* 0X4030C0 */
extern plc_bit 机器人2延时[30];  /* 0X2101AE0 */
extern plc_bit 机器人2延时T[20];  /* 0X2101760 */
extern plc_bit 机器人2插FPC失败中转;  /* 0X2100517 */
extern plc_bit 机器人2插FPC失败蜂鸣器中转;  /* 0X2100523 */
extern plc_bit 机器人2插FPC延时重拍;  /* 0X2100364 */
extern int16_t 机器人2插FPC识别失败计数;  /* 0X2100570 */
extern double 机器人2设备CT[160];  /* 0X210B0F0 */
extern int32_t 机器人2设备CT时间[160];  /* 0X210AE70 */
extern double 机器人2设备CT浮点数[160];  /* 0X210B370 */
extern double 机器人2设备_CT[160];  /* 0X502300 */
extern double 机器人2设备_CT时间[160];  /* 0X210B870 */
extern plc_bit 机器人报警复位中转[5];  /* 0X2100368 */
extern int16_t 机器人控制字[40];  /* 0X21016A0 */
extern int16_t 机器人状态字[40];  /* 0X21016F0 */
extern int16_t 气缸动位报警集合;  /* 0X2100390 */
extern int16_t 气缸动位报警集合1;  /* 0X2103E90 */
extern int16_t 气缸原位报警集合;  /* 0X2100370 */
extern int16_t 气缸原位报警集合1;  /* 0X2101D10 */
extern plc_bit 气缸复位延时;  /* 0X210017F */
extern plc_bit 流道1进料延时;  /* 0X21014AD */
extern plc_bit 流道2皮带出料检测延时;  /* 0X21014AE */
extern plc_bit 流道2皮带出料检测延时1;  /* 0X21014AF */
extern plc_bit 流道2皮带出料检测延时2;  /* 0X21014BA */
extern plc_bit 清料延时判断;  /* 0X2105D07 */
extern plc_bit 电缸启动[10];  /* 0X2101670 */
extern plc_bit 电缸启动延时[10];  /* 0X2101660 */
extern int16_t 电缸控制字[80];  /* 0X2101520 */
extern int16_t 电缸故障集合;  /* 0X21000F0 */
extern int16_t 电缸状态字[80];  /* 0X21015C0 */
extern plc_bit 电缸统一手动条件;  /* 0X2100075 */
extern int32_t 皮带报警集合;  /* 0X2104BF0 */
extern int16_t 真空报警集合;  /* 0X21003B0 */
extern int16_t 给视觉上传数据;  /* 0X4026A0 */
extern double 视觉EPD检测数据;  /* 0X402820 */
extern int16_t 视觉EPD检测结果;  /* 0X402800 */
extern double 视觉EPD检测角度结果;  /* 0X4028E0 */
extern double 视觉FL检测数据;  /* 0X4028A0 */
extern int16_t 视觉FL检测结果;  /* 0X402880 */
extern double 视觉TP检测数据;  /* 0X402860 */
extern int16_t 视觉TP检测结果;  /* 0X402840 */
extern plc_bit 视觉只触发延时;  /* 0X210067D */
extern plc_bit 视觉只触发延时1;  /* 0X210067E */
extern plc_bit 视觉心跳延时;  /* 0X2100510 */
extern int16_t 视觉数据接收完成;  /* 0X4026B0 */
extern int16_t 视觉数据整合触发;  /* 0X402760 */
extern int16_t 视觉数据整合触发结果;  /* 0X402780 */
extern plc_bit 视觉结果接收延时;  /* 0X210059D */
extern int32_t 视觉软件打开;  /* 0X402580 */
extern int16_t 视觉通讯心跳;  /* 0X4025A0 */
extern plc_bit 触发HMI记录复位延时;  /* 0X210068C */
extern plc_bit 触发HMI记录复位延时1;  /* 0X210068D */
extern plc_bit 触发HMI记录复位延时2;  /* 0X210068E */
extern plc_bit 触发HMI记录复位延时3;  /* 0X210068F */
extern plc_bit 触发HMI记录复位延时4;  /* 0X210144A */
extern plc_bit 触发HMI记录复位延时5;  /* 0X210144B */
extern plc_bit 触发HMI记录复位延时6;  /* 0X210144C */
extern plc_bit 触发HMI记录复位延时7;  /* 0X210144D */
extern double 设备CT[80];  /* 0X2104250 */
extern int32_t 设备CT时间[80];  /* 0X2104110 */
extern double 设备CT浮点数[80];  /* 0X2104710 */
extern double 设备_CT[80];  /* 0X501F40 */
extern double 设备_CT时间[80];  /* 0X50B680 */
extern int16_t 轴故障集合;  /* 0X21003D0 */
extern int32_t 轴未使能集合;  /* 0X21003F0 */
extern plc_bit 过道皮带进料中延时;  /* 0X210063F */
extern plc_bit 运行延时;  /* 0X2100003 */
extern plc_bit 通道1进料皮带进料超时延时;  /* 0X210064C */
extern int32_t 驱动通讯故障集合;  /* 0X2100410 */
extern plc_bit 高低速切换延时;  /* 0X21014BC */

/* ========== 物理 IO（X 输入 / Y 输出）（264 个） ========== */
extern plc_bit X0_启动按钮;  /* 0X0 */
extern plc_bit X100_CCD检测位横向定位气缸始位;  /* 0X40 */
extern plc_bit X101_CCD检测位横向定位气缸到位;  /* 0X41 */
extern plc_bit X102_流道1上游给有料信号;  /* 0X42 */
extern plc_bit X103_流道2上游给有料信号;  /* 0X43 */
extern plc_bit X104_CCD检测位压合平移气缸始位;  /* 0X44 */
extern plc_bit X105_CCD检测位压合平移气缸到位;  /* 0X45 */
extern plc_bit X106_CCD检测位压合升降气缸始位;  /* 0X46 */
extern plc_bit X107_CCD检测位压合升降气缸到位;  /* 0X47 */
extern plc_bit X10_前安全门1;  /* 0X8 */
extern plc_bit X110_下料机械手升降气缸始位;  /* 0X48 */
extern plc_bit X111_下料机械手升降气缸到位;  /* 0X49 */
extern plc_bit X112_流道1下游要料信号;  /* 0X4A */
extern plc_bit X113_备用;  /* 0X4B */
extern plc_bit X114_流道2下游要料信号;  /* 0X4C */
extern plc_bit X115_备用;  /* 0X4D */
extern plc_bit X116_下料机械手吸盘真空负压信号;  /* 0X4E */
extern plc_bit X117_撕膜位产品检测光电2;  /* 0X4F */
extern plc_bit X11_前安全门2;  /* 0X9 */
extern plc_bit X120_下料位产品检测光电;  /* 0X50 */
extern plc_bit X121_下料位阻挡气缸始位;  /* 0X51 */
extern plc_bit X122_下料位阻挡气缸到位;  /* 0X52 */
extern plc_bit X123_下料位顶升气缸始位;  /* 0X53 */
extern plc_bit X124_下料位顶升气缸到位;  /* 0X54 */
extern plc_bit X125_CCD检测位纵向定位气缸始位;  /* 0X55 */
extern plc_bit X126_CCD检测位纵向定位气缸到位;  /* 0X56 */
extern plc_bit X127_下料位产品检测光电2;  /* 0X57 */
extern plc_bit X12_后安全门1;  /* 0XA */
extern plc_bit X133_撕膜电缸_动作中;  /* 0X5B */
extern plc_bit X135_撕膜电缸_原点复位中;  /* 0X5D */
extern plc_bit X136_撕膜电缸_到达目标位置;  /* 0X5E */
extern plc_bit X137_撕膜电缸_伺服使能中;  /* 0X5F */
extern plc_bit X13_后安全门2;  /* 0XB */
extern plc_bit X143_机器人1位抚平FPC电缸_动作中;  /* 0X63 */
extern plc_bit X145_机器人1位抚平FPC电缸_原点复位中;  /* 0X65 */
extern plc_bit X146_机器人1位抚平FPC电缸_到达目标位置;  /* 0X66 */
extern plc_bit X147_机器人1位抚平FPC电缸_伺服使能中;  /* 0X67 */
extern plc_bit X14_流道1皮带进料检测光电;  /* 0XC */
extern plc_bit X153_机器人1位抓手升降电缸_动作中;  /* 0X6B */
extern plc_bit X155_机器人1位抓手升降电缸_原点复位中;  /* 0X6D */
extern plc_bit X156_机器人1位抓手升降电缸_到达目标位置;  /* 0X6E */
extern plc_bit X157_机器人1位抓手升降电缸_伺服使能中;  /* 0X6F */
extern plc_bit X15_流道1皮带进料检测光电2;  /* 0XD */
extern plc_bit X163_机器人1位抓手平移电缸_动作中;  /* 0X73 */
extern plc_bit X165_机器人1位抓手平移电缸_原点复位中;  /* 0X75 */
extern plc_bit X166_机器人1位抓手平移电缸_到达目标位置;  /* 0X76 */
extern plc_bit X167_机器人1位抓手平移电缸_伺服使能中;  /* 0X77 */
extern plc_bit X16_流道1二段皮带进料检测光电;  /* 0XE */
extern plc_bit X170_机器人2位抚平FPC电缸_OUT0;  /* 0X78 */
extern plc_bit X173_机器人2位抚平FPC电缸_动作中;  /* 0X7B */
extern plc_bit X175_机器人2位抚平FPC电缸_原点复位中;  /* 0X7D */
extern plc_bit X176_机器人2位抚平FPC电缸_到达目标位置;  /* 0X7E */
extern plc_bit X177_机器人2位抚平FPC电缸_伺服使能中;  /* 0X7F */
extern plc_bit X17_流道1四段皮带出料检测光电;  /* 0XF */
extern plc_bit X1_停止按钮;  /* 0X1 */
extern plc_bit X200_NG下料皮带检测光电1;  /* 0X80 */
extern plc_bit X201_NG下料皮带检测光电2;  /* 0X81 */
extern plc_bit X202_机器人1爪手升降气缸始位;  /* 0X82 */
extern plc_bit X203_机器人1爪手升降气缸到位;  /* 0X83 */
extern plc_bit X204_FL侧边光源平移气缸始位;  /* 0X84 */
extern plc_bit X205_FL侧边光源平移气缸到位;  /* 0X85 */
extern plc_bit X20_撕膜位产品检测光电;  /* 0X10 */
extern plc_bit X210_机器人1程序运行中;  /* 0X88 */
extern plc_bit X211_机器人1系统报警;  /* 0X89 */
extern plc_bit X212_机器人1电池没电报警;  /* 0X8A */
extern plc_bit X213_机器人1程序暂停中;  /* 0X8B */
extern plc_bit X216_机器人1真空负压反馈;  /* 0X8E */
extern plc_bit X21_撕膜位阻挡气缸始位;  /* 0X11 */
extern plc_bit X225_机器人1任务执行完成;  /* 0X95 */
extern plc_bit X22_撕膜位阻挡气缸到位;  /* 0X12 */
extern plc_bit X230_机器人2程序运行中;  /* 0X98 */
extern plc_bit X231_机器人2系统报警;  /* 0X99 */
extern plc_bit X232_机器人2电池没电报警;  /* 0X9A */
extern plc_bit X233_机器人2程序暂停中;  /* 0X9B */
extern plc_bit X235_机器人2真空负压反馈;  /* 0X9D */
extern plc_bit X23_撕膜位顶升气缸始位;  /* 0X13 */
extern plc_bit X245_机器人2任务执行完成;  /* 0XA5 */
extern plc_bit X24_撕膜位顶升气缸到位;  /* 0X14 */
extern plc_bit X25_撕膜位横向定位气缸始位;  /* 0X15 */
extern plc_bit X26_撕膜位横向定位气缸到位;  /* 0X16 */
extern plc_bit X27_撕膜位纵向定位气缸始位;  /* 0X17 */
extern plc_bit X2_复位按钮;  /* 0X2 */
extern plc_bit X30_撕膜位纵向定位气缸到位;  /* 0X18 */
extern plc_bit X31_撕膜位FPC扶正升降气缸始位;  /* 0X19 */
extern plc_bit X32_撕膜位FPC扶正升降气缸到位;  /* 0X1A */
extern plc_bit X33_撕膜位FPC扶正平移气缸始位;  /* 0X1B */
extern plc_bit X34_撕膜位FPC扶正平移气缸到位;  /* 0X1C */
extern plc_bit X35_撕膜位FPC夹膜气缸始位;  /* 0X1D */
extern plc_bit X36_撕膜位FPC夹膜气缸到位;  /* 0X1E */
extern plc_bit X37_撕膜位FPC撕膜平移气缸始位;  /* 0X1F */
extern plc_bit X3_前急停按钮;  /* 0X3 */
extern plc_bit X40_撕膜位FPC撕膜平移气缸到位;  /* 0X20 */
extern plc_bit X41_撕膜位FPC撕膜升降气缸始位;  /* 0X21 */
extern plc_bit X42_撕膜位FPC撕膜升降气缸到位;  /* 0X22 */
extern plc_bit X43_机器人1位产品检测光电;  /* 0X23 */
extern plc_bit X44_机器人1位阻挡气缸始位;  /* 0X24 */
extern plc_bit X45_机器人1位阻挡气缸到位;  /* 0X25 */
extern plc_bit X46_机器人1位顶升气缸始位;  /* 0X26 */
extern plc_bit X47_机器人1位顶升气缸到位;  /* 0X27 */
extern plc_bit X50_机器人1位横向定位气缸始位;  /* 0X28 */
extern plc_bit X51_机器人1位横向定位气缸到位;  /* 0X29 */
extern plc_bit X52_机器人1位纵向定位气缸始位;  /* 0X2A */
extern plc_bit X53_机器人1位纵向定位气缸到位;  /* 0X2B */
extern plc_bit X54_FL夹紧气缸始位;  /* 0X2C */
extern plc_bit X55_FL夹紧气缸到位;  /* 0X2D */
extern plc_bit X56_机器人1位抚平定位气缸到位;  /* 0X2E */
extern plc_bit X57_机器人1位抚平定位气缸始位;  /* 0X2F */
extern plc_bit X5_流道2皮带出料检测光电1;  /* 0X5 */
extern plc_bit X60_机器人2位产品检测光电;  /* 0X30 */
extern plc_bit X61_机器人2位阻挡气缸始位;  /* 0X31 */
extern plc_bit X62_机器人2位阻挡气缸到位;  /* 0X32 */
extern plc_bit X63_机器人2位顶升气缸始位;  /* 0X33 */
extern plc_bit X64_机器人2位顶升气缸到位;  /* 0X34 */
extern plc_bit X65_机器人2位横向定位气缸始位;  /* 0X35 */
extern plc_bit X66_机器人2位横向定位气缸到位;  /* 0X36 */
extern plc_bit X67_机器人2位纵向定位气缸始位;  /* 0X37 */
extern plc_bit X6_流道2皮带出料检测光电2;  /* 0X6 */
extern plc_bit X70_机器人2位纵向定位气缸到位;  /* 0X38 */
extern plc_bit X71_机器人2位抚平定位气缸始位;  /* 0X39 */
extern plc_bit X72_机器人2位抚平定位气缸到位;  /* 0X3A */
extern plc_bit X73_CCD检测位产品检测光电;  /* 0X3B */
extern plc_bit X74_CCD检测位阻挡气缸始位;  /* 0X3C */
extern plc_bit X75_CCD检测位阻挡气缸到位;  /* 0X3D */
extern plc_bit X76_CCD检测位顶升气缸始位;  /* 0X3E */
extern plc_bit X77_CCD检测位顶升气缸到位;  /* 0X3F */
extern plc_bit Y0_启动按钮灯;  /* 0X80000 */
extern plc_bit Y100_CCD检测位横向定位气缸始位;  /* 0X80040 */
extern plc_bit Y101_CCD检测位横向定位气缸到位;  /* 0X80041 */
extern plc_bit Y102_流道1给上游允许放料信号;  /* 0X80042 */
extern plc_bit Y103_流道2给上游允许放料信号;  /* 0X80043 */
extern plc_bit Y104_CCD检测位压合平移气缸始位;  /* 0X80044 */
extern plc_bit Y105_CCD检测位压合平移气缸到位;  /* 0X80045 */
extern plc_bit Y106_CCD检测位压合升降气缸始位;  /* 0X80046 */
extern plc_bit Y107_CCD检测位压合升降气缸到位;  /* 0X80047 */
extern plc_bit Y10_1皮带电机启动;  /* 0X80008  撕膜位皮带 */
extern plc_bit Y110_下料机械手升降气缸始位;  /* 0X80048 */
extern plc_bit Y111_下料机械手升降气缸到位;  /* 0X80049 */
extern plc_bit Y112_下料机械手吸盘真空吸;  /* 0X8004A */
extern plc_bit Y113_下料机械手吸盘真空破;  /* 0X8004B */
extern plc_bit Y114_下料位阻挡气缸始位;  /* 0X8004C */
extern plc_bit Y115_下料位阻挡气缸到位;  /* 0X8004D */
extern plc_bit Y116_下料位顶升气缸始位;  /* 0X8004E */
extern plc_bit Y117_下料位顶升气缸到位;  /* 0X8004F */
extern plc_bit Y120_CCD检测位纵向定位气缸始位;  /* 0X80050 */
extern plc_bit Y121_CCD检测位纵向定位气缸到位;  /* 0X80051 */
extern plc_bit Y122_流道1给下游有料信号;  /* 0X80052 */
extern plc_bit Y123_机器人抓手1光源控制1;  /* 0X80053  机器人1插FL光源 */
extern plc_bit Y124_机器人抓手1光源控制2;  /* 0X80054  机器人1插EPD光源 */
extern plc_bit Y125_机器人抓手1光源控制3;  /* 0X80055  机器人1插EPD光源 */
extern plc_bit Y126_机器人抓手2光源控制1;  /* 0X80056  机器人2插TP光源 */
extern plc_bit Y127_机器人抓手2光源控制2;  /* 0X80057  机器人2插TP光源 */
extern plc_bit Y12_机器人1位皮带电机启动;  /* 0X8000A  机器人1位皮带 */
extern plc_bit Y133_撕膜电缸_原点复位;  /* 0X8005B */
extern plc_bit Y134_撕膜电缸_暂停;  /* 0X8005C */
extern plc_bit Y135_撕膜电缸_运行启动;  /* 0X8005D */
extern plc_bit Y136_撕膜电缸_报警复位;  /* 0X8005E */
extern plc_bit Y137_撕膜电缸_伺服使能ON;  /* 0X8005F */
extern plc_bit Y13_流道2出料皮带电机速度切换;  /* 0X8000B  AOI出料皮带速度切换 */
extern plc_bit Y143_机器人1位抚平FPC电缸_原点复位;  /* 0X80063 */
extern plc_bit Y144_机器人1位抚平FPC电缸_暂停;  /* 0X80064 */
extern plc_bit Y145_机器人1位抚平FPC电缸_运行启动;  /* 0X80065 */
extern plc_bit Y146_机器人1位抚平FPC电缸_报警复位;  /* 0X80066 */
extern plc_bit Y147_机器人1位抚平FPC电缸_伺服使能ON;  /* 0X80067 */
extern plc_bit Y14_机器人2位皮带电机启动;  /* 0X8000C  机器人2位皮带 */
extern plc_bit Y153_机器人1位抓手升降电缸_原点复位;  /* 0X8006B */
extern plc_bit Y154_机器人1位抓手升降电缸_暂停;  /* 0X8006C */
extern plc_bit Y155_机器人1位抓手升降电缸_运行启动;  /* 0X8006D */
extern plc_bit Y156_机器人1位抓手升降电缸_报警复位;  /* 0X8006E */
extern plc_bit Y157_机器人1位抓手升降电缸_伺服使能ON;  /* 0X8006F */
extern plc_bit Y15_流道2给下游有料信号;  /* 0X8000D */
extern plc_bit Y163_机器人1位抓手平移电缸_原点复位;  /* 0X80073 */
extern plc_bit Y164_机器人1位抓手平移电缸_暂停;  /* 0X80074 */
extern plc_bit Y165_机器人1位抓手平移电缸_运行启动;  /* 0X80075 */
extern plc_bit Y166_机器人1位抓手平移电缸_报警复位;  /* 0X80076 */
extern plc_bit Y167_机器人1位抓手平移电缸_伺服使能ON;  /* 0X80077 */
extern plc_bit Y16_AOI位皮带电机启动;  /* 0X8000E  AOI检测位皮带 */
extern plc_bit Y173_机器人2位抚平FPC电缸_原点复位;  /* 0X8007B */
extern plc_bit Y174_机器人2位抚平FPC电缸_暂停;  /* 0X8007C */
extern plc_bit Y175_机器人2位抚平FPC电缸_运行启动;  /* 0X8007D */
extern plc_bit Y176_机器人2位抚平FPC电缸_报警复位;  /* 0X8007E */
extern plc_bit Y177_机器人2位抚平FPC电缸_伺服使能ON;  /* 0X8007F */
extern plc_bit Y17_流道2出料皮带电机启动;  /* 0X8000F  AOI出料皮带 */
extern plc_bit Y1_停止按钮灯;  /* 0X80001 */
extern plc_bit Y200_机器人1位抚平定位气缸始位;  /* 0X80080 */
extern plc_bit Y201_机器人1位抚平定位气缸到位;  /* 0X80081 */
extern plc_bit Y202_机器人2位抚平定位气缸始位;  /* 0X80082 */
extern plc_bit Y203_机器人2位抚平定位气缸到位;  /* 0X80083 */
extern plc_bit Y204_机器人1爪手升降气缸始位;  /* 0X80084 */
extern plc_bit Y205_机器人1爪手升降气缸到位;  /* 0X80085 */
extern plc_bit Y206_FL侧边光源平移气缸始位;  /* 0X80086 */
extern plc_bit Y207_FL侧边光源平移气缸到位;  /* 0X80087 */
extern plc_bit Y20_流道1出料皮带电机启动;  /* 0X80010  流道1出料皮带 */
extern plc_bit Y210_机器人1紧急停止;  /* 0X80088 */
extern plc_bit Y211_机器人1暂停;  /* 0X80089 */
extern plc_bit Y212_机器人1周期停止;  /* 0X8008A */
extern plc_bit Y213_机器人1运行任务;  /* 0X8008B */
extern plc_bit Y214_机器人1报警复位;  /* 0X8008C */
extern plc_bit Y215_机器人1继续运行;  /* 0X8008D */
extern plc_bit Y216_机器人1真空吸;  /* 0X8008E */
extern plc_bit Y21_流道1第三段皮带电机启动;  /* 0X80011  流道1第三段皮带 */
extern plc_bit Y225_机器人1任务执行开始;  /* 0X80095 */
extern plc_bit Y226_机器人1爪手夹头气缸到位;  /* 0X80096 */
extern plc_bit Y22_流道1第二段皮带电机启动;  /* 0X80012  流道1第二段皮带 */
extern plc_bit Y230_机器人2紧急停止;  /* 0X80098 */
extern plc_bit Y231_机器人2暂停;  /* 0X80099 */
extern plc_bit Y232_机器人2周期停止;  /* 0X8009A */
extern plc_bit Y233_机器人2运行任务;  /* 0X8009B */
extern plc_bit Y234_机器人2报警复位;  /* 0X8009C */
extern plc_bit Y235_机器人2继续运行;  /* 0X8009D */
extern plc_bit Y236_机器人2爪手升降气缸始位;  /* 0X8009E */
extern plc_bit Y237_机器人2爪手升降气缸到位;  /* 0X8009F */
extern plc_bit Y23_流道1进料皮带电机启动;  /* 0X80013  流道1进料皮带 */
extern plc_bit Y245_机器人2任务执行开始;  /* 0X800A5 */
extern plc_bit Y246_机器人2爪手夹头气缸到位;  /* 0X800A6 */
extern plc_bit Y24_三色灯红灯;  /* 0X80014 */
extern plc_bit Y25_三色灯黄灯;  /* 0X80015 */
extern plc_bit Y26_三色灯绿灯;  /* 0X80016 */
extern plc_bit Y27_蜂鸣器;  /* 0X80017 */
extern plc_bit Y2_复位按钮灯;  /* 0X80002 */
extern plc_bit Y30_撕膜位阻挡气缸始位;  /* 0X80018 */
extern plc_bit Y31_撕膜位阻挡气缸到位;  /* 0X80019 */
extern plc_bit Y32_撕膜位顶升气缸始位;  /* 0X8001A */
extern plc_bit Y33_撕膜位顶升气缸到位;  /* 0X8001B */
extern plc_bit Y34_撕膜位横向定位气缸始位;  /* 0X8001C */
extern plc_bit Y35_撕膜位横向定位气缸到位;  /* 0X8001D */
extern plc_bit Y36_撕膜位纵向定位气缸始位;  /* 0X8001E */
extern plc_bit Y37_撕膜位纵向定位气缸到位;  /* 0X8001F */
extern plc_bit Y3_机器人2真空吸;  /* 0X80003 */
extern plc_bit Y40_撕膜位FPC扶正升降气缸始位;  /* 0X80020 */
extern plc_bit Y41_撕膜位FPC扶正升降气缸到位;  /* 0X80021 */
extern plc_bit Y42_撕膜位FPC扶正平移气缸始位;  /* 0X80022 */
extern plc_bit Y43_撕膜位FPC扶正平移气缸到位;  /* 0X80023 */
extern plc_bit Y44_撕膜位FPC夹膜气缸始位;  /* 0X80024 */
extern plc_bit Y45_撕膜位FPC夹膜气缸到位;  /* 0X80025 */
extern plc_bit Y46_撕膜位FPC撕膜平移气缸始位;  /* 0X80026 */
extern plc_bit Y47_撕膜位FPC撕膜平移气缸到位;  /* 0X80027 */
extern plc_bit Y4_废料真空;  /* 0X80004 */
extern plc_bit Y50_机器人1位阻挡气缸始位;  /* 0X80028 */
extern plc_bit Y51_机器人1位阻挡气缸到位;  /* 0X80029 */
extern plc_bit Y52_机器人1位顶升气缸始位;  /* 0X8002A */
extern plc_bit Y53_机器人1位顶升气缸到位;  /* 0X8002B */
extern plc_bit Y54_机器人1位横向定位气缸始位;  /* 0X8002C */
extern plc_bit Y55_机器人1位横向定位气缸到位;  /* 0X8002D */
extern plc_bit Y56_机器人1位纵向定位气缸始位;  /* 0X8002E */
extern plc_bit Y57_机器人1位纵向定位气缸到位;  /* 0X8002F */
extern plc_bit Y5_NG下料皮带控制;  /* 0X80005 */
extern plc_bit Y60_FL夹紧气缸始位;  /* 0X80030 */
extern plc_bit Y61_FL夹紧气缸到位;  /* 0X80031 */
extern plc_bit Y62_撕膜位FPC撕膜升降气缸始位;  /* 0X80032 */
extern plc_bit Y63_撕膜位FPC撕膜升降气缸到位;  /* 0X80033 */
extern plc_bit Y64_机器人2位阻挡气缸始位;  /* 0X80034 */
extern plc_bit Y65_机器人2位阻挡气缸到位;  /* 0X80035 */
extern plc_bit Y66_机器人2位顶升气缸始位;  /* 0X80036 */
extern plc_bit Y67_机器人2位顶升气缸到位;  /* 0X80037 */
extern plc_bit Y6_CCD检测光源控制1;  /* 0X80006 */
extern plc_bit Y70_机器人2位横向定位气缸始位;  /* 0X80038 */
extern plc_bit Y71_机器人2位横向定位气缸到位;  /* 0X80039 */
extern plc_bit Y72_机器人2位纵向定位气缸始位;  /* 0X8003A */
extern plc_bit Y73_机器人2位纵向定位气缸到位;  /* 0X8003B */
extern plc_bit Y74_CCD检测位阻挡气缸始位;  /* 0X8003C */
extern plc_bit Y75_CCD检测位阻挡气缸到位;  /* 0X8003D */
extern plc_bit Y76_CCD检测位顶升气缸始位;  /* 0X8003E */
extern plc_bit Y77_CCD检测位顶升气缸到位;  /* 0X8003F */
extern plc_bit Y7_CCD检测光源控制2;  /* 0X80007 */

