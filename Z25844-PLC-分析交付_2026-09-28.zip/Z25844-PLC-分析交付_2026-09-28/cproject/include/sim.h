#pragma once
#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

/* ============================================================================
 * 仿真侧接口（sim/ 目录）：PLC 本身不包含这些，它们只是让 C 工程能跑起来的"机械替身"。
 * ========================================================================== */
void plc_scan(void);
void plc_init(void);

/* 机械/负载仿真：把 Y 输出反馈成 X 感应，把运动指令积分成位置 */
void sim_machine_step(int32_t dt_ms);
void sim_axis_step(int32_t dt_ms);
void sim_print_state(void);
