#pragma once
#include "symbols.h"
#include "enums.h"
#include "structs.h"

/* 功能块（FB）：结构体 = 实例数据；引脚以**指针形参**传入，
   语义与 AutoShop 的引脚绑定一致 —— 绑定了外部变量就指向外部变量，
   未绑定（`-`）则指向实例自身的成员存储。 */

typedef struct {
    plc_bit IB_手自动切换;
    plc_bit HMI_启动;
    plc_bit IB_复位按钮;
    plc_bit HMI_复位;
    int16_t IF_复位延时;
    plc_bit IB_停止按钮;
    plc_bit IB_故障;
    plc_bit IB_维修请求;
    plc_bit IB_回原完成;
    int32_t IF_回原超时;
    plc_bit IB_启动按钮;
    plc_bit QB_复位提醒;
    plc_bit IB_半自动切换;
    int16_t i_pc软件联机;
    plc_bit i_x联机模式;
    plc_bit QB_手动中;
    plc_bit QB_自动暂停中;
    plc_bit QB_初始化中;
    plc_bit QB_自动中;
    plc_bit QF_设备状态;
    plc_bit QB_回原超时;
    plc_bit QB_没有整机回原;
    plc_bit QB_半自动中;
    plc_bit QB_维修中;
    plc_bit o_pc软件未打开;
    plc_bit B12100;
    plc_bit B12101;
    plc_bit B12110;
    plc_bit B12111;
    plc_bit B12112;
    plc_bit B12120;
    plc_bit B12130;
    plc_bit B12131;
    plc_bit B12140;
    plc_bit B12150;
    plc_bit B12199;
    plc_bit B12200;
    plc_bit B12300;
    plc_bit H_x时间修改按钮;
    plc_bit H_x时间修改页面;
    int16_t IN_设备状态;
    plc_bit VAR_停止;
    plc_bit VAR_启动;
    plc_bit YY;
    int32_t di密码错误计时;
    plc_bit di锁机时间;
    plc_bit var_复位;
    plc_bit x密码错误计时Q;
    plc_bit x密码错误计时R;
    plc_bit x开机跳锁机QT;
    plc_bit 回原超时;
    plc_bit 密码弹窗关闭QT;
} 设备状态_t;   /* 原 FB: 设备状态 */

typedef struct {
    int16_t i_x设备状态机;
    plc_bit i_x故障;
    plc_bit i_x报警复位;
    plc_bit i_x蜂鸣器屏蔽;
    plc_bit i_x屏蔽总气源检查;
    plc_bit i_x安全门屏蔽;
    plc_bit i_x气源常闭;
    plc_bit i_x前门禁信号常闭;
    plc_bit i_x后门禁信号常闭;
    plc_bit i_x左门禁信号常闭;
    plc_bit i_x右门禁信号常闭;
    plc_bit i_x照明;
    plc_bit i_x急停1;
    plc_bit i_x急停2;
    plc_bit i_x急停3;
    plc_bit i_x急停4;
    plc_bit i_xNG下料提示;
    plc_bit o_x气源报警;
    plc_bit o_x前门禁报警;
    plc_bit o_x后门禁报警;
    plc_bit o_x左门禁报警;
    plc_bit o_x右门禁报警;
    plc_bit o_x红灯;
    plc_bit o_x绿灯;
    plc_bit o_x黄灯;
    plc_bit o_x蜂鸣器;
    plc_bit o_x照明;
    plc_bit o_x急停1报警;
    plc_bit o_x急停2报警;
    plc_bit o_x急停3报警;
    plc_bit o_x急停4报警;
    plc_bit 后安全门延时报警;
} FB_门禁气源三色灯_t;   /* 原 FB: FB_门禁气源三色灯 */

typedef struct {
    plc_bit ix_检测信号;
    plc_bit ix_检测条件;
    plc_bit if_检测延时;
    plc_bit if_检测延时报警;
    plc_bit ix_报警屏蔽;
    plc_bit ix_复位;
    plc_bit qx_检测信号;
    plc_bit qx_检测报警;
    plc_bit vx_检测条件不满足报警;
    plc_bit vx_检测满足报警;
} FB_检测信号_t;   /* 原 FB: FB_检测信号 */

typedef struct {
    plc_bit 报警复位;
    plc_bit IP地址;
    plc_bit 端口号;
    plc_bit 连接请求;
    plc_bit 手动扫码;
    plc_bit 自动扫码;
    plc_bit 发送触发扫码数据;
    int16_t NG字符[4];
    int16_t 重扫次数;
    plc_bit err扫码NG;
    plc_bit 当前条码;
    plc_bit err接收超时;
    plc_bit err连接超时;
    int16_t NG扫码计数;
    plc_bit Socket_扫码枪;
    plc_bit 发送OK;
    plc_bit 发送长度[2];
    plc_bit 延时tt;
    plc_bit 扫码触发;
    plc_bit 扫码连接;
    plc_bit 接收err;
    plc_bit 接收完成;
    int16_t 接收的条码[20];
    plc_bit 接收超时;
    plc_bit 进行NG扫码对比;
    plc_bit 进行重扫码;
    plc_bit 连接成功;
    plc_bit 连接故障;
    plc_bit 连接超时;
} 扫码枪FB_t;   /* 原 FB: 扫码枪FB */

typedef struct {
    plc_bit IF_旧码[1];
    int16_t IF_新码[1];
    int16_t IF_检查长度;
    plc_bit IB_开始检查;
    plc_bit QB_运行OK;
    plc_bit QB_新旧码一样;
    int32_t VAR_旧码[32];
    int32_t VAR_检查同码数;
    int32_t VAR_检查长度;
    plc_bit _STB87;
    int32_t self;
} FB_扫码检测旧码_t;   /* 原 FB: FB_扫码检测旧码 */

typedef struct {
    int16_t 设备状态;
    plc_bit 故障清除;
    plc_bit 单控双控;
    plc_bit 原位感应;
    plc_bit 出位感应;
    plc_bit 原位屏蔽;
    plc_bit 出位屏蔽;
    plc_bit 半自动允许;
    plc_bit 初始化;
    plc_bit 气缸触发_HMI;
    plc_bit 控制_AUTO;
    plc_bit 半自动启动;
    plc_bit 屏蔽到位延时;
    plc_bit 报警延时;
    plc_bit 到位延时;
    plc_bit 手动条件;
    plc_bit 原位Y;
    plc_bit 出位Y;
    plc_bit 原位OK;
    plc_bit 出位OK;
    plc_bit 原位报警;
    plc_bit 出位报警;
    plc_bit QX_气缸状态改变标记;
    int16_t VI_自动状态保存;
    plc_bit VX_气缸状态标记;
    plc_bit 出位到位延时;
    plc_bit 出位延时报警;
    plc_bit 原位到位延时;
    plc_bit 原位延时报警;
    plc_bit 感应器延时[2];
    plc_bit 气缸半自动模式;
    plc_bit 气缸模式;
} 气缸_FB_t;   /* 原 FB: 气缸_FB */

typedef struct {
    plc_bit 手自动模式;
    plc_bit 停机;
    plc_bit etc状态字;
    int32_t etc当前位置;
    plc_bit etc当前速度;
    plc_bit 使能;
    plc_bit 报警复位;
    plc_bit 回原点触发;
    plc_bit 自动回原点触发;
    plc_bit 回原点完成;
    plc_bit 正向点动;
    plc_bit 反向点动;
    plc_bit 速度;
    plc_bit 加减速度;
    int32_t HMI_定位位置[32];
    plc_bit HMI_定位触发[32];
    plc_bit g_x自动定位[32];
    int16_t etc从站号;
    plc_bit HMI_点动速度;
    plc_bit HMI_点动速度修改;
    plc_bit etc控制字;
    int32_t etc目标位置;
    plc_bit etc目标速度;
    plc_bit etc加速度;
    plc_bit etc减速度;
    plc_bit etc定位推力;
    int32_t etc定位宽度;
    plc_bit etc数据标志;
    plc_bit etc启动标志;
    plc_bit etc动作方法;
    int32_t 当前位置;
    plc_bit 当前速度;
    plc_bit 使能完成;
    plc_bit 电缸报警中;
    plc_bit 电缸运动中;
    plc_bit HMI_当前位[32];
    plc_bit SDO写入中;
    plc_bit SDO写入完成;
    plc_bit SDO错误;
    plc_bit 写SDO错误码;
    plc_bit 到位延时;
    plc_bit 回原点完成延时;
    int16_t 定位组合;
    int16_t 定位组合1;
    plc_bit 定位触发延时;
    plc_bit 定位触发延时1;
    int32_t 当前位置上限;
    int32_t 当前位置下限;
    plc_bit 报警复位延时;
    plc_bit 点动速度修改;
} ETC电缸_t;   /* 原 FB: ETC电缸 */

typedef struct {
    plc_bit i_x手动模式;
    plc_bit i_x自动模式;
    plc_bit i_x皮带1故障;
    plc_bit i_x皮带2故障;
    plc_bit i_x手动皮带1单独正转;
    plc_bit i_x手动皮带2单独正转;
    plc_bit i_x手动皮带1单独反转;
    plc_bit i_x手动皮带2单独反转;
    plc_bit i_x手动一起正转运行;
    plc_bit i_x手动一起反转运行;
    plc_bit i_x自动正转运行;
    plc_bit i_x自动反转运行;
    plc_bit i_x自动高低速切换;
    int16_t 自动停止延时;
    plc_bit 皮带1正转;
    plc_bit 皮带2正转;
    plc_bit 皮带1反转方向;
    plc_bit 皮带2反转方向;
    plc_bit 皮带1速度切换;
    plc_bit 皮带2速度切换;
    plc_bit 皮带延时停;
} IO皮带FB_t;   /* 原 FB: IO皮带FB */

typedef struct {
    int16_t 设备状态;
    plc_bit 故障清除;
    plc_bit 空跑模式;
    plc_bit 真空检测;
    plc_bit 真空屏蔽;
    plc_bit 半自动允许;
    plc_bit 初始化;
    plc_bit 真空触发_HMI;
    plc_bit 开真空_AUTO;
    plc_bit 破真空_AUTO;
    plc_bit 吸真空延时;
    plc_bit 报警延时;
    plc_bit 破真空延时;
    plc_bit 自动下去吸料检测屏蔽;
    plc_bit 报警屏蔽;
    plc_bit 开真空Y;
    plc_bit 破真空Y;
    plc_bit 开真空OK;
    plc_bit 破真空OK;
    plc_bit 真空报警;
    plc_bit QX_真空状态改变标记;
    int16_t VI_自动状态保存;
    plc_bit VX_真空状态标记;
    plc_bit 半自动启动;
    plc_bit 真空半自动模式;
    plc_bit 真空吸OK延时[2];
    plc_bit 真空延时报警;
    plc_bit 真空模式;
    plc_bit 破真空OK延时;
} 真空_FB_t;   /* 原 FB: 真空_FB */

typedef struct {
    mca_axis_info_t Axis;
    plc_bit 急停;
    plc_bit 停止;
    plc_bit 半自动允许;
    int16_t 设备状态;
    plc_bit 故障复位;
    plc_bit HMI_轴使能;
    plc_bit HMI_找原;
    plc_bit HMI_手动定位触发[32];
    plc_bit HMI_JOG正转;
    plc_bit HMI_JOG反转;
    double hmi_寸动距离;
    plc_bit hmi_正寸动;
    plc_bit hmi_负寸动;
    plc_bit HMI_位置保存[24];
    double HMI_手动速度;
    double HMI_加速度;
    double HMI_减速度;
    double HMI_定位速度;
    double HMI_回原定位速度;
    int16_t 自动定位ID;
    plc_bit 定位方向;
    plc_bit JOG条件;
    plc_bit 初始化找原;
    plc_bit 自动互锁;
    plc_bit 回原偏移;
    plc_bit 自动JOG正;
    plc_bit 自动JOG负;
    double 自动JOG速度;
    double 轴绝对定位位置[32];
    plc_bit HMI_定位OK[23];
    plc_bit HMI_正限位触发;
    plc_bit HMI_负限位触发;
    plc_bit HMI_原点触发;
    plc_bit 轴报警;
    plc_bit 轴使能OK;
    plc_bit 轴BUSY;
    plc_bit 轴找原OK;
    plc_bit 负限位报警;
    plc_bit 正限位报警;
    plc_bit 相对定位OK;
    double 轴当前位置;
    plc_bit 轴没使能;
    plc_bit AbsOK;
    plc_bit Abs_Busy;
    plc_bit Abs_Err;
    plc_bit Abs_延时;
    plc_bit DIstatus;
    int16_t ErrID[2];
    plc_bit HMI_定位互锁[25];
    plc_bit HMI_手动相对触发[3];
    double HMI_正软限位;
    double HMI_负软限位;
    plc_bit HomeOK;
    plc_bit Home_Busy;
    plc_bit JOG正;
    plc_bit JOG负;
    plc_bit Jog_Busy;
    double OLD_绝对定位;
    int16_t OLD_自动ID;
    int16_t OLD_自动定位ID;
    plc_bit QX_正软限位中;
    plc_bit QX_负软限位中;
    plc_bit RelOK;
    plc_bit Rel_Busy;
    plc_bit Rel_Err;
    plc_bit Rel_延时;
    plc_bit Stop_Done;
    plc_bit Stop_Error;
    double VAR_减速度;
    double VAR_加速度;
    double VAR_手动JOG速度;
    double VAR_目标速度;
    double VAR_相对定位;
    double VAR_自动JOG速度;
    double VAR_轴绝对定位位置;
    plc_bit buffer_Busy;
    plc_bit ix_软限位使能;
    plc_bit 使能done;
    plc_bit 回原修改位置OK;
    plc_bit 回原偏移完成;
    double 当前位置上限;
    double 当前位置下限;
    plc_bit 找原中;
    plc_bit 自动id延时;
    plc_bit 自动标定;
    double 轴JOG速度;
    plc_bit 轴模式;
    plc_bit 轴相对定位中;
    plc_bit 轴绝对定位中;
} Axis_FB_t;   /* 原 FB: Axis_FB */

typedef struct {
    double IF_数据1;
    double IF_数据2;
    double IF允许波动值;
    plc_bit QB_满足;
    plc_bit QB_不满足;
    double VAR_数据1上限;
    double VAR_数据1下限;
} FB_位置比较比较_t;   /* 原 FB: FB_位置比较比较 */

void 设备状态_call(设备状态_t *self, plc_bit *IB_手自动切换, plc_bit *HMI_启动, plc_bit *IB_复位按钮, plc_bit *HMI_复位, int16_t *IF_复位延时, plc_bit *IB_停止按钮, plc_bit *IB_故障, plc_bit *IB_维修请求, plc_bit *IB_回原完成, int32_t *IF_回原超时, plc_bit *IB_启动按钮, plc_bit *QB_复位提醒, plc_bit *IB_半自动切换, int16_t *i_pc软件联机, plc_bit *i_x联机模式, plc_bit *QB_手动中, plc_bit *QB_自动暂停中, plc_bit *QB_初始化中, plc_bit *QB_自动中, plc_bit *QF_设备状态, plc_bit *QB_回原超时, plc_bit *QB_没有整机回原, plc_bit *QB_半自动中, plc_bit *QB_维修中, plc_bit *o_pc软件未打开);
void FB_门禁气源三色灯_call(FB_门禁气源三色灯_t *self, int16_t *i_x设备状态机, plc_bit *i_x故障, plc_bit *i_x报警复位, plc_bit *i_x蜂鸣器屏蔽, plc_bit *i_x屏蔽总气源检查, plc_bit *i_x安全门屏蔽, plc_bit *i_x气源常闭, plc_bit *i_x前门禁信号常闭, plc_bit *i_x后门禁信号常闭, plc_bit *i_x左门禁信号常闭, plc_bit *i_x右门禁信号常闭, plc_bit *i_x照明, plc_bit *i_x急停1, plc_bit *i_x急停2, plc_bit *i_x急停3, plc_bit *i_x急停4, plc_bit *i_xNG下料提示, plc_bit *o_x气源报警, plc_bit *o_x前门禁报警, plc_bit *o_x后门禁报警, plc_bit *o_x左门禁报警, plc_bit *o_x右门禁报警, plc_bit *o_x红灯, plc_bit *o_x绿灯, plc_bit *o_x黄灯, plc_bit *o_x蜂鸣器, plc_bit *o_x照明, plc_bit *o_x急停1报警, plc_bit *o_x急停2报警, plc_bit *o_x急停3报警, plc_bit *o_x急停4报警);
void FB_检测信号_call(FB_检测信号_t *self, plc_bit *ix_检测信号, plc_bit *ix_检测条件, plc_bit *if_检测延时, plc_bit *if_检测延时报警, plc_bit *ix_报警屏蔽, plc_bit *ix_复位, plc_bit *qx_检测信号, plc_bit *qx_检测报警);
void 扫码枪FB_call(扫码枪FB_t *self, plc_bit *报警复位, plc_bit *IP地址, plc_bit *端口号, plc_bit *连接请求, plc_bit *手动扫码, plc_bit *自动扫码, plc_bit *发送触发扫码数据, int16_t *NG字符, int16_t *重扫次数, plc_bit *err扫码NG, plc_bit *当前条码, plc_bit *err接收超时, plc_bit *err连接超时);
void FB_扫码检测旧码_call(FB_扫码检测旧码_t *self, plc_bit *IF_旧码, int16_t *IF_新码, int16_t *IF_检查长度, plc_bit *IB_开始检查, plc_bit *QB_运行OK, plc_bit *QB_新旧码一样);
void 气缸_FB_call(气缸_FB_t *self, int16_t *设备状态, plc_bit *故障清除, plc_bit *单控双控, plc_bit *原位感应, plc_bit *出位感应, plc_bit *原位屏蔽, plc_bit *出位屏蔽, plc_bit *半自动允许, plc_bit *初始化, plc_bit *气缸触发_HMI, plc_bit *控制_AUTO, plc_bit *半自动启动, plc_bit *屏蔽到位延时, plc_bit *报警延时, plc_bit *到位延时, plc_bit *手动条件, plc_bit *原位Y, plc_bit *出位Y, plc_bit *原位OK, plc_bit *出位OK, plc_bit *原位报警, plc_bit *出位报警, plc_bit *QX_气缸状态改变标记);
void ETC电缸_call(ETC电缸_t *self, plc_bit *手自动模式, plc_bit *停机, plc_bit *etc状态字, int32_t *etc当前位置, plc_bit *etc当前速度, plc_bit *使能, plc_bit *报警复位, plc_bit *回原点触发, plc_bit *自动回原点触发, plc_bit *回原点完成, plc_bit *正向点动, plc_bit *反向点动, plc_bit *速度, plc_bit *加减速度, int32_t *HMI_定位位置, plc_bit *HMI_定位触发, plc_bit *g_x自动定位, int16_t *etc从站号, plc_bit *HMI_点动速度, plc_bit *HMI_点动速度修改, plc_bit *etc控制字, int32_t *etc目标位置, plc_bit *etc目标速度, plc_bit *etc加速度, plc_bit *etc减速度, plc_bit *etc定位推力, int32_t *etc定位宽度, plc_bit *etc数据标志, plc_bit *etc启动标志, plc_bit *etc动作方法, int32_t *当前位置, plc_bit *当前速度, plc_bit *使能完成, plc_bit *电缸报警中, plc_bit *电缸运动中, plc_bit *HMI_当前位);
void IO皮带FB_call(IO皮带FB_t *self, plc_bit *i_x手动模式, plc_bit *i_x自动模式, plc_bit *i_x皮带1故障, plc_bit *i_x皮带2故障, plc_bit *i_x手动皮带1单独正转, plc_bit *i_x手动皮带2单独正转, plc_bit *i_x手动皮带1单独反转, plc_bit *i_x手动皮带2单独反转, plc_bit *i_x手动一起正转运行, plc_bit *i_x手动一起反转运行, plc_bit *i_x自动正转运行, plc_bit *i_x自动反转运行, plc_bit *i_x自动高低速切换, int16_t *自动停止延时, plc_bit *皮带1正转, plc_bit *皮带2正转, plc_bit *皮带1反转方向, plc_bit *皮带2反转方向, plc_bit *皮带1速度切换, plc_bit *皮带2速度切换);
void 真空_FB_call(真空_FB_t *self, int16_t *设备状态, plc_bit *故障清除, plc_bit *空跑模式, plc_bit *真空检测, plc_bit *真空屏蔽, plc_bit *半自动允许, plc_bit *初始化, plc_bit *真空触发_HMI, plc_bit *开真空_AUTO, plc_bit *破真空_AUTO, plc_bit *吸真空延时, plc_bit *报警延时, plc_bit *破真空延时, plc_bit *自动下去吸料检测屏蔽, plc_bit *报警屏蔽, plc_bit *开真空Y, plc_bit *破真空Y, plc_bit *开真空OK, plc_bit *破真空OK, plc_bit *真空报警);
void Axis_FB_call(Axis_FB_t *self, mca_axis_info_t *Axis, plc_bit *急停, plc_bit *停止, plc_bit *半自动允许, int16_t *设备状态, plc_bit *故障复位, plc_bit *HMI_轴使能, plc_bit *HMI_找原, plc_bit *HMI_手动定位触发, plc_bit *HMI_JOG正转, plc_bit *HMI_JOG反转, double *hmi_寸动距离, plc_bit *hmi_正寸动, plc_bit *hmi_负寸动, plc_bit *HMI_位置保存, double *HMI_手动速度, double *HMI_加速度, double *HMI_减速度, double *HMI_定位速度, double *HMI_回原定位速度, int16_t *自动定位ID, plc_bit *定位方向, plc_bit *JOG条件, plc_bit *初始化找原, plc_bit *自动互锁, plc_bit *回原偏移, plc_bit *自动JOG正, plc_bit *自动JOG负, double *自动JOG速度, double *轴绝对定位位置, plc_bit *HMI_定位OK, plc_bit *HMI_正限位触发, plc_bit *HMI_负限位触发, plc_bit *HMI_原点触发, plc_bit *轴报警, plc_bit *轴使能OK, plc_bit *轴BUSY, plc_bit *轴找原OK, plc_bit *负限位报警, plc_bit *正限位报警, plc_bit *相对定位OK, double *轴当前位置, plc_bit *轴没使能);
void FB_位置比较比较_call(FB_位置比较比较_t *self, double *IF_数据1, double *IF_数据2, double *IF允许波动值, plc_bit *QB_满足, plc_bit *QB_不满足);
