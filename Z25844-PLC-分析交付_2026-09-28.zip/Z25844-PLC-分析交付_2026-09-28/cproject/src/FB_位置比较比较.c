#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void FB_位置比较比较_call(FB_位置比较比较_t *self, double *IF_数据1, double *IF_数据2, double *IF允许波动值, plc_bit *QB_满足, plc_bit *QB_不满足) {
    /* IL:17842  DESUB IF_数据1 IF允许波动值 VAR_数据1下限 */
    if (M8000) { self->VAR_数据1下限 = (*IF_数据1) - (*IF允许波动值); }
    /* IL:17843  DEADD IF_数据1 IF允许波动值 VAR_数据1上限 */
    if (M8000) { self->VAR_数据1上限 = (*IF_数据1) + (*IF允许波动值); }
    /* IL:17848  OUT QB_满足 */
    if (((M8000) && (((double)((*IF_数据2)) >= (double)(self->VAR_数据1下限)))) && (((double)((*IF_数据2)) <= (double)(self->VAR_数据1上限)))) { (*QB_满足) = (((M8000) && (((double)((*IF_数据2)) >= (double)(self->VAR_数据1下限)))) && (((double)((*IF_数据2)) <= (double)(self->VAR_数据1上限)))); }
    /* IL:17853  OUT QB_不满足 */
    if ((M8000) && (((M8000) && (((double)((*IF_数据2)) < (double)(self->VAR_数据1下限)))) && (((double)((*IF_数据2)) > (double)(self->VAR_数据1上限))))) { (*QB_不满足) = ((M8000) && (((M8000) && (((double)((*IF_数据2)) < (double)(self->VAR_数据1下限)))) && (((double)((*IF_数据2)) > (double)(self->VAR_数据1上限))))); }
}
