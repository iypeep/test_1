#include "plc.h"

int32_t dt_ms = 1;

void TON(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt) {
    if (rst) { if (et) *et = 0; if (q) *q = 0; return; }
    if (cond) {
        if (et) { if (*et < pt) *et += dt; if (*et >= pt && q) *q = 1; }
        else if (q && pt <= 0) *q = 1;
    } else { if (et) *et = 0; if (q) *q = 0; }
}

void TACC(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt) {
    if (rst) { if (et) *et = 0; if (q) *q = 0; return; }
    if (cond && et) { if (*et < pt) *et += dt; if (*et >= pt && q) *q = 1; }
}

void BLKMOV(void *dst, void *src, int n) { memmove(dst, src, (size_t)n * sizeof(plc_word)); }
void BLKMOV32(void *dst, void *src, int n) { memmove(dst, src, (size_t)n * sizeof(plc_dword)); }
void FILL(void *dst, int32_t v, int n) { for (int i = 0; i < n; i++) ((plc_word *)dst)[i] = (plc_word)v; }
void FILLB(void *dst, int v, int n) { memset(dst, v, (size_t)n); }
int16_t DIV16(int32_t a, int32_t b) { return b ? (int16_t)(a / b) : 0; }
int32_t DIV32(int32_t a, int32_t b) { return b ? (a / b) : 0; }
double  DIVF(double a, double b) { return (b != 0.0) ? (a / b) : 0.0; }
int16_t MOD16(int32_t a, int32_t b) { return b ? (int16_t)(a % b) : 0; }
int32_t MOD32(int32_t a, int32_t b) { return b ? (a % b) : 0; }
void FILL32(void *dst, int32_t v, int n) { for (int i = 0; i < n; i++) ((plc_dword *)dst)[i] = v; }
void WSHIFT(void *dst, int n, int32_t v) {
    plc_word *p = (plc_word *)dst;
    for (int i = 0; i < n - 1; i++) p[i] = p[i + 1];
    if (n > 0) p[n - 1] = (plc_word)v;
}
void STRCPY(void *dst, const char *src) { strcpy((char *)dst, src); }
int  STRLEN(const void *src) { return (int)strlen((const char *)src); }
void WTODW(void *dw, void *w, int n) { for (int i = 0; i < n; i++) ((plc_dword *)dw)[i] = (plc_dword)((plc_word *)w)[i]; }
int32_t PACK_BITS(void *bitbase, int n) {
    int32_t v = 0; plc_bit *b = (plc_bit *)bitbase;
    for (int i = 0; i < n; i++) if (b[i]) v |= (1 << i);
    return v;
}
void UNPACK_BITS(void *bitbase, int32_t v, int n) {
    plc_bit *b = (plc_bit *)bitbase;
    for (int i = 0; i < n; i++) b[i] = (plc_bit)((v >> i) & 1);
}
int32_t PACK_BITS32(void *bitbase, int n) { return PACK_BITS(bitbase, n); }
void UNPACK_BITS32(void *bitbase, int32_t v, int n) { UNPACK_BITS(bitbase, v, n); }
void RTC_READ(void *dst) { (void)dst; }
void RTC_WRITE(void *src) { (void)src; }
void PLS_(plc_bit *y) { if (y) *y = 1; }
