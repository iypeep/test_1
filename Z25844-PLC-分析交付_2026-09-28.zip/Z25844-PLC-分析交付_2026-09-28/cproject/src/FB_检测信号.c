#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void FB_检测信号_call(FB_检测信号_t *self, plc_bit *ix_检测信号, plc_bit *ix_检测条件, plc_bit *if_检测延时, plc_bit *if_检测延时报警, plc_bit *ix_报警屏蔽, plc_bit *ix_复位, plc_bit *qx_检测信号, plc_bit *qx_检测报警) {
    /* IL:8001  TONR if_检测延时 - qx_检测信号 - */
    TON(NULL, NULL, (*if_检测延时), (((M8000) && ((*ix_检测信号))) && ((*ix_检测条件))), ((*qx_检测信号)), dt_ms);
    /* IL:8007  TONR if_检测延时报警 - vx_检测条件不满足报警 - */
    TON(NULL, NULL, (*if_检测延时报警), (((((M8000) && (!((*ix_报警屏蔽)))) && (!((*ix_复位)))) && ((*ix_检测信号))) && (!((*ix_检测条件)))), (self->vx_检测条件不满足报警), dt_ms);
    /* IL:8013  TONR if_检测延时报警 - vx_检测满足报警 - */
    TON(NULL, NULL, (*if_检测延时报警), (((((M8000) && (!((*ix_报警屏蔽)))) && (!((*ix_复位)))) && (!((*ix_检测信号)))) && ((*ix_检测条件))), (self->vx_检测满足报警), dt_ms);
    /* IL:8080  SET qx_检测报警 */
    if ((M8000) && ((self->vx_检测条件不满足报警) || (self->vx_检测满足报警))) { (*qx_检测报警) = 1; }
    /* IL:8020  RST vx_检测满足报警 */
    if ((*ix_复位)) { self->vx_检测满足报警 = 0; }
    /* IL:8021  RST vx_检测满足报警 */
    if ((*ix_复位)) { self->vx_检测满足报警 = 0; }
}
