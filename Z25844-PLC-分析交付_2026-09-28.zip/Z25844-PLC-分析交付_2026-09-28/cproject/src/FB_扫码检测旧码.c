#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void FB_扫码检测旧码_call(FB_扫码检测旧码_t *self, plc_bit *IF_旧码, int16_t *IF_新码, int16_t *IF_检查长度, plc_bit *IB_开始检查, plc_bit *QB_运行OK, plc_bit *QB_新旧码一样) {
    static plc_bit e1 = 0;   /* 边沿: re */

    /* IL:8094  BMOV IF_旧码[0] VAR_旧码[0] K20 */
    if (M8000) { BLKMOV(&self->VAR_旧码[0], &IF_旧码[0], 20); }
    /* IL:8095  RST QB_新旧码一样 */
    if (M8000) { (*QB_新旧码一样) = 0; }
    /* IL:8097  RST QB_新旧码一样 */
    if (!((*IB_开始检查))) { (*QB_新旧码一样) = 0; }
    /* IL:8100  EXECUTE _STB87 */
    if ((RE(&e1, (*IB_开始检查))) && (((IF_新码[0]) != (28494)))) { _STB87(self, IF_新码, IF_检查长度); }
    /* IL:8103  OUT QB_新旧码一样 */
    if (((*IB_开始检查)) && (((self->VAR_检查同码数) == ((*IF_检查长度))))) { (*QB_新旧码一样) = (((*IB_开始检查)) && (((self->VAR_检查同码数) == ((*IF_检查长度))))); }
    /* IL:8106  OUT QB_运行OK */
    if (((*IB_开始检查)) && (((self->VAR_检查同码数) != ((*IF_检查长度))))) { (*QB_运行OK) = (((*IB_开始检查)) && (((self->VAR_检查同码数) != ((*IF_检查长度))))); }
}
