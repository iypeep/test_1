#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void SBR_A9_来料检测(void) {
    if (!(M8000)) { /* IL:4922  CALL_FB FB_检测信号 来料检测0 - M8000 HMI_来料检测有效延时[0] HMI_来料检测延时报警[0] HMI_来料检测报警屏蔽[0] HMI_故障清除 - HMI_检测来料报警[0] */
        FB_检测信号_call(&来料检测0, &来料检测0.ix_检测信号, &M8000, &HMI_来料检测有效延时[0], &HMI_来料检测延时报警[0], &HMI_来料检测报警屏蔽[0], &HMI_故障清除, &来料检测0.qx_检测信号, &HMI_检测来料报警[0]); }
}
