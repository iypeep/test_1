#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void SBR_CT产能(void) {
    static plc_bit e1 = 0;   /* 边沿: re */
    static plc_bit e2 = 0;   /* 边沿: re */
    static plc_bit e3 = 0;   /* 边沿: re */
    static plc_bit e4 = 0;   /* 边沿: re */
    static plc_bit e5 = 0;   /* 边沿: re */
    static plc_bit e6 = 0;   /* 边沿: re */
    static plc_bit e7 = 0;   /* 边沿: re */
    static plc_bit e8 = 0;   /* 边沿: re */
    static plc_bit e9 = 0;   /* 边沿: re */
    static plc_bit e10 = 0;   /* 边沿: re */
    static plc_bit e11 = 0;   /* 边沿: re */
    static plc_bit e12 = 0;   /* 边沿: re */
    static plc_bit e13 = 0;   /* 边沿: re */
    static plc_bit e14 = 0;   /* 边沿: re */
    static plc_bit e15 = 0;   /* 边沿: re */
    static plc_bit e16 = 0;   /* 边沿: re */
    static plc_bit e17 = 0;   /* 边沿: re */
    static plc_bit e18 = 0;   /* 边沿: re */
    static plc_bit e19 = 0;   /* 边沿: re */
    static plc_bit e20 = 0;   /* 边沿: re */
    static plc_bit e21 = 0;   /* 边沿: re */
    static plc_bit e22 = 0;   /* 边沿: re */
    static plc_bit e23 = 0;   /* 边沿: re */
    static plc_bit e24 = 0;   /* 边沿: re */
    static plc_bit e25 = 0;   /* 边沿: re */
    static plc_bit e26 = 0;   /* 边沿: re */
    static plc_bit e27 = 0;   /* 边沿: re */
    static plc_bit e28 = 0;   /* 边沿: re */
    static plc_bit e29 = 0;   /* 边沿: re */
    static plc_bit e30 = 0;   /* 边沿: re */
    static plc_bit e31 = 0;   /* 边沿: re */
    static plc_bit e32 = 0;   /* 边沿: re */
    static plc_bit e33 = 0;   /* 边沿: re */
    static plc_bit e34 = 0;   /* 边沿: re */
    static plc_bit e35 = 0;   /* 边沿: re */
    static plc_bit e36 = 0;   /* 边沿: re */
    static plc_bit e37 = 0;   /* 边沿: re */
    static plc_bit e38 = 0;   /* 边沿: re */
    static plc_bit e39 = 0;   /* 边沿: re */
    static plc_bit e40 = 0;   /* 边沿: re */
    static plc_bit e41 = 0;   /* 边沿: re */
    static plc_bit e42 = 0;   /* 边沿: re */
    static plc_bit e43 = 0;   /* 边沿: re */
    static plc_bit e44 = 0;   /* 边沿: re */
    static plc_bit e45 = 0;   /* 边沿: re */
    static plc_bit e46 = 0;   /* 边沿: re */
    static plc_bit e47 = 0;   /* 边沿: re */
    static plc_bit e48 = 0;   /* 边沿: re */
    static plc_bit e49 = 0;   /* 边沿: re */
    static plc_bit e50 = 0;   /* 边沿: re */
    static plc_bit e51 = 0;   /* 边沿: re */
    static plc_bit e52 = 0;   /* 边沿: re */
    static plc_bit e53 = 0;   /* 边沿: re */
    static plc_bit e54 = 0;   /* 边沿: re */
    static plc_bit e55 = 0;   /* 边沿: re */
    static plc_bit e56 = 0;   /* 边沿: re */
    static plc_bit e57 = 0;   /* 边沿: re */
    static plc_bit e58 = 0;   /* 边沿: re */
    static plc_bit e59 = 0;   /* 边沿: re */
    static plc_bit e60 = 0;   /* 边沿: re */
    static plc_bit e61 = 0;   /* 边沿: re */
    static plc_bit e62 = 0;   /* 边沿: re */
    static plc_bit e63 = 0;   /* 边沿: re */
    static plc_bit e64 = 0;   /* 边沿: re */
    static plc_bit e65 = 0;   /* 边沿: re */
    static plc_bit e66 = 0;   /* 边沿: re */
    static plc_bit e67 = 0;   /* 边沿: re */
    static plc_bit e68 = 0;   /* 边沿: re */
    static plc_bit e69 = 0;   /* 边沿: re */
    static plc_bit e70 = 0;   /* 边沿: re */
    static plc_bit e71 = 0;   /* 边沿: re */
    static plc_bit e72 = 0;   /* 边沿: re */
    static plc_bit e73 = 0;   /* 边沿: re */
    static plc_bit e74 = 0;   /* 边沿: re */
    static plc_bit e75 = 0;   /* 边沿: re */
    static plc_bit e76 = 0;   /* 边沿: re */
    static plc_bit e77 = 0;   /* 边沿: re */
    static plc_bit e78 = 0;   /* 边沿: re */
    static plc_bit e79 = 0;   /* 边沿: re */
    static plc_bit e80 = 0;   /* 边沿: re */
    static plc_bit e81 = 0;   /* 边沿: re */
    static plc_bit e82 = 0;   /* 边沿: re */
    static plc_bit e83 = 0;   /* 边沿: re */
    static plc_bit e84 = 0;   /* 边沿: re */
    static plc_bit e85 = 0;   /* 边沿: re */
    static plc_bit e86 = 0;   /* 边沿: re */
    static plc_bit e87 = 0;   /* 边沿: re */
    static plc_bit e88 = 0;   /* 边沿: re */
    static plc_bit e89 = 0;   /* 边沿: re */
    static plc_bit e90 = 0;   /* 边沿: re */
    static plc_bit e91 = 0;   /* 边沿: re */
    static plc_bit e92 = 0;   /* 边沿: re */
    static plc_bit e93 = 0;   /* 边沿: re */
    static plc_bit e94 = 0;   /* 边沿: re */
    static plc_bit e95 = 0;   /* 边沿: re */
    static plc_bit e96 = 0;   /* 边沿: re */
    static plc_bit e97 = 0;   /* 边沿: re */
    static plc_bit e98 = 0;   /* 边沿: re */
    static plc_bit e99 = 0;   /* 边沿: re */
    static plc_bit e100 = 0;   /* 边沿: re */
    static plc_bit e101 = 0;   /* 边沿: re */
    static plc_bit e102 = 0;   /* 边沿: re */
    static plc_bit e103 = 0;   /* 边沿: re */
    static plc_bit e104 = 0;   /* 边沿: re */
    static plc_bit e105 = 0;   /* 边沿: re */
    static plc_bit e106 = 0;   /* 边沿: re */
    static plc_bit e107 = 0;   /* 边沿: re */
    static plc_bit e108 = 0;   /* 边沿: re */
    static plc_bit e109 = 0;   /* 边沿: re */
    static plc_bit e110 = 0;   /* 边沿: re */
    static plc_bit e111 = 0;   /* 边沿: re */
    static plc_bit e112 = 0;   /* 边沿: re */
    static plc_bit e113 = 0;   /* 边沿: re */
    static plc_bit e114 = 0;   /* 边沿: re */

    /* IL:4927  RST CT计时开始[0] */
    if (RE(&e1, !(g_xct计时开始[0]))) { CT计时开始[0] = 0; }
    /* IL:4930  TACR K9999999 CT复位[0] - 设备CT时间[0] */
    TACC(&CT复位[0], &设备CT时间[0], 9999999, ((设备状态机.QB_自动中) && (CT计时开始[0])), (0), dt_ms);
    /* IL:4933  DMOV 设备CT时间[0] 设备CT[0] */
    if (RE(&e2, !(CT计时开始[0]))) { 设备CT[0] = 设备CT时间[0]; }
    /* IL:4934  DFLT 设备CT[0] 设备CT浮点数[0] */
    if (RE(&e2, !(CT计时开始[0]))) { 设备CT浮点数[0] = (double)(设备CT[0]); }
    /* IL:4935  DEDIV 设备CT浮点数[0] E1000.0 设备_CT[0] */
    if (RE(&e2, !(CT计时开始[0]))) { 设备_CT[0] = DIVF(设备CT浮点数[0], 1000.0); }
    /* IL:4936  DEDIV 设备_CT[0] E4 设备_CT时间[0] */
    if (RE(&e2, !(CT计时开始[0]))) { 设备_CT时间[0] = DIVF(设备_CT[0], 4.0); }
    /* IL:4937  OUT CT复位[0] */
    if (RE(&e2, !(CT计时开始[0]))) { CT复位[0] = (RE(&e2, !(CT计时开始[0]))); }
    /* IL:4923  SET CT计时开始[0] */
    if (RE(&e3, g_xct计时开始[0])) { CT计时开始[0] = 1; }
    /* IL:4943  RST CT计时开始[1] */
    if (RE(&e4, !(g_xct计时开始[1]))) { CT计时开始[1] = 0; }
    /* IL:4946  TACR K9999999 CT复位[1] - 设备CT时间[1] */
    TACC(&CT复位[1], &设备CT时间[1], 9999999, ((设备状态机.QB_自动中) && (CT计时开始[1])), (0), dt_ms);
    /* IL:4949  DMOV 设备CT时间[1] 设备CT[1] */
    if (RE(&e5, !(CT计时开始[1]))) { 设备CT[1] = 设备CT时间[1]; }
    /* IL:4950  DFLT 设备CT[1] 设备CT浮点数[1] */
    if (RE(&e5, !(CT计时开始[1]))) { 设备CT浮点数[1] = (double)(设备CT[1]); }
    /* IL:4951  DEDIV 设备CT浮点数[1] E1000.0 设备_CT[1] */
    if (RE(&e5, !(CT计时开始[1]))) { 设备_CT[1] = DIVF(设备CT浮点数[1], 1000.0); }
    /* IL:4952  DEDIV 设备_CT[1] E4 设备_CT时间[1] */
    if (RE(&e5, !(CT计时开始[1]))) { 设备_CT时间[1] = DIVF(设备_CT[1], 4.0); }
    /* IL:4953  OUT CT复位[1] */
    if (RE(&e5, !(CT计时开始[1]))) { CT复位[1] = (RE(&e5, !(CT计时开始[1]))); }
    /* IL:4924  SET CT计时开始[1] */
    if (RE(&e6, g_xct计时开始[1])) { CT计时开始[1] = 1; }
    /* IL:4959  RST CT计时开始[2] */
    if (RE(&e7, !(g_xct计时开始[2]))) { CT计时开始[2] = 0; }
    /* IL:4962  TACR K9999999 CT复位[2] - 设备CT时间[2] */
    TACC(&CT复位[2], &设备CT时间[2], 9999999, ((设备状态机.QB_自动中) && (CT计时开始[2])), (0), dt_ms);
    /* IL:4965  DMOV 设备CT时间[2] 设备CT[2] */
    if (RE(&e8, !(CT计时开始[2]))) { 设备CT[2] = 设备CT时间[2]; }
    /* IL:4966  DFLT 设备CT[2] 设备CT浮点数[2] */
    if (RE(&e8, !(CT计时开始[2]))) { 设备CT浮点数[2] = (double)(设备CT[2]); }
    /* IL:4967  DEDIV 设备CT浮点数[2] E1000.0 设备_CT[2] */
    if (RE(&e8, !(CT计时开始[2]))) { 设备_CT[2] = DIVF(设备CT浮点数[2], 1000.0); }
    /* IL:4968  DEDIV 设备_CT[2] E4 设备_CT时间[2] */
    if (RE(&e8, !(CT计时开始[2]))) { 设备_CT时间[2] = DIVF(设备_CT[2], 4.0); }
    /* IL:4969  OUT CT复位[2] */
    if (RE(&e8, !(CT计时开始[2]))) { CT复位[2] = (RE(&e8, !(CT计时开始[2]))); }
    /* IL:4940  SET CT计时开始[2] */
    if (RE(&e9, g_xct计时开始[2])) { CT计时开始[2] = 1; }
    /* IL:4975  RST CT计时开始[3] */
    if (RE(&e10, !(g_xct计时开始[3]))) { CT计时开始[3] = 0; }
    /* IL:4978  TACR K9999999 CT复位[3] - 设备CT时间[3] */
    TACC(&CT复位[3], &设备CT时间[3], 9999999, ((设备状态机.QB_自动中) && (CT计时开始[3])), (0), dt_ms);
    /* IL:4981  DMOV 设备CT时间[3] 设备CT[3] */
    if (RE(&e11, !(CT计时开始[3]))) { 设备CT[3] = 设备CT时间[3]; }
    /* IL:4982  DFLT 设备CT[3] 设备CT浮点数[3] */
    if (RE(&e11, !(CT计时开始[3]))) { 设备CT浮点数[3] = (double)(设备CT[3]); }
    /* IL:4983  DEDIV 设备CT浮点数[3] E1000.0 设备_CT[3] */
    if (RE(&e11, !(CT计时开始[3]))) { 设备_CT[3] = DIVF(设备CT浮点数[3], 1000.0); }
    /* IL:4984  DEDIV 设备_CT[3] E4 设备_CT时间[3] */
    if (RE(&e11, !(CT计时开始[3]))) { 设备_CT时间[3] = DIVF(设备_CT[3], 4.0); }
    /* IL:4985  OUT CT复位[3] */
    if (RE(&e11, !(CT计时开始[3]))) { CT复位[3] = (RE(&e11, !(CT计时开始[3]))); }
    /* IL:4956  SET CT计时开始[3] */
    if (RE(&e12, g_xct计时开始[3])) { CT计时开始[3] = 1; }
    /* IL:4991  RST CT计时开始[4] */
    if (RE(&e13, !(g_xct计时开始[4]))) { CT计时开始[4] = 0; }
    /* IL:4994  TACR K9999999 CT复位[4] - 设备CT时间[4] */
    TACC(&CT复位[4], &设备CT时间[4], 9999999, ((设备状态机.QB_自动中) && (CT计时开始[4])), (0), dt_ms);
    /* IL:4997  DMOV 设备CT时间[4] 设备CT[4] */
    if (RE(&e14, !(CT计时开始[4]))) { 设备CT[4] = 设备CT时间[4]; }
    /* IL:4998  DFLT 设备CT[4] 设备CT浮点数[4] */
    if (RE(&e14, !(CT计时开始[4]))) { 设备CT浮点数[4] = (double)(设备CT[4]); }
    /* IL:4999  DEDIV 设备CT浮点数[4] E1000.0 设备_CT[4] */
    if (RE(&e14, !(CT计时开始[4]))) { 设备_CT[4] = DIVF(设备CT浮点数[4], 1000.0); }
    /* IL:5000  DEDIV 设备_CT[4] E4 设备_CT时间[4] */
    if (RE(&e14, !(CT计时开始[4]))) { 设备_CT时间[4] = DIVF(设备_CT[4], 4.0); }
    /* IL:5001  OUT CT复位[4] */
    if (RE(&e14, !(CT计时开始[4]))) { CT复位[4] = (RE(&e14, !(CT计时开始[4]))); }
    /* IL:4972  SET CT计时开始[4] */
    if (RE(&e15, g_xct计时开始[4])) { CT计时开始[4] = 1; }
    /* IL:5006  MOV K8 i白班上班时间 */
    if (M8000) { i白班上班时间 = 8; }
    /* IL:5007  MOV K20 i白班下班时间 */
    if (M8000) { i白班下班时间 = 20; }
    /* IL:5008  MOV K20 i夜班上班时间 */
    if (M8000) { i夜班上班时间 = 20; }
    /* IL:5009  MOV K8 i夜班下班时间 */
    if (M8000) { i夜班下班时间 = 8; }
    /* IL:5011  TRD 当前时间 */
    if (M8000) { RTC_READ(&当前时间); }
    /* IL:5013  CALL_FB FB_产能 产能CT 当前时间 h_x总产能清零 HMI当天产能清零 i白班上班时间 i白班下班时间 i夜班上班时间 i夜班下班时间 产能.ib_投料信号 OK数量 NG数量 当天小时产能 昨天小时产能 前天小时产能 产能.od_设备运行时间_时 产能.od_设备运行时间_分 产能.od_设备运行时间_秒 产能.od_设备待机时间_时 产能.od_设备待机时间_分 产能.od_设备待机时间_秒 产能.of_设备开机率 h_f总产能 h_f总OK数 h_f总NG数 h_f总良率 */
    /* 注：FB「FB_产能」本体未包含在本工程编译输出中（未实例化到 C） */
    /* IL:5015  DADD 当天小时产能.od_夜班产能总产量 当天小时产能.od_白班产能总产量 当天总产能 */
    if (M8000) { 当天总产能 = 当天小时产能.od_夜班产能总产量 + 当天小时产能.od_白班产能总产量; }
    /* IL:5016  DADD 当天小时产能.od_夜班产能OK产量 当天小时产能.od_白班产能OK产量 当天OK数 */
    if (M8000) { 当天OK数 = 当天小时产能.od_夜班产能OK产量 + 当天小时产能.od_白班产能OK产量; }
    /* IL:5017  DMUL 当天OK数 K100 中转1 */
    if (M8000) { 中转1 = 当天OK数 * 100; }
    /* IL:5018  DDIV 中转1 当天总产能 中转 */
    if (M8000) { 中转 = DIV32(中转1, 当天总产能); }
    /* IL:5019  DMUL 中转 K1 当天良率 */
    if (M8000) { 当天良率 = 中转 * 1; }
    /* IL:5022  RST g_x机器人1ct开始[0] */
    if (RE(&e16, !(g_x机器人1ct细分计时[0]))) { g_x机器人1ct开始[0] = 0; }
    /* IL:5025  TACR K9999999 机器人1CT复位[0] - 机器人1设备CT时间[0] */
    TACC(&机器人1CT复位[0], &机器人1设备CT时间[0], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[0])), (0), dt_ms);
    /* IL:5028  DMOV 机器人1设备CT时间[0] 机器人1设备CT[0] */
    if (RE(&e17, !(g_x机器人1ct开始[0]))) { 机器人1设备CT[0] = 机器人1设备CT时间[0]; }
    /* IL:5029  DFLT 机器人1设备CT[0] 机器人1设备CT浮点数[0] */
    if (RE(&e17, !(g_x机器人1ct开始[0]))) { 机器人1设备CT浮点数[0] = (double)(机器人1设备CT[0]); }
    /* IL:5030  DEDIV 机器人1设备CT浮点数[0] E1000.0 机器人1设备_CT[0] */
    if (RE(&e17, !(g_x机器人1ct开始[0]))) { 机器人1设备_CT[0] = DIVF(机器人1设备CT浮点数[0], 1000.0); }
    /* IL:5031  DEDIV 机器人1设备_CT[0] E4 机器人1设备_CT时间[0] */
    if (RE(&e17, !(g_x机器人1ct开始[0]))) { 机器人1设备_CT时间[0] = DIVF(机器人1设备_CT[0], 4.0); }
    /* IL:5032  OUT 机器人1CT复位[0] */
    if (RE(&e17, !(g_x机器人1ct开始[0]))) { 机器人1CT复位[0] = (RE(&e17, !(g_x机器人1ct开始[0]))); }
    /* IL:4988  SET g_x机器人1ct开始[0] */
    if (RE(&e18, g_x机器人1ct细分计时[0])) { g_x机器人1ct开始[0] = 1; }
    /* IL:5038  RST g_x机器人1ct开始[1] */
    if (RE(&e19, !(g_x机器人1ct细分计时[1]))) { g_x机器人1ct开始[1] = 0; }
    /* IL:5041  TACR K9999999 机器人1CT复位[1] - 机器人1设备CT时间[1] */
    TACC(&机器人1CT复位[1], &机器人1设备CT时间[1], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[1])), (0), dt_ms);
    /* IL:5044  DMOV 机器人1设备CT时间[1] 机器人1设备CT[1] */
    if (RE(&e20, !(g_x机器人1ct开始[1]))) { 机器人1设备CT[1] = 机器人1设备CT时间[1]; }
    /* IL:5045  DFLT 机器人1设备CT[1] 机器人1设备CT浮点数[1] */
    if (RE(&e20, !(g_x机器人1ct开始[1]))) { 机器人1设备CT浮点数[1] = (double)(机器人1设备CT[1]); }
    /* IL:5046  DEDIV 机器人1设备CT浮点数[1] E1000.0 机器人1设备_CT[1] */
    if (RE(&e20, !(g_x机器人1ct开始[1]))) { 机器人1设备_CT[1] = DIVF(机器人1设备CT浮点数[1], 1000.0); }
    /* IL:5047  DEDIV 机器人1设备_CT[1] E4 机器人1设备_CT时间[1] */
    if (RE(&e20, !(g_x机器人1ct开始[1]))) { 机器人1设备_CT时间[1] = DIVF(机器人1设备_CT[1], 4.0); }
    /* IL:5048  OUT 机器人1CT复位[1] */
    if (RE(&e20, !(g_x机器人1ct开始[1]))) { 机器人1CT复位[1] = (RE(&e20, !(g_x机器人1ct开始[1]))); }
    /* IL:5004  SET g_x机器人1ct开始[1] */
    if (RE(&e21, g_x机器人1ct细分计时[1])) { g_x机器人1ct开始[1] = 1; }
    /* IL:5054  RST g_x机器人1ct开始[2] */
    if (RE(&e22, !(g_x机器人1ct细分计时[2]))) { g_x机器人1ct开始[2] = 0; }
    /* IL:5057  TACR K9999999 机器人1CT复位[2] - 机器人1设备CT时间[2] */
    TACC(&机器人1CT复位[2], &机器人1设备CT时间[2], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[2])), (0), dt_ms);
    /* IL:5060  DMOV 机器人1设备CT时间[2] 机器人1设备CT[2] */
    if (RE(&e23, !(g_x机器人1ct开始[2]))) { 机器人1设备CT[2] = 机器人1设备CT时间[2]; }
    /* IL:5061  DFLT 机器人1设备CT[2] 机器人1设备CT浮点数[2] */
    if (RE(&e23, !(g_x机器人1ct开始[2]))) { 机器人1设备CT浮点数[2] = (double)(机器人1设备CT[2]); }
    /* IL:5062  DEDIV 机器人1设备CT浮点数[2] E1000.0 机器人1设备_CT[2] */
    if (RE(&e23, !(g_x机器人1ct开始[2]))) { 机器人1设备_CT[2] = DIVF(机器人1设备CT浮点数[2], 1000.0); }
    /* IL:5063  DEDIV 机器人1设备_CT[2] E4 机器人1设备_CT时间[2] */
    if (RE(&e23, !(g_x机器人1ct开始[2]))) { 机器人1设备_CT时间[2] = DIVF(机器人1设备_CT[2], 4.0); }
    /* IL:5064  OUT 机器人1CT复位[2] */
    if (RE(&e23, !(g_x机器人1ct开始[2]))) { 机器人1CT复位[2] = (RE(&e23, !(g_x机器人1ct开始[2]))); }
    /* IL:5035  SET g_x机器人1ct开始[2] */
    if (RE(&e24, g_x机器人1ct细分计时[2])) { g_x机器人1ct开始[2] = 1; }
    /* IL:5070  RST g_x机器人1ct开始[3] */
    if (RE(&e25, !(g_x机器人1ct细分计时[3]))) { g_x机器人1ct开始[3] = 0; }
    /* IL:5073  TACR K9999999 机器人1CT复位[3] - 机器人1设备CT时间[3] */
    TACC(&机器人1CT复位[3], &机器人1设备CT时间[3], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[3])), (0), dt_ms);
    /* IL:5076  DMOV 机器人1设备CT时间[3] 机器人1设备CT[3] */
    if (RE(&e26, !(g_x机器人1ct开始[3]))) { 机器人1设备CT[3] = 机器人1设备CT时间[3]; }
    /* IL:5077  DFLT 机器人1设备CT[3] 机器人1设备CT浮点数[3] */
    if (RE(&e26, !(g_x机器人1ct开始[3]))) { 机器人1设备CT浮点数[3] = (double)(机器人1设备CT[3]); }
    /* IL:5078  DEDIV 机器人1设备CT浮点数[3] E1000.0 机器人1设备_CT[3] */
    if (RE(&e26, !(g_x机器人1ct开始[3]))) { 机器人1设备_CT[3] = DIVF(机器人1设备CT浮点数[3], 1000.0); }
    /* IL:5079  DEDIV 机器人1设备_CT[3] E4 机器人1设备_CT时间[3] */
    if (RE(&e26, !(g_x机器人1ct开始[3]))) { 机器人1设备_CT时间[3] = DIVF(机器人1设备_CT[3], 4.0); }
    /* IL:5080  OUT 机器人1CT复位[3] */
    if (RE(&e26, !(g_x机器人1ct开始[3]))) { 机器人1CT复位[3] = (RE(&e26, !(g_x机器人1ct开始[3]))); }
    /* IL:5051  SET g_x机器人1ct开始[3] */
    if (RE(&e27, g_x机器人1ct细分计时[3])) { g_x机器人1ct开始[3] = 1; }
    /* IL:5086  RST g_x机器人1ct开始[4] */
    if (RE(&e28, !(g_x机器人1ct细分计时[4]))) { g_x机器人1ct开始[4] = 0; }
    /* IL:5089  TACR K9999999 机器人1CT复位[4] - 机器人1设备CT时间[4] */
    TACC(&机器人1CT复位[4], &机器人1设备CT时间[4], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[4])), (0), dt_ms);
    /* IL:5092  DMOV 机器人1设备CT时间[4] 机器人1设备CT[4] */
    if (RE(&e29, !(g_x机器人1ct开始[4]))) { 机器人1设备CT[4] = 机器人1设备CT时间[4]; }
    /* IL:5093  DFLT 机器人1设备CT[4] 机器人1设备CT浮点数[4] */
    if (RE(&e29, !(g_x机器人1ct开始[4]))) { 机器人1设备CT浮点数[4] = (double)(机器人1设备CT[4]); }
    /* IL:5094  DEDIV 机器人1设备CT浮点数[4] E1000.0 机器人1设备_CT[4] */
    if (RE(&e29, !(g_x机器人1ct开始[4]))) { 机器人1设备_CT[4] = DIVF(机器人1设备CT浮点数[4], 1000.0); }
    /* IL:5095  DEDIV 机器人1设备_CT[4] E4 机器人1设备_CT时间[4] */
    if (RE(&e29, !(g_x机器人1ct开始[4]))) { 机器人1设备_CT时间[4] = DIVF(机器人1设备_CT[4], 4.0); }
    /* IL:5096  OUT 机器人1CT复位[4] */
    if (RE(&e29, !(g_x机器人1ct开始[4]))) { 机器人1CT复位[4] = (RE(&e29, !(g_x机器人1ct开始[4]))); }
    /* IL:5067  SET g_x机器人1ct开始[4] */
    if (RE(&e30, g_x机器人1ct细分计时[4])) { g_x机器人1ct开始[4] = 1; }
    /* IL:5102  RST g_x机器人1ct开始[5] */
    if (RE(&e31, !(g_x机器人1ct细分计时[5]))) { g_x机器人1ct开始[5] = 0; }
    /* IL:5105  TACR K9999999 机器人1CT复位[5] - 机器人1设备CT时间[5] */
    TACC(&机器人1CT复位[5], &机器人1设备CT时间[5], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[5])), (0), dt_ms);
    /* IL:5108  DMOV 机器人1设备CT时间[5] 机器人1设备CT[5] */
    if (RE(&e32, !(g_x机器人1ct开始[5]))) { 机器人1设备CT[5] = 机器人1设备CT时间[5]; }
    /* IL:5109  DFLT 机器人1设备CT[5] 机器人1设备CT浮点数[5] */
    if (RE(&e32, !(g_x机器人1ct开始[5]))) { 机器人1设备CT浮点数[5] = (double)(机器人1设备CT[5]); }
    /* IL:5110  DEDIV 机器人1设备CT浮点数[5] E1000.0 机器人1设备_CT[5] */
    if (RE(&e32, !(g_x机器人1ct开始[5]))) { 机器人1设备_CT[5] = DIVF(机器人1设备CT浮点数[5], 1000.0); }
    /* IL:5111  DEDIV 机器人1设备_CT[5] E4 机器人1设备_CT时间[5] */
    if (RE(&e32, !(g_x机器人1ct开始[5]))) { 机器人1设备_CT时间[5] = DIVF(机器人1设备_CT[5], 4.0); }
    /* IL:5112  OUT 机器人1CT复位[5] */
    if (RE(&e32, !(g_x机器人1ct开始[5]))) { 机器人1CT复位[5] = (RE(&e32, !(g_x机器人1ct开始[5]))); }
    /* IL:5083  SET g_x机器人1ct开始[5] */
    if (RE(&e33, g_x机器人1ct细分计时[5])) { g_x机器人1ct开始[5] = 1; }
    /* IL:5118  RST g_x机器人1ct开始[6] */
    if (RE(&e34, !(g_x机器人1ct细分计时[6]))) { g_x机器人1ct开始[6] = 0; }
    /* IL:5121  TACR K9999999 机器人1CT复位[6] - 机器人1设备CT时间[6] */
    TACC(&机器人1CT复位[6], &机器人1设备CT时间[6], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[6])), (0), dt_ms);
    /* IL:5124  DMOV 机器人1设备CT时间[6] 机器人1设备CT[6] */
    if (RE(&e35, !(g_x机器人1ct开始[6]))) { 机器人1设备CT[6] = 机器人1设备CT时间[6]; }
    /* IL:5125  DFLT 机器人1设备CT[6] 机器人1设备CT浮点数[6] */
    if (RE(&e35, !(g_x机器人1ct开始[6]))) { 机器人1设备CT浮点数[6] = (double)(机器人1设备CT[6]); }
    /* IL:5126  DEDIV 机器人1设备CT浮点数[6] E1000.0 机器人1设备_CT[6] */
    if (RE(&e35, !(g_x机器人1ct开始[6]))) { 机器人1设备_CT[6] = DIVF(机器人1设备CT浮点数[6], 1000.0); }
    /* IL:5127  DEDIV 机器人1设备_CT[6] E4 机器人1设备_CT时间[6] */
    if (RE(&e35, !(g_x机器人1ct开始[6]))) { 机器人1设备_CT时间[6] = DIVF(机器人1设备_CT[6], 4.0); }
    /* IL:5128  OUT 机器人1CT复位[6] */
    if (RE(&e35, !(g_x机器人1ct开始[6]))) { 机器人1CT复位[6] = (RE(&e35, !(g_x机器人1ct开始[6]))); }
    /* IL:5099  SET g_x机器人1ct开始[6] */
    if (RE(&e36, g_x机器人1ct细分计时[6])) { g_x机器人1ct开始[6] = 1; }
    /* IL:5134  RST g_x机器人1ct开始[7] */
    if (RE(&e37, !(g_x机器人1ct细分计时[7]))) { g_x机器人1ct开始[7] = 0; }
    /* IL:5137  TACR K9999999 机器人1CT复位[7] - 机器人1设备CT时间[7] */
    TACC(&机器人1CT复位[7], &机器人1设备CT时间[7], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[7])), (0), dt_ms);
    /* IL:5140  DMOV 机器人1设备CT时间[7] 机器人1设备CT[7] */
    if (RE(&e38, !(g_x机器人1ct开始[7]))) { 机器人1设备CT[7] = 机器人1设备CT时间[7]; }
    /* IL:5141  DFLT 机器人1设备CT[7] 机器人1设备CT浮点数[7] */
    if (RE(&e38, !(g_x机器人1ct开始[7]))) { 机器人1设备CT浮点数[7] = (double)(机器人1设备CT[7]); }
    /* IL:5142  DEDIV 机器人1设备CT浮点数[7] E1000.0 机器人1设备_CT[7] */
    if (RE(&e38, !(g_x机器人1ct开始[7]))) { 机器人1设备_CT[7] = DIVF(机器人1设备CT浮点数[7], 1000.0); }
    /* IL:5143  DEDIV 机器人1设备_CT[7] E4 机器人1设备_CT时间[7] */
    if (RE(&e38, !(g_x机器人1ct开始[7]))) { 机器人1设备_CT时间[7] = DIVF(机器人1设备_CT[7], 4.0); }
    /* IL:5144  OUT 机器人1CT复位[7] */
    if (RE(&e38, !(g_x机器人1ct开始[7]))) { 机器人1CT复位[7] = (RE(&e38, !(g_x机器人1ct开始[7]))); }
    /* IL:5115  SET g_x机器人1ct开始[7] */
    if (RE(&e39, g_x机器人1ct细分计时[7])) { g_x机器人1ct开始[7] = 1; }
    /* IL:5150  RST g_x机器人1ct开始[8] */
    if (RE(&e40, !(g_x机器人1ct细分计时[8]))) { g_x机器人1ct开始[8] = 0; }
    /* IL:5153  TACR K9999999 机器人1CT复位[8] - 机器人1设备CT时间[8] */
    TACC(&机器人1CT复位[8], &机器人1设备CT时间[8], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[8])), (0), dt_ms);
    /* IL:5156  DMOV 机器人1设备CT时间[8] 机器人1设备CT[8] */
    if (RE(&e41, !(g_x机器人1ct开始[8]))) { 机器人1设备CT[8] = 机器人1设备CT时间[8]; }
    /* IL:5157  DFLT 机器人1设备CT[8] 机器人1设备CT浮点数[8] */
    if (RE(&e41, !(g_x机器人1ct开始[8]))) { 机器人1设备CT浮点数[8] = (double)(机器人1设备CT[8]); }
    /* IL:5158  DEDIV 机器人1设备CT浮点数[8] E1000.0 机器人1设备_CT[8] */
    if (RE(&e41, !(g_x机器人1ct开始[8]))) { 机器人1设备_CT[8] = DIVF(机器人1设备CT浮点数[8], 1000.0); }
    /* IL:5159  DEDIV 机器人1设备_CT[8] E4 机器人1设备_CT时间[8] */
    if (RE(&e41, !(g_x机器人1ct开始[8]))) { 机器人1设备_CT时间[8] = DIVF(机器人1设备_CT[8], 4.0); }
    /* IL:5160  OUT 机器人1CT复位[8] */
    if (RE(&e41, !(g_x机器人1ct开始[8]))) { 机器人1CT复位[8] = (RE(&e41, !(g_x机器人1ct开始[8]))); }
    /* IL:5131  SET g_x机器人1ct开始[8] */
    if (RE(&e42, g_x机器人1ct细分计时[8])) { g_x机器人1ct开始[8] = 1; }
    /* IL:5166  RST g_x机器人1ct开始[9] */
    if (RE(&e43, !(g_x机器人1ct细分计时[9]))) { g_x机器人1ct开始[9] = 0; }
    /* IL:5169  TACR K9999999 机器人1CT复位[9] - 机器人1设备CT时间[9] */
    TACC(&机器人1CT复位[9], &机器人1设备CT时间[9], 9999999, ((设备状态机.QB_自动中) && (g_x机器人1ct开始[9])), (0), dt_ms);
    /* IL:5172  DMOV 机器人1设备CT时间[9] 机器人1设备CT[9] */
    if (RE(&e44, !(g_x机器人1ct开始[9]))) { 机器人1设备CT[9] = 机器人1设备CT时间[9]; }
    /* IL:5173  DFLT 机器人1设备CT[9] 机器人1设备CT浮点数[9] */
    if (RE(&e44, !(g_x机器人1ct开始[9]))) { 机器人1设备CT浮点数[9] = (double)(机器人1设备CT[9]); }
    /* IL:5174  DEDIV 机器人1设备CT浮点数[9] E1000.0 机器人1设备_CT[9] */
    if (RE(&e44, !(g_x机器人1ct开始[9]))) { 机器人1设备_CT[9] = DIVF(机器人1设备CT浮点数[9], 1000.0); }
    /* IL:5175  DEDIV 机器人1设备_CT[9] E4 机器人1设备_CT时间[9] */
    if (RE(&e44, !(g_x机器人1ct开始[9]))) { 机器人1设备_CT时间[9] = DIVF(机器人1设备_CT[9], 4.0); }
    /* IL:5176  OUT 机器人1CT复位[9] */
    if (RE(&e44, !(g_x机器人1ct开始[9]))) { 机器人1CT复位[9] = (RE(&e44, !(g_x机器人1ct开始[9]))); }
    /* IL:5147  SET g_x机器人1ct开始[9] */
    if (RE(&e45, g_x机器人1ct细分计时[9])) { g_x机器人1ct开始[9] = 1; }
    /* IL:5182  RST g_x机器人2ct开始[0] */
    if (RE(&e46, !(g_x机器人2ct细分计时[0]))) { g_x机器人2ct开始[0] = 0; }
    /* IL:5185  TACR K9999999 机器人2CT复位[0] - 机器人2设备CT时间[0] */
    TACC(&机器人2CT复位[0], &机器人2设备CT时间[0], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[0])), (0), dt_ms);
    /* IL:5188  DMOV 机器人2设备CT时间[0] 机器人2设备CT[0] */
    if (RE(&e47, !(g_x机器人2ct开始[0]))) { 机器人2设备CT[0] = 机器人2设备CT时间[0]; }
    /* IL:5189  DFLT 机器人2设备CT[0] 机器人2设备CT浮点数[0] */
    if (RE(&e47, !(g_x机器人2ct开始[0]))) { 机器人2设备CT浮点数[0] = (double)(机器人2设备CT[0]); }
    /* IL:5190  DEDIV 机器人2设备CT浮点数[0] E1000.0 机器人2设备_CT[0] */
    if (RE(&e47, !(g_x机器人2ct开始[0]))) { 机器人2设备_CT[0] = DIVF(机器人2设备CT浮点数[0], 1000.0); }
    /* IL:5191  DEDIV 机器人2设备_CT[0] E4 机器人2设备_CT时间[0] */
    if (RE(&e47, !(g_x机器人2ct开始[0]))) { 机器人2设备_CT时间[0] = DIVF(机器人2设备_CT[0], 4.0); }
    /* IL:5192  OUT 机器人2CT复位[0] */
    if (RE(&e47, !(g_x机器人2ct开始[0]))) { 机器人2CT复位[0] = (RE(&e47, !(g_x机器人2ct开始[0]))); }
    /* IL:5163  SET g_x机器人2ct开始[0] */
    if (RE(&e48, g_x机器人2ct细分计时[0])) { g_x机器人2ct开始[0] = 1; }
    /* IL:5198  RST g_x机器人2ct开始[1] */
    if (RE(&e49, !(g_x机器人2ct细分计时[1]))) { g_x机器人2ct开始[1] = 0; }
    /* IL:5201  TACR K9999999 机器人2CT复位[1] - 机器人2设备CT时间[1] */
    TACC(&机器人2CT复位[1], &机器人2设备CT时间[1], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[1])), (0), dt_ms);
    /* IL:5204  DMOV 机器人2设备CT时间[1] 机器人2设备CT[1] */
    if (RE(&e50, !(g_x机器人2ct开始[1]))) { 机器人2设备CT[1] = 机器人2设备CT时间[1]; }
    /* IL:5205  DFLT 机器人2设备CT[1] 机器人2设备CT浮点数[1] */
    if (RE(&e50, !(g_x机器人2ct开始[1]))) { 机器人2设备CT浮点数[1] = (double)(机器人2设备CT[1]); }
    /* IL:5206  DEDIV 机器人2设备CT浮点数[1] E1000.0 机器人2设备_CT[1] */
    if (RE(&e50, !(g_x机器人2ct开始[1]))) { 机器人2设备_CT[1] = DIVF(机器人2设备CT浮点数[1], 1000.0); }
    /* IL:5207  DEDIV 机器人2设备_CT[1] E4 机器人2设备_CT时间[1] */
    if (RE(&e50, !(g_x机器人2ct开始[1]))) { 机器人2设备_CT时间[1] = DIVF(机器人2设备_CT[1], 4.0); }
    /* IL:5208  OUT 机器人2CT复位[1] */
    if (RE(&e50, !(g_x机器人2ct开始[1]))) { 机器人2CT复位[1] = (RE(&e50, !(g_x机器人2ct开始[1]))); }
    /* IL:5179  SET g_x机器人2ct开始[1] */
    if (RE(&e51, g_x机器人2ct细分计时[1])) { g_x机器人2ct开始[1] = 1; }
    /* IL:5214  RST g_x机器人2ct开始[2] */
    if (RE(&e52, !(g_x机器人2ct细分计时[2]))) { g_x机器人2ct开始[2] = 0; }
    /* IL:5217  TACR K9999999 机器人2CT复位[2] - 机器人2设备CT时间[2] */
    TACC(&机器人2CT复位[2], &机器人2设备CT时间[2], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[2])), (0), dt_ms);
    /* IL:5220  DMOV 机器人2设备CT时间[2] 机器人2设备CT[2] */
    if (RE(&e53, !(g_x机器人2ct开始[2]))) { 机器人2设备CT[2] = 机器人2设备CT时间[2]; }
    /* IL:5221  DFLT 机器人2设备CT[2] 机器人2设备CT浮点数[2] */
    if (RE(&e53, !(g_x机器人2ct开始[2]))) { 机器人2设备CT浮点数[2] = (double)(机器人2设备CT[2]); }
    /* IL:5222  DEDIV 机器人2设备CT浮点数[2] E1000.0 机器人2设备_CT[2] */
    if (RE(&e53, !(g_x机器人2ct开始[2]))) { 机器人2设备_CT[2] = DIVF(机器人2设备CT浮点数[2], 1000.0); }
    /* IL:5223  DEDIV 机器人2设备_CT[2] E4 机器人2设备_CT时间[2] */
    if (RE(&e53, !(g_x机器人2ct开始[2]))) { 机器人2设备_CT时间[2] = DIVF(机器人2设备_CT[2], 4.0); }
    /* IL:5224  OUT 机器人2CT复位[2] */
    if (RE(&e53, !(g_x机器人2ct开始[2]))) { 机器人2CT复位[2] = (RE(&e53, !(g_x机器人2ct开始[2]))); }
    /* IL:5195  SET g_x机器人2ct开始[2] */
    if (RE(&e54, g_x机器人2ct细分计时[2])) { g_x机器人2ct开始[2] = 1; }
    /* IL:5230  RST g_x机器人2ct开始[3] */
    if (RE(&e55, !(g_x机器人2ct细分计时[3]))) { g_x机器人2ct开始[3] = 0; }
    /* IL:5233  TACR K9999999 机器人2CT复位[3] - 机器人2设备CT时间[3] */
    TACC(&机器人2CT复位[3], &机器人2设备CT时间[3], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[3])), (0), dt_ms);
    /* IL:5236  DMOV 机器人2设备CT时间[3] 机器人2设备CT[3] */
    if (RE(&e56, !(g_x机器人2ct开始[3]))) { 机器人2设备CT[3] = 机器人2设备CT时间[3]; }
    /* IL:5237  DFLT 机器人2设备CT[3] 机器人2设备CT浮点数[3] */
    if (RE(&e56, !(g_x机器人2ct开始[3]))) { 机器人2设备CT浮点数[3] = (double)(机器人2设备CT[3]); }
    /* IL:5238  DEDIV 机器人2设备CT浮点数[3] E1000.0 机器人2设备_CT[3] */
    if (RE(&e56, !(g_x机器人2ct开始[3]))) { 机器人2设备_CT[3] = DIVF(机器人2设备CT浮点数[3], 1000.0); }
    /* IL:5239  DEDIV 机器人2设备_CT[3] E4 机器人2设备_CT时间[3] */
    if (RE(&e56, !(g_x机器人2ct开始[3]))) { 机器人2设备_CT时间[3] = DIVF(机器人2设备_CT[3], 4.0); }
    /* IL:5240  OUT 机器人2CT复位[3] */
    if (RE(&e56, !(g_x机器人2ct开始[3]))) { 机器人2CT复位[3] = (RE(&e56, !(g_x机器人2ct开始[3]))); }
    /* IL:5211  SET g_x机器人2ct开始[3] */
    if (RE(&e57, g_x机器人2ct细分计时[3])) { g_x机器人2ct开始[3] = 1; }
    /* IL:5246  RST g_x机器人2ct开始[4] */
    if (RE(&e58, !(g_x机器人2ct细分计时[4]))) { g_x机器人2ct开始[4] = 0; }
    /* IL:5249  TACR K9999999 机器人2CT复位[4] - 机器人2设备CT时间[4] */
    TACC(&机器人2CT复位[4], &机器人2设备CT时间[4], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[4])), (0), dt_ms);
    /* IL:5252  DMOV 机器人2设备CT时间[4] 机器人2设备CT[4] */
    if (RE(&e59, !(g_x机器人2ct开始[4]))) { 机器人2设备CT[4] = 机器人2设备CT时间[4]; }
    /* IL:5253  DFLT 机器人2设备CT[4] 机器人2设备CT浮点数[4] */
    if (RE(&e59, !(g_x机器人2ct开始[4]))) { 机器人2设备CT浮点数[4] = (double)(机器人2设备CT[4]); }
    /* IL:5254  DEDIV 机器人2设备CT浮点数[4] E1000.0 机器人2设备_CT[4] */
    if (RE(&e59, !(g_x机器人2ct开始[4]))) { 机器人2设备_CT[4] = DIVF(机器人2设备CT浮点数[4], 1000.0); }
    /* IL:5255  DEDIV 机器人2设备_CT[4] E4 机器人2设备_CT时间[4] */
    if (RE(&e59, !(g_x机器人2ct开始[4]))) { 机器人2设备_CT时间[4] = DIVF(机器人2设备_CT[4], 4.0); }
    /* IL:5256  OUT 机器人2CT复位[4] */
    if (RE(&e59, !(g_x机器人2ct开始[4]))) { 机器人2CT复位[4] = (RE(&e59, !(g_x机器人2ct开始[4]))); }
    /* IL:5227  SET g_x机器人2ct开始[4] */
    if (RE(&e60, g_x机器人2ct细分计时[4])) { g_x机器人2ct开始[4] = 1; }
    /* IL:5262  RST g_x机器人2ct开始[5] */
    if (RE(&e61, !(g_x机器人2ct细分计时[5]))) { g_x机器人2ct开始[5] = 0; }
    /* IL:5265  TACR K9999999 机器人2CT复位[5] - 机器人2设备CT时间[5] */
    TACC(&机器人2CT复位[5], &机器人2设备CT时间[5], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[5])), (0), dt_ms);
    /* IL:5268  DMOV 机器人2设备CT时间[5] 机器人2设备CT[5] */
    if (RE(&e62, !(g_x机器人2ct开始[5]))) { 机器人2设备CT[5] = 机器人2设备CT时间[5]; }
    /* IL:5269  DFLT 机器人2设备CT[5] 机器人2设备CT浮点数[5] */
    if (RE(&e62, !(g_x机器人2ct开始[5]))) { 机器人2设备CT浮点数[5] = (double)(机器人2设备CT[5]); }
    /* IL:5270  DEDIV 机器人2设备CT浮点数[5] E1000.0 机器人2设备_CT[5] */
    if (RE(&e62, !(g_x机器人2ct开始[5]))) { 机器人2设备_CT[5] = DIVF(机器人2设备CT浮点数[5], 1000.0); }
    /* IL:5271  DEDIV 机器人2设备_CT[5] E4 机器人2设备_CT时间[5] */
    if (RE(&e62, !(g_x机器人2ct开始[5]))) { 机器人2设备_CT时间[5] = DIVF(机器人2设备_CT[5], 4.0); }
    /* IL:5272  OUT 机器人2CT复位[5] */
    if (RE(&e62, !(g_x机器人2ct开始[5]))) { 机器人2CT复位[5] = (RE(&e62, !(g_x机器人2ct开始[5]))); }
    /* IL:5243  SET g_x机器人2ct开始[5] */
    if (RE(&e63, g_x机器人2ct细分计时[5])) { g_x机器人2ct开始[5] = 1; }
    /* IL:5278  RST g_x机器人2ct开始[6] */
    if (RE(&e64, !(g_x机器人2ct细分计时[6]))) { g_x机器人2ct开始[6] = 0; }
    /* IL:5281  TACR K9999999 机器人2CT复位[6] - 机器人2设备CT时间[6] */
    TACC(&机器人2CT复位[6], &机器人2设备CT时间[6], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[6])), (0), dt_ms);
    /* IL:5284  DMOV 机器人2设备CT时间[6] 机器人2设备CT[6] */
    if (RE(&e65, !(g_x机器人2ct开始[6]))) { 机器人2设备CT[6] = 机器人2设备CT时间[6]; }
    /* IL:5285  DFLT 机器人2设备CT[6] 机器人2设备CT浮点数[6] */
    if (RE(&e65, !(g_x机器人2ct开始[6]))) { 机器人2设备CT浮点数[6] = (double)(机器人2设备CT[6]); }
    /* IL:5286  DEDIV 机器人2设备CT浮点数[6] E1000.0 机器人2设备_CT[6] */
    if (RE(&e65, !(g_x机器人2ct开始[6]))) { 机器人2设备_CT[6] = DIVF(机器人2设备CT浮点数[6], 1000.0); }
    /* IL:5287  DEDIV 机器人2设备_CT[6] E4 机器人2设备_CT时间[6] */
    if (RE(&e65, !(g_x机器人2ct开始[6]))) { 机器人2设备_CT时间[6] = DIVF(机器人2设备_CT[6], 4.0); }
    /* IL:5288  OUT 机器人2CT复位[6] */
    if (RE(&e65, !(g_x机器人2ct开始[6]))) { 机器人2CT复位[6] = (RE(&e65, !(g_x机器人2ct开始[6]))); }
    /* IL:5259  SET g_x机器人2ct开始[6] */
    if (RE(&e66, g_x机器人2ct细分计时[6])) { g_x机器人2ct开始[6] = 1; }
    /* IL:5294  RST g_x机器人2ct开始[7] */
    if (RE(&e67, !(g_x机器人2ct细分计时[7]))) { g_x机器人2ct开始[7] = 0; }
    /* IL:5297  TACR K9999999 机器人2CT复位[7] - 机器人2设备CT时间[7] */
    TACC(&机器人2CT复位[7], &机器人2设备CT时间[7], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[7])), (0), dt_ms);
    /* IL:5300  DMOV 机器人2设备CT时间[7] 机器人2设备CT[7] */
    if (RE(&e68, !(g_x机器人2ct开始[7]))) { 机器人2设备CT[7] = 机器人2设备CT时间[7]; }
    /* IL:5301  DFLT 机器人2设备CT[7] 机器人2设备CT浮点数[7] */
    if (RE(&e68, !(g_x机器人2ct开始[7]))) { 机器人2设备CT浮点数[7] = (double)(机器人2设备CT[7]); }
    /* IL:5302  DEDIV 机器人2设备CT浮点数[7] E1000.0 机器人2设备_CT[7] */
    if (RE(&e68, !(g_x机器人2ct开始[7]))) { 机器人2设备_CT[7] = DIVF(机器人2设备CT浮点数[7], 1000.0); }
    /* IL:5303  DEDIV 机器人2设备_CT[7] E4 机器人2设备_CT时间[7] */
    if (RE(&e68, !(g_x机器人2ct开始[7]))) { 机器人2设备_CT时间[7] = DIVF(机器人2设备_CT[7], 4.0); }
    /* IL:5304  OUT 机器人2CT复位[7] */
    if (RE(&e68, !(g_x机器人2ct开始[7]))) { 机器人2CT复位[7] = (RE(&e68, !(g_x机器人2ct开始[7]))); }
    /* IL:5275  SET g_x机器人2ct开始[7] */
    if (RE(&e69, g_x机器人2ct细分计时[7])) { g_x机器人2ct开始[7] = 1; }
    /* IL:5310  RST g_x机器人2ct开始[8] */
    if (RE(&e70, !(g_x机器人2ct细分计时[8]))) { g_x机器人2ct开始[8] = 0; }
    /* IL:5313  TACR K9999999 机器人2CT复位[8] - 机器人2设备CT时间[8] */
    TACC(&机器人2CT复位[8], &机器人2设备CT时间[8], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[8])), (0), dt_ms);
    /* IL:5316  DMOV 机器人2设备CT时间[8] 机器人2设备CT[8] */
    if (RE(&e71, !(g_x机器人2ct开始[8]))) { 机器人2设备CT[8] = 机器人2设备CT时间[8]; }
    /* IL:5317  DFLT 机器人2设备CT[8] 机器人2设备CT浮点数[8] */
    if (RE(&e71, !(g_x机器人2ct开始[8]))) { 机器人2设备CT浮点数[8] = (double)(机器人2设备CT[8]); }
    /* IL:5318  DEDIV 机器人2设备CT浮点数[8] E1000.0 机器人2设备_CT[8] */
    if (RE(&e71, !(g_x机器人2ct开始[8]))) { 机器人2设备_CT[8] = DIVF(机器人2设备CT浮点数[8], 1000.0); }
    /* IL:5319  DEDIV 机器人2设备_CT[8] E4 机器人2设备_CT时间[8] */
    if (RE(&e71, !(g_x机器人2ct开始[8]))) { 机器人2设备_CT时间[8] = DIVF(机器人2设备_CT[8], 4.0); }
    /* IL:5320  OUT 机器人2CT复位[8] */
    if (RE(&e71, !(g_x机器人2ct开始[8]))) { 机器人2CT复位[8] = (RE(&e71, !(g_x机器人2ct开始[8]))); }
    /* IL:5291  SET g_x机器人2ct开始[8] */
    if (RE(&e72, g_x机器人2ct细分计时[8])) { g_x机器人2ct开始[8] = 1; }
    /* IL:5326  RST g_x机器人2ct开始[9] */
    if (RE(&e73, !(g_x机器人2ct细分计时[9]))) { g_x机器人2ct开始[9] = 0; }
    /* IL:5329  TACR K9999999 机器人2CT复位[9] - 机器人2设备CT时间[9] */
    TACC(&机器人2CT复位[9], &机器人2设备CT时间[9], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[9])), (0), dt_ms);
    /* IL:5332  DMOV 机器人2设备CT时间[9] 机器人2设备CT[9] */
    if (RE(&e74, !(g_x机器人2ct开始[9]))) { 机器人2设备CT[9] = 机器人2设备CT时间[9]; }
    /* IL:5333  DFLT 机器人2设备CT[9] 机器人2设备CT浮点数[9] */
    if (RE(&e74, !(g_x机器人2ct开始[9]))) { 机器人2设备CT浮点数[9] = (double)(机器人2设备CT[9]); }
    /* IL:5334  DEDIV 机器人2设备CT浮点数[9] E1000.0 机器人2设备_CT[9] */
    if (RE(&e74, !(g_x机器人2ct开始[9]))) { 机器人2设备_CT[9] = DIVF(机器人2设备CT浮点数[9], 1000.0); }
    /* IL:5335  DEDIV 机器人2设备_CT[9] E4 机器人2设备_CT时间[9] */
    if (RE(&e74, !(g_x机器人2ct开始[9]))) { 机器人2设备_CT时间[9] = DIVF(机器人2设备_CT[9], 4.0); }
    /* IL:5336  OUT 机器人2CT复位[9] */
    if (RE(&e74, !(g_x机器人2ct开始[9]))) { 机器人2CT复位[9] = (RE(&e74, !(g_x机器人2ct开始[9]))); }
    /* IL:5307  SET g_x机器人2ct开始[9] */
    if (RE(&e75, g_x机器人2ct细分计时[9])) { g_x机器人2ct开始[9] = 1; }
    /* IL:5342  RST g_x机器人2ct开始[10] */
    if (RE(&e76, !(g_x机器人2ct细分计时[10]))) { g_x机器人2ct开始[10] = 0; }
    /* IL:5345  TACR K9999999 机器人2CT复位[10] - 机器人2设备CT时间[10] */
    TACC(&机器人2CT复位[10], &机器人2设备CT时间[10], 9999999, ((设备状态机.QB_自动中) && (g_x机器人2ct开始[10])), (0), dt_ms);
    /* IL:5348  DMOV 机器人2设备CT时间[10] 机器人2设备CT[10] */
    if (RE(&e77, !(g_x机器人2ct开始[10]))) { 机器人2设备CT[10] = 机器人2设备CT时间[10]; }
    /* IL:5349  DFLT 机器人2设备CT[10] 机器人2设备CT浮点数[10] */
    if (RE(&e77, !(g_x机器人2ct开始[10]))) { 机器人2设备CT浮点数[10] = (double)(机器人2设备CT[10]); }
    /* IL:5350  DEDIV 机器人2设备CT浮点数[10] E1000.0 机器人2设备_CT[10] */
    if (RE(&e77, !(g_x机器人2ct开始[10]))) { 机器人2设备_CT[10] = DIVF(机器人2设备CT浮点数[10], 1000.0); }
    /* IL:5351  DEDIV 机器人2设备_CT[10] E4 机器人2设备_CT时间[10] */
    if (RE(&e77, !(g_x机器人2ct开始[10]))) { 机器人2设备_CT时间[10] = DIVF(机器人2设备_CT[10], 4.0); }
    /* IL:5352  OUT 机器人2CT复位[10] */
    if (RE(&e77, !(g_x机器人2ct开始[10]))) { 机器人2CT复位[10] = (RE(&e77, !(g_x机器人2ct开始[10]))); }
    /* IL:5323  SET g_x机器人2ct开始[10] */
    if (RE(&e78, g_x机器人2ct细分计时[10])) { g_x机器人2ct开始[10] = 1; }
    /* IL:5358  RST g_xFLct开始[0] */
    if (RE(&e79, !(g_xFLct细分计时[0]))) { g_xFLct开始[0] = 0; }
    /* IL:5361  TACR K9999999 FLCT复位[0] - FL设备CT时间[0] */
    TACC(&FLCT复位[0], &FL设备CT时间[0], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[0])), (0), dt_ms);
    /* IL:5364  DMOV FL设备CT时间[0] FL设备CT[0] */
    if (RE(&e80, !(g_xFLct开始[0]))) { FL设备CT[0] = FL设备CT时间[0]; }
    /* IL:5365  DFLT FL设备CT[0] FL设备CT浮点数[0] */
    if (RE(&e80, !(g_xFLct开始[0]))) { FL设备CT浮点数[0] = (double)(FL设备CT[0]); }
    /* IL:5366  DEDIV FL设备CT浮点数[0] E1000.0 FL设备_CT[0] */
    if (RE(&e80, !(g_xFLct开始[0]))) { FL设备_CT[0] = DIVF(FL设备CT浮点数[0], 1000.0); }
    /* IL:5367  DEDIV FL设备_CT[0] E4 FL设备_CT时间[0] */
    if (RE(&e80, !(g_xFLct开始[0]))) { FL设备_CT时间[0] = DIVF(FL设备_CT[0], 4.0); }
    /* IL:5368  OUT FLCT复位[0] */
    if (RE(&e80, !(g_xFLct开始[0]))) { FLCT复位[0] = (RE(&e80, !(g_xFLct开始[0]))); }
    /* IL:5339  SET g_xFLct开始[0] */
    if (RE(&e81, g_xFLct细分计时[0])) { g_xFLct开始[0] = 1; }
    /* IL:5374  RST g_xFLct开始[1] */
    if (RE(&e82, !(g_xFLct细分计时[1]))) { g_xFLct开始[1] = 0; }
    /* IL:5377  TACR K9999999 FLCT复位[1] - FL设备CT时间[1] */
    TACC(&FLCT复位[1], &FL设备CT时间[1], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[1])), (0), dt_ms);
    /* IL:5380  DMOV FL设备CT时间[1] FL设备CT[1] */
    if (RE(&e83, !(g_xFLct开始[1]))) { FL设备CT[1] = FL设备CT时间[1]; }
    /* IL:5381  DFLT FL设备CT[1] FL设备CT浮点数[1] */
    if (RE(&e83, !(g_xFLct开始[1]))) { FL设备CT浮点数[1] = (double)(FL设备CT[1]); }
    /* IL:5382  DEDIV FL设备CT浮点数[1] E1000.0 FL设备_CT[1] */
    if (RE(&e83, !(g_xFLct开始[1]))) { FL设备_CT[1] = DIVF(FL设备CT浮点数[1], 1000.0); }
    /* IL:5383  DEDIV FL设备_CT[1] E4 FL设备_CT时间[1] */
    if (RE(&e83, !(g_xFLct开始[1]))) { FL设备_CT时间[1] = DIVF(FL设备_CT[1], 4.0); }
    /* IL:5384  OUT FLCT复位[1] */
    if (RE(&e83, !(g_xFLct开始[1]))) { FLCT复位[1] = (RE(&e83, !(g_xFLct开始[1]))); }
    /* IL:5355  SET g_xFLct开始[1] */
    if (RE(&e84, g_xFLct细分计时[1])) { g_xFLct开始[1] = 1; }
    /* IL:5390  RST g_xFLct开始[2] */
    if (RE(&e85, !(g_xFLct细分计时[2]))) { g_xFLct开始[2] = 0; }
    /* IL:5393  TACR K9999999 FLCT复位[2] - FL设备CT时间[2] */
    TACC(&FLCT复位[2], &FL设备CT时间[2], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[2])), (0), dt_ms);
    /* IL:5396  DMOV FL设备CT时间[2] FL设备CT[2] */
    if (RE(&e86, !(g_xFLct开始[2]))) { FL设备CT[2] = FL设备CT时间[2]; }
    /* IL:5397  DFLT FL设备CT[2] FL设备CT浮点数[2] */
    if (RE(&e86, !(g_xFLct开始[2]))) { FL设备CT浮点数[2] = (double)(FL设备CT[2]); }
    /* IL:5398  DEDIV FL设备CT浮点数[2] E1000.0 FL设备_CT[2] */
    if (RE(&e86, !(g_xFLct开始[2]))) { FL设备_CT[2] = DIVF(FL设备CT浮点数[2], 1000.0); }
    /* IL:5399  DEDIV FL设备_CT[2] E4 FL设备_CT时间[2] */
    if (RE(&e86, !(g_xFLct开始[2]))) { FL设备_CT时间[2] = DIVF(FL设备_CT[2], 4.0); }
    /* IL:5400  OUT FLCT复位[2] */
    if (RE(&e86, !(g_xFLct开始[2]))) { FLCT复位[2] = (RE(&e86, !(g_xFLct开始[2]))); }
    /* IL:5371  SET g_xFLct开始[2] */
    if (RE(&e87, g_xFLct细分计时[2])) { g_xFLct开始[2] = 1; }
    /* IL:5406  RST g_xFLct开始[3] */
    if (RE(&e88, !(g_xFLct细分计时[3]))) { g_xFLct开始[3] = 0; }
    /* IL:5409  TACR K9999999 FLCT复位[3] - FL设备CT时间[3] */
    TACC(&FLCT复位[3], &FL设备CT时间[3], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[3])), (0), dt_ms);
    /* IL:5412  DMOV FL设备CT时间[3] FL设备CT[3] */
    if (RE(&e89, !(g_xFLct开始[3]))) { FL设备CT[3] = FL设备CT时间[3]; }
    /* IL:5413  DFLT FL设备CT[3] FL设备CT浮点数[3] */
    if (RE(&e89, !(g_xFLct开始[3]))) { FL设备CT浮点数[3] = (double)(FL设备CT[3]); }
    /* IL:5414  DEDIV FL设备CT浮点数[3] E1000.0 FL设备_CT[3] */
    if (RE(&e89, !(g_xFLct开始[3]))) { FL设备_CT[3] = DIVF(FL设备CT浮点数[3], 1000.0); }
    /* IL:5415  DEDIV FL设备_CT[3] E4 FL设备_CT时间[3] */
    if (RE(&e89, !(g_xFLct开始[3]))) { FL设备_CT时间[3] = DIVF(FL设备_CT[3], 4.0); }
    /* IL:5416  OUT FLCT复位[3] */
    if (RE(&e89, !(g_xFLct开始[3]))) { FLCT复位[3] = (RE(&e89, !(g_xFLct开始[3]))); }
    /* IL:5387  SET g_xFLct开始[3] */
    if (RE(&e90, g_xFLct细分计时[3])) { g_xFLct开始[3] = 1; }
    /* IL:5422  RST g_xFLct开始[4] */
    if (RE(&e91, !(g_xFLct细分计时[4]))) { g_xFLct开始[4] = 0; }
    /* IL:5425  TACR K9999999 FLCT复位[4] - FL设备CT时间[4] */
    TACC(&FLCT复位[4], &FL设备CT时间[4], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[4])), (0), dt_ms);
    /* IL:5428  DMOV FL设备CT时间[4] FL设备CT[4] */
    if (RE(&e92, !(g_xFLct开始[4]))) { FL设备CT[4] = FL设备CT时间[4]; }
    /* IL:5429  DFLT FL设备CT[4] FL设备CT浮点数[4] */
    if (RE(&e92, !(g_xFLct开始[4]))) { FL设备CT浮点数[4] = (double)(FL设备CT[4]); }
    /* IL:5430  DEDIV FL设备CT浮点数[4] E1000.0 FL设备_CT[4] */
    if (RE(&e92, !(g_xFLct开始[4]))) { FL设备_CT[4] = DIVF(FL设备CT浮点数[4], 1000.0); }
    /* IL:5431  DEDIV FL设备_CT[4] E4 FL设备_CT时间[4] */
    if (RE(&e92, !(g_xFLct开始[4]))) { FL设备_CT时间[4] = DIVF(FL设备_CT[4], 4.0); }
    /* IL:5432  OUT FLCT复位[4] */
    if (RE(&e92, !(g_xFLct开始[4]))) { FLCT复位[4] = (RE(&e92, !(g_xFLct开始[4]))); }
    /* IL:5403  SET g_xFLct开始[4] */
    if (RE(&e93, g_xFLct细分计时[4])) { g_xFLct开始[4] = 1; }
    /* IL:5438  RST g_xFLct开始[5] */
    if (RE(&e94, !(g_xFLct细分计时[5]))) { g_xFLct开始[5] = 0; }
    /* IL:5441  TACR K9999999 FLCT复位[5] - FL设备CT时间[5] */
    TACC(&FLCT复位[5], &FL设备CT时间[5], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[5])), (0), dt_ms);
    /* IL:5444  DMOV FL设备CT时间[5] FL设备CT[5] */
    if (RE(&e95, !(g_xFLct开始[5]))) { FL设备CT[5] = FL设备CT时间[5]; }
    /* IL:5445  DFLT FL设备CT[5] FL设备CT浮点数[5] */
    if (RE(&e95, !(g_xFLct开始[5]))) { FL设备CT浮点数[5] = (double)(FL设备CT[5]); }
    /* IL:5446  DEDIV FL设备CT浮点数[5] E1000.0 FL设备_CT[5] */
    if (RE(&e95, !(g_xFLct开始[5]))) { FL设备_CT[5] = DIVF(FL设备CT浮点数[5], 1000.0); }
    /* IL:5447  DEDIV FL设备_CT[5] E4 FL设备_CT时间[5] */
    if (RE(&e95, !(g_xFLct开始[5]))) { FL设备_CT时间[5] = DIVF(FL设备_CT[5], 4.0); }
    /* IL:5448  OUT FLCT复位[5] */
    if (RE(&e95, !(g_xFLct开始[5]))) { FLCT复位[5] = (RE(&e95, !(g_xFLct开始[5]))); }
    /* IL:5419  SET g_xFLct开始[5] */
    if (RE(&e96, g_xFLct细分计时[5])) { g_xFLct开始[5] = 1; }
    /* IL:5454  RST g_xFLct开始[6] */
    if (RE(&e97, !(g_xFLct细分计时[6]))) { g_xFLct开始[6] = 0; }
    /* IL:5457  TACR K9999999 FLCT复位[6] - FL设备CT时间[6] */
    TACC(&FLCT复位[6], &FL设备CT时间[6], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[6])), (0), dt_ms);
    /* IL:5460  DMOV FL设备CT时间[6] FL设备CT[6] */
    if (RE(&e98, !(g_xFLct开始[6]))) { FL设备CT[6] = FL设备CT时间[6]; }
    /* IL:5461  DFLT FL设备CT[6] FL设备CT浮点数[6] */
    if (RE(&e98, !(g_xFLct开始[6]))) { FL设备CT浮点数[6] = (double)(FL设备CT[6]); }
    /* IL:5462  DEDIV FL设备CT浮点数[6] E1000.0 FL设备_CT[6] */
    if (RE(&e98, !(g_xFLct开始[6]))) { FL设备_CT[6] = DIVF(FL设备CT浮点数[6], 1000.0); }
    /* IL:5463  DEDIV FL设备_CT[6] E4 FL设备_CT时间[6] */
    if (RE(&e98, !(g_xFLct开始[6]))) { FL设备_CT时间[6] = DIVF(FL设备_CT[6], 4.0); }
    /* IL:5464  OUT FLCT复位[6] */
    if (RE(&e98, !(g_xFLct开始[6]))) { FLCT复位[6] = (RE(&e98, !(g_xFLct开始[6]))); }
    /* IL:5435  SET g_xFLct开始[6] */
    if (RE(&e99, g_xFLct细分计时[6])) { g_xFLct开始[6] = 1; }
    /* IL:5470  RST g_xFLct开始[7] */
    if (RE(&e100, !(g_xFLct细分计时[7]))) { g_xFLct开始[7] = 0; }
    /* IL:5473  TACR K9999999 FLCT复位[7] - FL设备CT时间[7] */
    TACC(&FLCT复位[7], &FL设备CT时间[7], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[7])), (0), dt_ms);
    /* IL:5476  DMOV FL设备CT时间[7] FL设备CT[7] */
    if (RE(&e101, !(g_xFLct开始[7]))) { FL设备CT[7] = FL设备CT时间[7]; }
    /* IL:5477  DFLT FL设备CT[7] FL设备CT浮点数[7] */
    if (RE(&e101, !(g_xFLct开始[7]))) { FL设备CT浮点数[7] = (double)(FL设备CT[7]); }
    /* IL:5478  DEDIV FL设备CT浮点数[7] E1000.0 FL设备_CT[7] */
    if (RE(&e101, !(g_xFLct开始[7]))) { FL设备_CT[7] = DIVF(FL设备CT浮点数[7], 1000.0); }
    /* IL:5479  DEDIV FL设备_CT[7] E4 FL设备_CT时间[7] */
    if (RE(&e101, !(g_xFLct开始[7]))) { FL设备_CT时间[7] = DIVF(FL设备_CT[7], 4.0); }
    /* IL:5480  OUT FLCT复位[7] */
    if (RE(&e101, !(g_xFLct开始[7]))) { FLCT复位[7] = (RE(&e101, !(g_xFLct开始[7]))); }
    /* IL:5451  SET g_xFLct开始[7] */
    if (RE(&e102, g_xFLct细分计时[7])) { g_xFLct开始[7] = 1; }
    /* IL:5486  RST g_xFLct开始[8] */
    if (RE(&e103, !(g_xFLct细分计时[8]))) { g_xFLct开始[8] = 0; }
    /* IL:5489  TACR K9999999 FLCT复位[8] - FL设备CT时间[8] */
    TACC(&FLCT复位[8], &FL设备CT时间[8], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[8])), (0), dt_ms);
    /* IL:5492  DMOV FL设备CT时间[8] FL设备CT[8] */
    if (RE(&e104, !(g_xFLct开始[8]))) { FL设备CT[8] = FL设备CT时间[8]; }
    /* IL:5493  DFLT FL设备CT[8] FL设备CT浮点数[8] */
    if (RE(&e104, !(g_xFLct开始[8]))) { FL设备CT浮点数[8] = (double)(FL设备CT[8]); }
    /* IL:5494  DEDIV FL设备CT浮点数[8] E1000.0 FL设备_CT[8] */
    if (RE(&e104, !(g_xFLct开始[8]))) { FL设备_CT[8] = DIVF(FL设备CT浮点数[8], 1000.0); }
    /* IL:5495  DEDIV FL设备_CT[8] E4 FL设备_CT时间[8] */
    if (RE(&e104, !(g_xFLct开始[8]))) { FL设备_CT时间[8] = DIVF(FL设备_CT[8], 4.0); }
    /* IL:5496  OUT FLCT复位[8] */
    if (RE(&e104, !(g_xFLct开始[8]))) { FLCT复位[8] = (RE(&e104, !(g_xFLct开始[8]))); }
    /* IL:5467  SET g_xFLct开始[8] */
    if (RE(&e105, g_xFLct细分计时[8])) { g_xFLct开始[8] = 1; }
    /* IL:5502  RST g_xFLct开始[9] */
    if (RE(&e106, !(g_xFLct细分计时[9]))) { g_xFLct开始[9] = 0; }
    /* IL:5505  TACR K9999999 FLCT复位[9] - FL设备CT时间[9] */
    TACC(&FLCT复位[9], &FL设备CT时间[9], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[9])), (0), dt_ms);
    /* IL:5508  DMOV FL设备CT时间[9] FL设备CT[9] */
    if (RE(&e107, !(g_xFLct开始[9]))) { FL设备CT[9] = FL设备CT时间[9]; }
    /* IL:5509  DFLT FL设备CT[9] FL设备CT浮点数[9] */
    if (RE(&e107, !(g_xFLct开始[9]))) { FL设备CT浮点数[9] = (double)(FL设备CT[9]); }
    /* IL:5510  DEDIV FL设备CT浮点数[9] E1000.0 FL设备_CT[9] */
    if (RE(&e107, !(g_xFLct开始[9]))) { FL设备_CT[9] = DIVF(FL设备CT浮点数[9], 1000.0); }
    /* IL:5511  DEDIV FL设备_CT[9] E4 FL设备_CT时间[9] */
    if (RE(&e107, !(g_xFLct开始[9]))) { FL设备_CT时间[9] = DIVF(FL设备_CT[9], 4.0); }
    /* IL:5512  OUT FLCT复位[9] */
    if (RE(&e107, !(g_xFLct开始[9]))) { FLCT复位[9] = (RE(&e107, !(g_xFLct开始[9]))); }
    /* IL:5483  SET g_xFLct开始[9] */
    if (RE(&e108, g_xFLct细分计时[9])) { g_xFLct开始[9] = 1; }
    /* IL:5518  RST g_xFLct开始[10] */
    if (RE(&e109, !(g_xFLct细分计时[10]))) { g_xFLct开始[10] = 0; }
    /* IL:5521  TACR K9999999 FLCT复位[10] - FL设备CT时间[10] */
    TACC(&FLCT复位[10], &FL设备CT时间[10], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[10])), (0), dt_ms);
    /* IL:5524  DMOV FL设备CT时间[10] FL设备CT[10] */
    if (RE(&e110, !(g_xFLct开始[10]))) { FL设备CT[10] = FL设备CT时间[10]; }
    /* IL:5525  DFLT FL设备CT[10] FL设备CT浮点数[10] */
    if (RE(&e110, !(g_xFLct开始[10]))) { FL设备CT浮点数[10] = (double)(FL设备CT[10]); }
    /* IL:5526  DEDIV FL设备CT浮点数[10] E1000.0 FL设备_CT[10] */
    if (RE(&e110, !(g_xFLct开始[10]))) { FL设备_CT[10] = DIVF(FL设备CT浮点数[10], 1000.0); }
    /* IL:5527  DEDIV FL设备_CT[10] E4 FL设备_CT时间[10] */
    if (RE(&e110, !(g_xFLct开始[10]))) { FL设备_CT时间[10] = DIVF(FL设备_CT[10], 4.0); }
    /* IL:5528  OUT FLCT复位[10] */
    if (RE(&e110, !(g_xFLct开始[10]))) { FLCT复位[10] = (RE(&e110, !(g_xFLct开始[10]))); }
    /* IL:5499  SET g_xFLct开始[10] */
    if (RE(&e111, g_xFLct细分计时[10])) { g_xFLct开始[10] = 1; }
    /* IL:5534  RST g_xFLct开始[11] */
    if (RE(&e112, !(g_xFLct细分计时[11]))) { g_xFLct开始[11] = 0; }
    /* IL:5537  TACR K9999999 FLCT复位[11] - FL设备CT时间[11] */
    TACC(&FLCT复位[11], &FL设备CT时间[11], 9999999, ((设备状态机.QB_自动中) && (g_xFLct开始[11])), (0), dt_ms);
    /* IL:5540  DMOV FL设备CT时间[11] FL设备CT[11] */
    if (RE(&e113, !(g_xFLct开始[10]))) { FL设备CT[11] = FL设备CT时间[11]; }
    /* IL:5541  DFLT FL设备CT[11] FL设备CT浮点数[11] */
    if (RE(&e113, !(g_xFLct开始[10]))) { FL设备CT浮点数[11] = (double)(FL设备CT[11]); }
    /* IL:5542  DEDIV FL设备CT浮点数[11] E1000.0 FL设备_CT[11] */
    if (RE(&e113, !(g_xFLct开始[10]))) { FL设备_CT[11] = DIVF(FL设备CT浮点数[11], 1000.0); }
    /* IL:5543  DEDIV FL设备_CT[11] E4 FL设备_CT时间[11] */
    if (RE(&e113, !(g_xFLct开始[10]))) { FL设备_CT时间[11] = DIVF(FL设备_CT[11], 4.0); }
    /* IL:5544  OUT FLCT复位[11] */
    if (RE(&e113, !(g_xFLct开始[10]))) { FLCT复位[11] = (RE(&e113, !(g_xFLct开始[10]))); }
    /* IL:5515  SET g_xFLct开始[11] */
    if (RE(&e114, g_xFLct细分计时[11])) { g_xFLct开始[11] = 1; }
}
