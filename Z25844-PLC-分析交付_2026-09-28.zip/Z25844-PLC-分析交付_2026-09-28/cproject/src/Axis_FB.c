#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void Axis_FB_call(Axis_FB_t *self, mca_axis_info_t *Axis, plc_bit *急停, plc_bit *停止, plc_bit *半自动允许, int16_t *设备状态, plc_bit *故障复位, plc_bit *HMI_轴使能, plc_bit *HMI_找原, plc_bit *HMI_手动定位触发, plc_bit *HMI_JOG正转, plc_bit *HMI_JOG反转, double *hmi_寸动距离, plc_bit *hmi_正寸动, plc_bit *hmi_负寸动, plc_bit *HMI_位置保存, double *HMI_手动速度, double *HMI_加速度, double *HMI_减速度, double *HMI_定位速度, double *HMI_回原定位速度, int16_t *自动定位ID, plc_bit *定位方向, plc_bit *JOG条件, plc_bit *初始化找原, plc_bit *自动互锁, plc_bit *回原偏移, plc_bit *自动JOG正, plc_bit *自动JOG负, double *自动JOG速度, double *轴绝对定位位置, plc_bit *HMI_定位OK, plc_bit *HMI_正限位触发, plc_bit *HMI_负限位触发, plc_bit *HMI_原点触发, plc_bit *轴报警, plc_bit *轴使能OK, plc_bit *轴BUSY, plc_bit *轴找原OK, plc_bit *负限位报警, plc_bit *正限位报警, plc_bit *相对定位OK, double *轴当前位置, plc_bit *轴没使能) {
    static plc_bit e1 = 0;   /* 边沿: re */
    static plc_bit e2 = 0;   /* 边沿: re */
    static plc_bit e3 = 0;   /* 边沿: re */
    static plc_bit e4 = 0;   /* 边沿: re */
    static plc_bit e5 = 0;   /* 边沿: re */
    static plc_bit e6 = 0;   /* 边沿: re */
    static plc_bit e7 = 0;   /* 边沿: re */
    static plc_bit e8 = 0;   /* 边沿: re */
    static plc_bit e9 = 0;   /* 边沿: re */
    static plc_bit e10 = 0;   /* 边沿: re */
    static plc_bit e11 = 0;   /* 边沿: re */
    static plc_bit e12 = 0;   /* 边沿: re */
    static plc_bit e13 = 0;   /* 边沿: re */
    static plc_bit e14 = 0;   /* 边沿: re */
    static plc_bit e15 = 0;   /* 边沿: re */
    static plc_bit e16 = 0;   /* 边沿: re */
    static plc_bit e17 = 0;   /* 边沿: re */
    static plc_bit e18 = 0;   /* 边沿: re */
    static plc_bit e19 = 0;   /* 边沿: re */
    static plc_bit e20 = 0;   /* 边沿: re */
    static plc_bit e21 = 0;   /* 边沿: re */
    static plc_bit e22 = 0;   /* 边沿: re */
    static plc_bit e23 = 0;   /* 边沿: re */
    static plc_bit e24 = 0;   /* 边沿: re */
    static plc_bit e25 = 0;   /* 边沿: re */
    static plc_bit e26 = 0;   /* 边沿: re */
    static plc_bit e27 = 0;   /* 边沿: re */
    static plc_bit e28 = 0;   /* 边沿: re */
    static plc_bit e29 = 0;   /* 边沿: re */
    static plc_bit e30 = 0;   /* 边沿: re */
    static plc_bit e31 = 0;   /* 边沿: re */
    static plc_bit e32 = 0;   /* 边沿: re */
    static plc_bit e33 = 0;   /* 边沿: re */
    static plc_bit e34 = 0;   /* 边沿: re */
    static plc_bit e35 = 0;   /* 边沿: re */
    static plc_bit e36 = 0;   /* 边沿: re */
    static plc_bit e37 = 0;   /* 边沿: re */
    static plc_bit e38 = 0;   /* 边沿: re */

    /* IL:17108  OUT 轴模式 */
    if ((M8000) && (((((*设备状态)) == (40))) || ((((*设备状态)) == (50))))) { self->轴模式 = ((M8000) && (((((*设备状态)) == (40))) || ((((*设备状态)) == (50))))); }
    /* IL:17111  DEMOV HMI_手动速度 VAR_手动JOG速度 */
    if (M8000) { self->VAR_手动JOG速度 = (*HMI_手动速度); }
    /* IL:17113  DEMOV E10.0 VAR_手动JOG速度 */
    if ((M8000) && (((double)((*HMI_手动速度)) <= (double)(0.0)))) { self->VAR_手动JOG速度 = 10.0; }
    /* IL:17115  DEMOV 自动JOG速度 VAR_自动JOG速度 */
    if (M8000) { self->VAR_自动JOG速度 = (*自动JOG速度); }
    /* IL:17118  DEMOV E10.0 VAR_自动JOG速度 */
    if ((M8000) && (((double)((*HMI_手动速度)) <= (double)(0.0)))) { self->VAR_自动JOG速度 = 10.0; }
    /* IL:17123  DEMOV HMI_手动速度 VAR_目标速度 */
    if ((M8000) && (((((*设备状态)) == (0))) || ((((*设备状态)) == (10))))) { self->VAR_目标速度 = (*HMI_手动速度); }
    /* IL:17126  DEMOV HMI_定位速度 VAR_目标速度 */
    if ((M8000) && ((((*设备状态)) == (40)))) { self->VAR_目标速度 = (*HMI_定位速度); }
    /* IL:17129  DEMOV HMI_回原定位速度 VAR_目标速度 */
    if ((M8000) && ((((*设备状态)) == (30)))) { self->VAR_目标速度 = (*HMI_回原定位速度); }
    /* IL:17132  DEMOV E10.0 VAR_目标速度 */
    if ((M8000) && (((double)((*HMI_定位速度)) <= (double)(0.0)))) { self->VAR_目标速度 = 10.0; }
    /* IL:17134  DEMOV HMI_加速度 VAR_加速度 */
    if (M8000) { self->VAR_加速度 = (*HMI_加速度); }
    /* IL:17137  DEMOV E1000.0 VAR_加速度 */
    if ((M8000) && (((double)((*HMI_加速度)) <= (double)(0.0)))) { self->VAR_加速度 = 1000.0; }
    /* IL:17139  DEMOV HMI_减速度 VAR_减速度 */
    if (M8000) { self->VAR_减速度 = (*HMI_减速度); }
    /* IL:17142  DEMOV E1000.0 VAR_减速度 */
    if ((M8000) && (((double)((*HMI_减速度)) <= (double)(0.0)))) { self->VAR_减速度 = 1000.0; }
    /* IL:17147  DEMOV 轴当前位置 轴绝对定位位置[0] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e1, HMI_位置保存[0]))) { 轴绝对定位位置[0] = (*轴当前位置); }
    /* IL:17150  DEMOV 轴当前位置 轴绝对定位位置[1] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e2, HMI_位置保存[1]))) { 轴绝对定位位置[1] = (*轴当前位置); }
    /* IL:17153  DEMOV 轴当前位置 轴绝对定位位置[2] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e3, HMI_位置保存[2]))) { 轴绝对定位位置[2] = (*轴当前位置); }
    /* IL:17156  DEMOV 轴当前位置 轴绝对定位位置[3] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e4, HMI_位置保存[3]))) { 轴绝对定位位置[3] = (*轴当前位置); }
    /* IL:17159  DEMOV 轴当前位置 轴绝对定位位置[4] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e5, HMI_位置保存[4]))) { 轴绝对定位位置[4] = (*轴当前位置); }
    /* IL:17162  DEMOV 轴当前位置 轴绝对定位位置[5] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e6, HMI_位置保存[5]))) { 轴绝对定位位置[5] = (*轴当前位置); }
    /* IL:17165  DEMOV 轴当前位置 轴绝对定位位置[6] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e7, HMI_位置保存[6]))) { 轴绝对定位位置[6] = (*轴当前位置); }
    /* IL:17168  DEMOV 轴当前位置 轴绝对定位位置[7] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e8, HMI_位置保存[7]))) { 轴绝对定位位置[7] = (*轴当前位置); }
    /* IL:17171  DEMOV 轴当前位置 轴绝对定位位置[8] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e9, HMI_位置保存[8]))) { 轴绝对定位位置[8] = (*轴当前位置); }
    /* IL:17174  DEMOV 轴当前位置 轴绝对定位位置[9] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e10, HMI_位置保存[9]))) { 轴绝对定位位置[9] = (*轴当前位置); }
    /* IL:17177  DEMOV 轴当前位置 轴绝对定位位置[10] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e11, HMI_位置保存[10]))) { 轴绝对定位位置[10] = (*轴当前位置); }
    /* IL:17180  DEMOV 轴当前位置 轴绝对定位位置[11] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e12, HMI_位置保存[11]))) { 轴绝对定位位置[11] = (*轴当前位置); }
    /* IL:17183  DEMOV 轴当前位置 轴绝对定位位置[12] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e13, HMI_位置保存[12]))) { 轴绝对定位位置[12] = (*轴当前位置); }
    /* IL:17186  DEMOV 轴当前位置 轴绝对定位位置[13] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e14, HMI_位置保存[13]))) { 轴绝对定位位置[13] = (*轴当前位置); }
    /* IL:17189  DEMOV 轴当前位置 轴绝对定位位置[14] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e15, HMI_位置保存[14]))) { 轴绝对定位位置[14] = (*轴当前位置); }
    /* IL:17192  DEMOV 轴当前位置 轴绝对定位位置[15] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e16, HMI_位置保存[15]))) { 轴绝对定位位置[15] = (*轴当前位置); }
    /* IL:17195  DEMOV 轴当前位置 轴绝对定位位置[16] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e17, HMI_位置保存[16]))) { 轴绝对定位位置[16] = (*轴当前位置); }
    /* IL:17198  DEMOV 轴当前位置 轴绝对定位位置[17] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e18, HMI_位置保存[17]))) { 轴绝对定位位置[17] = (*轴当前位置); }
    /* IL:17201  DEMOV 轴当前位置 轴绝对定位位置[18] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e19, HMI_位置保存[18]))) { 轴绝对定位位置[18] = (*轴当前位置); }
    /* IL:17204  DEMOV 轴当前位置 轴绝对定位位置[19] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e20, HMI_位置保存[19]))) { 轴绝对定位位置[19] = (*轴当前位置); }
    /* IL:17207  DEMOV 轴当前位置 轴绝对定位位置[20] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e21, HMI_位置保存[20]))) { 轴绝对定位位置[20] = (*轴当前位置); }
    /* IL:17210  DEMOV 轴当前位置 轴绝对定位位置[21] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e22, HMI_位置保存[21]))) { 轴绝对定位位置[21] = (*轴当前位置); }
    /* IL:17213  DEMOV 轴当前位置 轴绝对定位位置[22] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e23, HMI_位置保存[22]))) { 轴绝对定位位置[22] = (*轴当前位置); }
    /* IL:17216  DEMOV 轴当前位置 轴绝对定位位置[23] */
    if (((M8000) && ((*轴找原OK))) && (RE(&e24, HMI_位置保存[23]))) { 轴绝对定位位置[23] = (*轴当前位置); }
    /* IL:17220  DEMOV 轴绝对定位位置[0] VAR_轴绝对定位位置 */
    if (((M8000) && (HMI_手动定位触发[0])) && (!(self->轴模式))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[0]; }
    /* IL:17229  DEMOV 轴绝对定位位置[1] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[1]) && (!(self->轴模式))) || (((((*自动定位ID)) == (1))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[1]; }
    /* IL:17237  DEMOV 轴绝对定位位置[2] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[2]) && (!(self->轴模式))) || (((((*自动定位ID)) == (2))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[2]; }
    /* IL:17245  DEMOV 轴绝对定位位置[3] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[3]) && (!(self->轴模式))) || (((((*自动定位ID)) == (3))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[3]; }
    /* IL:17253  DEMOV 轴绝对定位位置[4] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[4]) && (!(self->轴模式))) || (((((*自动定位ID)) == (4))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[4]; }
    /* IL:17261  DEMOV 轴绝对定位位置[5] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[5]) && (!(self->轴模式))) || (((((*自动定位ID)) == (5))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[5]; }
    /* IL:17269  DEMOV 轴绝对定位位置[6] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[6]) && (!(self->轴模式))) || (((((*自动定位ID)) == (6))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[6]; }
    /* IL:17277  DEMOV 轴绝对定位位置[7] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[7]) && (!(self->轴模式))) || (((((*自动定位ID)) == (7))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[7]; }
    /* IL:17285  DEMOV 轴绝对定位位置[8] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[8]) && (!(self->轴模式))) || (((((*自动定位ID)) == (8))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[8]; }
    /* IL:17293  DEMOV 轴绝对定位位置[9] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[9]) && (!(self->轴模式))) || (((((*自动定位ID)) == (9))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[9]; }
    /* IL:17301  DEMOV 轴绝对定位位置[10] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[10]) && (!(self->轴模式))) || (((((*自动定位ID)) == (10))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[10]; }
    /* IL:17309  DEMOV 轴绝对定位位置[11] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[11]) && (!(self->轴模式))) || (((((*自动定位ID)) == (11))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[11]; }
    /* IL:17317  DEMOV 轴绝对定位位置[12] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[12]) && (!(self->轴模式))) || (((((*自动定位ID)) == (12))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[12]; }
    /* IL:17325  DEMOV 轴绝对定位位置[13] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[13]) && (!(self->轴模式))) || (((((*自动定位ID)) == (13))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[13]; }
    /* IL:17333  DEMOV 轴绝对定位位置[14] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[14]) && (!(self->轴模式))) || (((((*自动定位ID)) == (14))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[14]; }
    /* IL:17341  DEMOV 轴绝对定位位置[15] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[15]) && (!(self->轴模式))) || (((((*自动定位ID)) == (15))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[15]; }
    /* IL:17349  DEMOV 轴绝对定位位置[16] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[16]) && (!(self->轴模式))) || (((((*自动定位ID)) == (16))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[16]; }
    /* IL:17357  DEMOV 轴绝对定位位置[17] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[17]) && (!(self->轴模式))) || (((((*自动定位ID)) == (17))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[17]; }
    /* IL:17365  DEMOV 轴绝对定位位置[18] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[18]) && (!(self->轴模式))) || (((((*自动定位ID)) == (18))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[18]; }
    /* IL:17373  DEMOV 轴绝对定位位置[19] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[19]) && (!(self->轴模式))) || (((((*自动定位ID)) == (19))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[19]; }
    /* IL:17381  DEMOV 轴绝对定位位置[20] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[20]) && (!(self->轴模式))) || (((((*自动定位ID)) == (20))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[20]; }
    /* IL:17389  DEMOV 轴绝对定位位置[21] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[21]) && (!(self->轴模式))) || (((((*自动定位ID)) == (21))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[21]; }
    /* IL:17397  DEMOV 轴绝对定位位置[22] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[22]) && (!(self->轴模式))) || (((((*自动定位ID)) == (22))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[22]; }
    /* IL:17405  DEMOV 轴绝对定位位置[23] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[23]) && (!(self->轴模式))) || (((((*自动定位ID)) == (23))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[23]; }
    /* IL:17413  DEMOV 轴绝对定位位置[24] VAR_轴绝对定位位置 */
    if ((M8000) && (((HMI_手动定位触发[24]) && (!(self->轴模式))) || (((((*自动定位ID)) == (24))) && (self->轴模式)))) { self->VAR_轴绝对定位位置 = 轴绝对定位位置[24]; }
    /* IL:17529  SET 轴绝对定位中 */
    if ((((((((((((((((((((((((((((((HMI_手动定位触发[0]) && (!(self->HMI_定位互锁[0]))) || ((HMI_手动定位触发[1]) && (!(self->HMI_定位互锁[1])))) || ((HMI_手动定位触发[2]) && (!(self->HMI_定位互锁[2])))) || ((HMI_手动定位触发[3]) && (!(self->HMI_定位互锁[3])))) || ((HMI_手动定位触发[4]) && (!(self->HMI_定位互锁[4])))) || ((HMI_手动定位触发[5]) && (!(self->HMI_定位互锁[5])))) || ((HMI_手动定位触发[6]) && (!(self->HMI_定位互锁[6])))) || ((HMI_手动定位触发[7]) && (!(self->HMI_定位互锁[7])))) || ((HMI_手动定位触发[8]) && (!(self->HMI_定位互锁[8])))) || ((HMI_手动定位触发[9]) && (!(self->HMI_定位互锁[9])))) || ((HMI_手动定位触发[10]) && (!(self->HMI_定位互锁[10])))) || ((HMI_手动定位触发[11]) && (!(self->HMI_定位互锁[11])))) || ((HMI_手动定位触发[12]) && (!(self->HMI_定位互锁[12])))) || ((HMI_手动定位触发[13]) && (!(self->HMI_定位互锁[13])))) || ((HMI_手动定位触发[14]) && (!(self->HMI_定位互锁[14])))) || ((HMI_手动定位触发[15]) && (!(self->HMI_定位互锁[15])))) || ((HMI_手动定位触发[16]) && (!(self->HMI_定位互锁[16])))) || ((HMI_手动定位触发[17]) && (!(self->HMI_定位互锁[17])))) || ((HMI_手动定位触发[18]) && (!(self->HMI_定位互锁[18])))) || ((HMI_手动定位触发[19]) && (!(self->HMI_定位互锁[19])))) || ((HMI_手动定位触发[20]) && (!(self->HMI_定位互锁[20])))) || ((HMI_手动定位触发[21]) && (!(self->HMI_定位互锁[21])))) || ((HMI_手动定位触发[22]) && (!(self->HMI_定位互锁[22])))) || ((HMI_手动定位触发[23]) && (!(self->HMI_定位互锁[23])))) || ((HMI_手动定位触发[24]) && (!(self->HMI_定位互锁[24])))) && (!(self->轴模式))) && (!((*急停)))) && ((*轴找原OK))) && (!((*轴BUSY)))) { self->轴绝对定位中 = 1; }
    /* IL:17495  DEMOV hmi_寸动距离 VAR_相对定位 */
    if (RE(&e25, (*hmi_正寸动))) { self->VAR_相对定位 = (*hmi_寸动距离); }
    /* IL:17498  DEMUL E-1 hmi_寸动距离 VAR_相对定位 */
    if (RE(&e26, (*hmi_负寸动))) { self->VAR_相对定位 = -1.0 * (*hmi_寸动距离); }
    /* IL:17531  SET 轴相对定位中 */
    if (((((((self->HMI_手动相对触发[0]) || (self->HMI_手动相对触发[1])) || (self->HMI_手动相对触发[2])) && (!(self->轴模式))) && (!((*停止)))) && ((*轴找原OK))) && (!((*轴BUSY)))) { self->轴相对定位中 = 1; }
    /* IL:17508  MC_RESET Axis - - - - */
    MC_RESET(&(*Axis), 0, 0, 0, 0);
    /* IL:17512  MC_POWER Axis 使能done - - - */
    MC_POWER(&(*Axis), &self->使能done, 0, 0, 0);
    /* IL:17517  OUT 轴使能OK */
    if ((M8000) && (((((*Axis).wPLCOpenState) > (1))) || (self->使能done))) { (*轴使能OK) = ((M8000) && (((((*Axis).wPLCOpenState) > (1))) || (self->使能done))); }
    /* IL:17521  OUT 轴没使能 */
    if (((M8000) && ((((*Axis).wPLCOpenState) == (0)))) && (!((*轴使能OK)))) { (*轴没使能) = (((M8000) && ((((*Axis).wPLCOpenState) == (0)))) && (!((*轴使能OK)))); }
    /* IL:17523  MC_READAXISERROR Axis - - ErrID[0] ErrID[1] - - */
    MC_READAXISERROR(&(*Axis), 0, 0, &self->ErrID[0], &self->ErrID[1], 0, 0);
    /* IL:17555  SET 轴报警 */
    if (((((((self->ErrID[0]) != (0))) && (((self->ErrID[0]) != (0x5444)))) && (((self->ErrID[0]) != (0x5443)))) || ((self->轴模式) && (((self->ErrID[0]) != (0))))) || (((self->ErrID[1]) != (0)))) { (*轴报警) = 1; }
    /* IL:17533  MC_READACTUALPOSITION Axis - - - - - */
    MC_READACTUALPOSITION(&(*Axis), 0, 0, 0, 0, 0);
    /* IL:17534  MC_READDIGITALINPUT Axis - - DIstatus - - */
    MC_READDIGITALINPUT(&(*Axis), 0, 0, &self->DIstatus, 0, 0);
    /* IL:17559  SET QX_正软限位中 */
    if (((M8000) && (self->ix_软限位使能)) && (((double)(self->HMI_正软限位) >= (double)((*轴当前位置))))) { self->QX_正软限位中 = 1; }
    /* IL:17567  SET QX_负软限位中 */
    if (((M8000) && (self->ix_软限位使能)) && (((double)(self->HMI_负软限位) <= (double)((*轴当前位置))))) { self->QX_负软限位中 = 1; }
    /* IL:17545  RST 自动JOG正 */
    if ((M8000) && (!(self->轴模式))) { (*自动JOG正) = 0; }
    /* IL:17546  RST 自动JOG负 */
    if ((M8000) && (!(self->轴模式))) { (*自动JOG负) = 0; }
    /* IL:17558  OUT JOG正 */
    if (((M8000) && ((((!(self->轴模式)) && ((*HMI_JOG正转))) && (!((*HMI_JOG反转)))) || (((self->轴模式) && ((*自动JOG正))) && (!((*自动JOG负)))))) && (!((*JOG条件)))) { self->JOG正 = (((M8000) && ((((!(self->轴模式)) && ((*HMI_JOG正转))) && (!((*HMI_JOG反转)))) || (((self->轴模式) && ((*自动JOG正))) && (!((*自动JOG负)))))) && (!((*JOG条件)))); }
    /* IL:17569  OUT JOG负 */
    if (((M8000) && ((((!(self->轴模式)) && ((*HMI_JOG反转))) && (!((*HMI_JOG正转)))) || (((self->轴模式) && ((*自动JOG负))) && (!((*自动JOG正)))))) && (!((*JOG条件)))) { self->JOG负 = (((M8000) && ((((!(self->轴模式)) && ((*HMI_JOG反转))) && (!((*HMI_JOG正转)))) || (((self->轴模式) && ((*自动JOG负))) && (!((*自动JOG正)))))) && (!((*JOG条件)))); }
    /* IL:17575  DEMOV VAR_手动JOG速度 轴JOG速度 */
    if (((M8000) && (((*HMI_JOG正转)) || ((*HMI_JOG反转)))) && (!(self->轴模式))) { self->轴JOG速度 = self->VAR_手动JOG速度; }
    /* IL:17581  DEMOV VAR_自动JOG速度 轴JOG速度 */
    if (((M8000) && (((*自动JOG正)) || ((*自动JOG负)))) && (self->轴模式)) { self->轴JOG速度 = self->VAR_自动JOG速度; }
    /* IL:17593  MC_JOG Axis JOG正 JOG负 轴JOG速度 VAR_加速度 VAR_减速度 - Jog_Busy - - - */
    MC_JOG(&(*Axis), &self->JOG正, &self->JOG负, &self->轴JOG速度, &self->VAR_加速度, &self->VAR_减速度, 0, &self->Jog_Busy, 0, 0, 0);
    /* IL:17598  RST 轴找原OK */
    if ((M8000) && ((RE(&e27, (*HMI_找原))) || (RE(&e28, (*初始化找原))))) { (*轴找原OK) = 0; }
    /* IL:17604  OUT 找原中 */
    if (((((RE(&e29, (*HMI_找原))) || (RE(&e30, (*初始化找原)))) && (!((*停止)))) && (!((*急停)))) && ((((*Axis).wPLCOpenState) == (3)))) { self->找原中 = (((((RE(&e29, (*HMI_找原))) || (RE(&e30, (*初始化找原)))) && (!((*停止)))) && (!((*急停)))) && ((((*Axis).wPLCOpenState) == (3)))); }
    /* IL:17608  MC_HOME Axis E0 HomeOK Home_Busy - - - */
    MC_HOME(&(*Axis), 0.0, &self->HomeOK, &self->Home_Busy, 0, 0, 0);
    /* IL:17611  MC_MOVEABSOLUTE Axis 回原偏移 E30 E500 E500 - - 回原偏移完成 - - - - */
    MC_MOVEABSOLUTE(&(*Axis), &(*回原偏移), 30.0, 500.0, 500.0, 0, 0, &self->回原偏移完成, 0, 0, 0, 0);
    /* IL:17614  MC_SETPOSITION Axis E0 - 回原修改位置OK - - - */
    MC_SETPOSITION(&(*Axis), 0.0, 0, &self->回原修改位置OK, 0, 0, 0);
    /* IL:17640  SET 轴找原OK */
    if ((M8000) && (RE(&e32, self->回原修改位置OK))) { (*轴找原OK) = 1; }
    /* IL:17623  RST HMI_找原 */
    if ((M8000) && (((RE(&e33, self->Home_Busy)) || ((*停止))) || ((*急停)))) { (*HMI_找原) = 0; }
    /* IL:17624  RST 初始化找原 */
    if ((M8000) && (((RE(&e33, self->Home_Busy)) || ((*停止))) || ((*急停)))) { (*初始化找原) = 0; }
    /* IL:17661  SET 自动标定 */
    if (RE(&e34, (M8000) && (((self->OLD_自动ID) == (0))))) { self->自动标定 = 1; }
    /* IL:17636  TONR K10 - Abs_延时 - */
    TON(NULL, NULL, 10, ((M8000) && ((self->轴绝对定位中) || (((self->轴模式) && (!((*自动互锁)))) && ((((*自动定位ID)) > (0)))))), (self->Abs_延时), dt_ms);
    /* IL:17638  MOV 自动定位ID OLD_自动ID */
    if (M8000) { self->OLD_自动ID = (*自动定位ID); }
    /* IL:17643  MC_MOVEABSOLUTE Axis VAR_轴绝对定位位置 VAR_目标速度 VAR_加速度 VAR_减速度 - 定位方向 AbsOK Abs_Busy - Abs_Err - */
    MC_MOVEABSOLUTE(&(*Axis), &self->VAR_轴绝对定位位置, &self->VAR_目标速度, &self->VAR_加速度, &self->VAR_减速度, 0, &(*定位方向), &self->AbsOK, &self->Abs_Busy, 0, &self->Abs_Err, 0);
    /* IL:17651  RST 轴绝对定位中 */
    if ((M8000) && (((((self->Abs_Busy) || (self->AbsOK)) || (self->Abs_Err)) || ((*停止))) || (RE(&e35, (*急停))))) { self->轴绝对定位中 = 0; }
    /* IL:17652  RST 自动标定 */
    if ((M8000) && (((((self->Abs_Busy) || (self->AbsOK)) || (self->Abs_Err)) || ((*停止))) || (RE(&e35, (*急停))))) { self->自动标定 = 0; }
    /* IL:17653  ZRST HMI_手动定位触发[0] HMI_手动定位触发[24] */
    if ((M8000) && (((((self->Abs_Busy) || (self->AbsOK)) || (self->Abs_Err)) || ((*停止))) || (RE(&e35, (*急停))))) { FILLB(&HMI_手动定位触发[0], 0, 25); }
    /* IL:17654  MOV 自动定位ID OLD_自动定位ID */
    if ((M8000) && (((((self->Abs_Busy) || (self->AbsOK)) || (self->Abs_Err)) || ((*停止))) || (RE(&e35, (*急停))))) { self->OLD_自动定位ID = (*自动定位ID); }
    /* IL:17655  DEMOV VAR_轴绝对定位位置 OLD_绝对定位 */
    if ((M8000) && (((((self->Abs_Busy) || (self->AbsOK)) || (self->Abs_Err)) || ((*停止))) || (RE(&e35, (*急停))))) { self->OLD_绝对定位 = self->VAR_轴绝对定位位置; }
    /* IL:17656  MOV K0 自动定位ID */
    if ((M8000) && (((((self->Abs_Busy) || (self->AbsOK)) || (self->Abs_Err)) || ((*停止))) || (RE(&e35, (*急停))))) { (*自动定位ID) = 0; }
    /* IL:17659  TONR K100 - Rel_延时 - */
    TON(NULL, NULL, 100, ((M8000) && (self->HMI_手动相对触发[0])), (self->Rel_延时), dt_ms);
    /* IL:17669  MC_MOVERELATIVE Axis VAR_相对定位 VAR_目标速度 VAR_加速度 VAR_减速度 - RelOK Rel_Busy - Rel_Err - */
    MC_MOVERELATIVE(&(*Axis), &self->VAR_相对定位, &self->VAR_目标速度, &self->VAR_加速度, &self->VAR_减速度, 0, &self->RelOK, &self->Rel_Busy, 0, &self->Rel_Err, 0);
    /* IL:17676  RST HMI_手动相对触发[0] */
    if ((M8000) && ((((self->Rel_Busy) || (self->Rel_Err)) || ((*停止))) || ((*急停)))) { self->HMI_手动相对触发[0] = 0; }
    /* IL:17680  OUT 相对定位OK */
    if (((self->Rel_Err) || (RE(&e38, self->Home_Busy))) || ((*急停))) { (*相对定位OK) = (((self->Rel_Err) || (RE(&e38, self->Home_Busy))) || ((*急停))); }
    /* IL:17691  MC_STOP Axis E15000 K0 Stop_Done - Stop_Error - */
    MC_STOP(&(*Axis), 15000.0, 0, &self->Stop_Done, 0, &self->Stop_Error, 0);
    /* IL:17696  RST 停止 */
    if ((M8000) && ((self->Stop_Done) || (self->Stop_Error))) { (*停止) = 0; }
    /* IL:17698  DEADD Axis.fSetPosition E0.05 当前位置上限 */
    if (M8000) { self->当前位置上限 = (*Axis).fSetPosition + 0.05; }
    /* IL:17699  DESUB Axis.fSetPosition E0.05 当前位置下限 */
    if (M8000) { self->当前位置下限 = (*Axis).fSetPosition - 0.05; }
    /* IL:17702  TONR K5 - 自动id延时 - */
    TON(NULL, NULL, 5, ((M8000) && ((((*自动定位ID)) == (0)))), (self->自动id延时), dt_ms);
    /* IL:17709  OUT HMI_定位OK[0] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[0])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[0])))) { HMI_定位OK[0] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[0])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[0])))); }
    /* IL:17713  OUT HMI_定位OK[1] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[1])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[1])))) { HMI_定位OK[1] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[1])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[1])))); }
    /* IL:17717  OUT HMI_定位OK[2] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[2])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[2])))) { HMI_定位OK[2] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[2])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[2])))); }
    /* IL:17721  OUT HMI_定位OK[3] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[3])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[3])))) { HMI_定位OK[3] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[3])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[3])))); }
    /* IL:17725  OUT HMI_定位OK[4] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[4])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[4])))) { HMI_定位OK[4] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[4])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[4])))); }
    /* IL:17729  OUT HMI_定位OK[5] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[5])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[5])))) { HMI_定位OK[5] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[5])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[5])))); }
    /* IL:17733  OUT HMI_定位OK[6] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[6])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[6])))) { HMI_定位OK[6] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[6])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[6])))); }
    /* IL:17737  OUT HMI_定位OK[7] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[7])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[7])))) { HMI_定位OK[7] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[7])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[7])))); }
    /* IL:17741  OUT HMI_定位OK[8] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[8])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[8])))) { HMI_定位OK[8] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[8])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[8])))); }
    /* IL:17745  OUT HMI_定位OK[9] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[9])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[9])))) { HMI_定位OK[9] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[9])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[9])))); }
    /* IL:17749  OUT HMI_定位OK[10] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[10])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[10])))) { HMI_定位OK[10] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[10])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[10])))); }
    /* IL:17753  OUT HMI_定位OK[11] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[11])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[11])))) { HMI_定位OK[11] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[11])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[11])))); }
    /* IL:17757  OUT HMI_定位OK[12] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[12])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[12])))) { HMI_定位OK[12] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[12])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[12])))); }
    /* IL:17761  OUT HMI_定位OK[13] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[13])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[13])))) { HMI_定位OK[13] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[13])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[13])))); }
    /* IL:17765  OUT HMI_定位OK[14] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[14])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[14])))) { HMI_定位OK[14] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[14])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[14])))); }
    /* IL:17769  OUT HMI_定位OK[15] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[15])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[15])))) { HMI_定位OK[15] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[15])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[15])))); }
    /* IL:17773  OUT HMI_定位OK[16] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[16])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[16])))) { HMI_定位OK[16] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[16])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[16])))); }
    /* IL:17777  OUT HMI_定位OK[17] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[17])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[17])))) { HMI_定位OK[17] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[17])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[17])))); }
    /* IL:17781  OUT HMI_定位OK[18] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[18])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[18])))) { HMI_定位OK[18] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[18])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[18])))); }
    /* IL:17785  OUT HMI_定位OK[19] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[19])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[19])))) { HMI_定位OK[19] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[19])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[19])))); }
    /* IL:17789  OUT HMI_定位OK[20] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[20])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[20])))) { HMI_定位OK[20] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[20])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[20])))); }
    /* IL:17793  OUT HMI_定位OK[21] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[21])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[21])))) { HMI_定位OK[21] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[21])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[21])))); }
    /* IL:17797  OUT HMI_定位OK[22] */
    if (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[22])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[22])))) { HMI_定位OK[22] = (((((self->自动id延时) && ((*轴找原OK))) && (!((*轴BUSY)))) && (((double)(self->当前位置下限) <= (double)(轴绝对定位位置[22])))) && (((double)(self->当前位置上限) >= (double)(轴绝对定位位置[22])))); }
    /* IL:17803  OUT 轴BUSY */
    if (((((self->Jog_Busy) || (self->Home_Busy)) || (self->Abs_Busy)) || (self->Rel_Busy)) || (self->buffer_Busy)) { (*轴BUSY) = (((((self->Jog_Busy) || (self->Home_Busy)) || (self->Abs_Busy)) || (self->Rel_Busy)) || (self->buffer_Busy)); }
    /* IL:17807  OUT HMI_正限位触发 */
    if ((M8000) && (BIT_R(self->DIstatus, 1))) { (*HMI_正限位触发) = ((M8000) && (BIT_R(self->DIstatus, 1))); }
    /* IL:17810  OUT HMI_负限位触发 */
    if ((M8000) && (BIT_R(self->DIstatus, 0))) { (*HMI_负限位触发) = ((M8000) && (BIT_R(self->DIstatus, 0))); }
    /* IL:17813  OUT HMI_原点触发 */
    if ((M8000) && (BIT_R(self->DIstatus, 2))) { (*HMI_原点触发) = ((M8000) && (BIT_R(self->DIstatus, 2))); }
    /* IL:17823  OUT 负限位报警 */
    if ((M8000) && (((((*HMI_负限位触发)) && ((((*Axis).wPLCOpenState) != (7)))) && (!(self->Home_Busy))) || (((*负限位报警)) && (!((*故障复位)))))) { (*负限位报警) = ((M8000) && (((((*HMI_负限位触发)) && ((((*Axis).wPLCOpenState) != (7)))) && (!(self->Home_Busy))) || (((*负限位报警)) && (!((*故障复位)))))); }
    /* IL:17832  OUT 正限位报警 */
    if ((M8000) && (((((*HMI_正限位触发)) && ((((*Axis).wPLCOpenState) != (7)))) && (!(self->Home_Busy))) || (((*正限位报警)) && (!((*故障复位)))))) { (*正限位报警) = ((M8000) && (((((*HMI_正限位触发)) && ((((*Axis).wPLCOpenState) != (7)))) && (!(self->Home_Busy))) || (((*正限位报警)) && (!((*故障复位)))))); }
    /* IL:17836  RST 轴报警 */
    if (((M8000) && ((*故障复位))) && (M8000)) { (*轴报警) = 0; }
    /* IL:17838  DEMOV Axis.fActPosition 轴当前位置 */
    if (M8000) { (*轴当前位置) = (*Axis).fActPosition; }
}
