#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void SBR_扫码相机(void) {
    static plc_bit e1 = 0;   /* 边沿: re */
    static plc_bit e2 = 0;   /* 边沿: re */
    static plc_bit e3 = 0;   /* 边沿: re */
    static plc_bit e4 = 0;   /* 边沿: re */
    static plc_bit e5 = 0;   /* 边沿: re */
    static plc_bit e6 = 0;   /* 边沿: re */

    /* IL:5897  STRMOV start g_x扫码枪1发送数据 */
    if (M8000) { STRCPY(&g_x扫码枪1发送数据, "start"); }
    /* IL:5898  STRMOV NG g_x扫码枪1NG字符 */
    if (M8000) { STRCPY(&g_x扫码枪1NG字符, "NG"); }
    /* IL:5899  DMOV K2001 扫码枪1端口号 */
    if (M8000) { 扫码枪1端口号 = 2001; }
    if (M8000) { /* IL:5901  CALL_FB 扫码枪FB 扫码枪1 MIAN_故障清除 扫码枪1IP 扫码枪1端口号 M8000 HMI_扫码枪1手动扫码触发 g_x扫码枪1自动扫码触发 g_x扫码枪1发送数据 g_x扫码枪1NG字符 HMI_扫码枪1NG重扫次数 err_扫码枪1扫码NG HMI_扫码枪1当前条码 err_扫码枪1接收超时 err_扫码枪1连接超时 */
        扫码枪FB_call(&扫码枪1, &MIAN_故障清除, &扫码枪1IP, &扫码枪1端口号, &M8000, &HMI_扫码枪1手动扫码触发, &g_x扫码枪1自动扫码触发, &g_x扫码枪1发送数据, &g_x扫码枪1NG字符, &HMI_扫码枪1NG重扫次数, &err_扫码枪1扫码NG, &HMI_扫码枪1当前条码, &err_扫码枪1接收超时, &err_扫码枪1连接超时); }
    if (M8000) { /* IL:5902  CALL_FB FB_扫码检测旧码 扫码枪1对比 撕膜进料工位条码 扫码枪1扫码字符 K20 g_x扫码枪1条码检测 g_x扫码枪1条码检测OK g_x扫码枪1条码重复 */
        FB_扫码检测旧码_call(&扫码枪1对比, &撕膜进料工位条码, &扫码枪1扫码字符, &(int16_t){20}, &g_x扫码枪1条码检测, &g_x扫码枪1条码检测OK, &g_x扫码枪1条码重复); }
    /* IL:5904  STRMOV start g_x扫码枪2发送数据 */
    if (M8000) { STRCPY(&g_x扫码枪2发送数据, "start"); }
    /* IL:5905  STRMOV NG g_x扫码枪2NG字符 */
    if (M8000) { STRCPY(&g_x扫码枪2NG字符, "NG"); }
    /* IL:5906  DMOV K2001 扫码枪2端口号 */
    if (M8000) { 扫码枪2端口号 = 2001; }
    if (M8000) { /* IL:5908  CALL_FB 扫码枪FB 扫码枪2 MIAN_故障清除 扫码枪2IP 扫码枪2端口号 M8000 HMI_扫码枪2手动扫码触发 g_x扫码枪2自动扫码触发 g_x扫码枪2发送数据 g_x扫码枪2NG字符 HMI_扫码枪2NG重扫次数 err_扫码枪2扫码NG HMI_扫码枪2当前条码 err_扫码枪2接收超时 err_扫码枪2连接超时 */
        扫码枪FB_call(&扫码枪2, &MIAN_故障清除, &扫码枪2IP, &扫码枪2端口号, &M8000, &HMI_扫码枪2手动扫码触发, &g_x扫码枪2自动扫码触发, &g_x扫码枪2发送数据, &g_x扫码枪2NG字符, &HMI_扫码枪2NG重扫次数, &err_扫码枪2扫码NG, &HMI_扫码枪2当前条码, &err_扫码枪2接收超时, &err_扫码枪2连接超时); }
    if (M8000) { /* IL:5909  CALL_FB FB_扫码检测旧码 扫码枪2对比 AOI检测工位条码 HMI_扫码枪2当前条码 K20 g_x扫码枪2条码检测 g_x扫码枪2条码检测OK g_x扫码枪2条码重复 */
        FB_扫码检测旧码_call(&扫码枪2对比, &AOI检测工位条码, &HMI_扫码枪2当前条码, &(int16_t){20}, &g_x扫码枪2条码检测, &g_x扫码枪2条码检测OK, &g_x扫码枪2条码重复); }
    /* IL:5914  MOVP K0 AOI1检测返回结果 */
    if (RE(&e1, ((M8000) && (!(HMI_手自动切换))) && (HMI_AOI1检测拍照触发))) { AOI1检测返回结果 = 0; }
    /* IL:5915  MOVP K2 AOI1检测触发拍照 */
    if (RE(&e2, ((M8000) && (!(HMI_手自动切换))) && (HMI_AOI1检测拍照触发))) { AOI1检测触发拍照 = 2; }
    /* IL:5918  MOVP K0 AOI1检测返回结果 */
    if (RE(&e3, ((M8000) && (!(HMI_手自动切换))) && (HMI_AOI1FL定位拍照触发))) { AOI1检测返回结果 = 0; }
    /* IL:5919  MOVP K1 AOI1检测触发拍照 */
    if (RE(&e4, ((M8000) && (!(HMI_手自动切换))) && (HMI_AOI1FL定位拍照触发))) { AOI1检测触发拍照 = 1; }
    /* IL:5922  MOVP K0 AOI2检测返回结果 */
    if (RE(&e5, ((M8000) && (!(HMI_手自动切换))) && (HMI_AOI2检测拍照触发))) { AOI2检测返回结果 = 0; }
    /* IL:5923  MOVP K1 AOI2检测触发拍照 */
    if (RE(&e6, ((M8000) && (!(HMI_手自动切换))) && (HMI_AOI2检测拍照触发))) { AOI2检测触发拍照 = 1; }
}
