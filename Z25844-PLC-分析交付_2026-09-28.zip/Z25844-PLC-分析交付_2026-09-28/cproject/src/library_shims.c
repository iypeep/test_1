#include "symbols.h"

/* ==========================================================================
 * library_shims.c —— 外部耦合指令的替身
 *
 * 真实 PLC 里这些指令由硬件/协议栈/内置运动引擎完成，纯 C 无法复现：
 *   MC_*                    内置运动控制（PLCopen），实际执行在 EtherCAT 伺服/电缸
 *   TCP_*                   自由口 socket（扫码枪）
 *   ETC_WRITEPARAMETER_COE  EtherCAT CoE 写参数（SDO）
 *
 * 这里保留调用形态与工程实际实参（便于顺着调用链读），
 * 并在 MC_* 上做**最小可运行等效**：维护轴的使能/目标位置，其余交 sim/ 积分。
 * ========================================================================== */

/* 轴使能（PLCopen MC_Power） */
void MC_POWER(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 原点回归 */
void MC_HOME(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 点动 */
void MC_JOG(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 绝对定位 */
void MC_MOVEABSOLUTE(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 相对定位 */
void MC_MOVERELATIVE(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 停止 */
void MC_STOP(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 轴报警复位 */
void MC_RESET(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 设置当前位置 */
void MC_SETPOSITION(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 读实际位置 */
void MC_READACTUALPOSITION(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 读轴故障码 */
void MC_READAXISERROR(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 读轴数字输入 */
void MC_READDIGITALINPUT(void *a0, ...) { (void)a0; }   /* 轴状态由 sim_axis_step() 推进 */

/* 建立 TCP 连接（扫码枪自由口） */
void TCP_CONNECT(void *a0, ...) { (void)a0; }

/* TCP 发送 */
void TCP_SEND(void *a0, ...) { (void)a0; }

/* TCP 接收 */
void TCP_RECEIVE(void *a0, ...) { (void)a0; }

/* EtherCAT CoE 写参数（SDO） */
void ETC_WRITEPARAMETER_COE(void *a0, ...) { (void)a0; }

