#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"

/* ============================================================================
 * plc_scan() —— 一个 PLC 扫描周期
 * 对应原工程 MAIN.LD 的调用网络（IL 0278–0312）：34 个子程序每周期无条件调用，
 * 顺序固定；每个子程序内部再用 HMI_自动中[n] / HMI_工位屏蔽[n] / HMI_自动流程[n]
 * 决定本周期动作。
 * ========================================================================== */
void SBR_01自动撕膜位进料(void);
void SBR_01自动机器人1位进料(void);
void SBR_01自动机器人2位进料(void);
void SBR_02自动保压(void);
void SBR_02自动撕膜机构(void);
void SBR_02自动机器人2插接(void);
void SBR_03自动NG下料模组(void);
void SBR_03自动机器人1插接FPC2(void);
void SBR_04自动下料皮带4段(void);
void SBR_05自动下料皮带1段(void);
void SBR_05自动下料皮带2段(void);
void SBR_05自动下料皮带3段(void);
void SBR_06自动ng下料皮带(void);
void SBR_07自动插FL(void);
void SBR_08自动FL抚平(void);
void SBR_09自动FL电缸提前等待(void);
void SBR_0整机初始化(void);
void SBR_10撕膜工位初始化(void);
void SBR_10自动流道2出料(void);
void SBR_11机器人1位初始化(void);
void SBR_12机器人2位初始化(void);
void SBR_13下料工位初始化(void);
void SBR_CT产能(void);
void SBR_压力传感器(void);
void SBR_扫码相机(void);
void SBR_报警(void);
void SBR_机器人(void);
void SBR_气缸映射(void);
void SBR_电缸控制(void);
void SBR_皮带控制(void);
void SBR_真空映射(void);
void SBR_自动机器人1插接FPC2抚平动作(void);
void SBR_轴实例化(void);

void plc_scan(void) {
    SBR_01自动撕膜位进料();
    SBR_01自动机器人1位进料();
    SBR_01自动机器人2位进料();
    SBR_02自动保压();
    SBR_02自动撕膜机构();
    SBR_02自动机器人2插接();
    SBR_03自动NG下料模组();
    SBR_03自动机器人1插接FPC2();
    SBR_04自动下料皮带4段();
    SBR_05自动下料皮带1段();
    SBR_05自动下料皮带2段();
    SBR_05自动下料皮带3段();
    SBR_06自动ng下料皮带();
    SBR_07自动插FL();
    SBR_08自动FL抚平();
    SBR_09自动FL电缸提前等待();
    SBR_0整机初始化();
    SBR_10撕膜工位初始化();
    SBR_10自动流道2出料();
    SBR_11机器人1位初始化();
    SBR_12机器人2位初始化();
    SBR_13下料工位初始化();
    SBR_CT产能();
    SBR_压力传感器();
    SBR_扫码相机();
    SBR_报警();
    SBR_机器人();
    SBR_气缸映射();
    SBR_电缸控制();
    SBR_皮带控制();
    SBR_真空映射();
    SBR_自动机器人1插接FPC2抚平动作();
    SBR_轴实例化();
}

/* 上电初始化：M8002 只在首次扫描为 1（对应原工程的初始化网络） */
void plc_init(void) {
    M8000 = 1;
    M8002 = 1;
    plc_scan();
    M8002 = 0;
}
