#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

void 扫码枪FB_call(扫码枪FB_t *self, plc_bit *报警复位, plc_bit *IP地址, plc_bit *端口号, plc_bit *连接请求, plc_bit *手动扫码, plc_bit *自动扫码, plc_bit *发送触发扫码数据, int16_t *NG字符, int16_t *重扫次数, plc_bit *err扫码NG, plc_bit *当前条码, plc_bit *err接收超时, plc_bit *err连接超时) {
    static plc_bit e1 = 0;   /* 边沿: re */
    static plc_bit e2 = 0;   /* 边沿: re */

    /* IL:8027  OUT 扫码连接 */
    if ((((*连接请求)) && (M8013)) || (self->连接成功)) { self->扫码连接 = ((((*连接请求)) && (M8013)) || (self->连接成功)); }
    /* IL:8031  TONR K5000 - 连接超时 - */
    TON(NULL, NULL, 5000, ((((*连接请求)) && (!((*err连接超时)))) && (!(self->连接成功))), (self->连接超时), dt_ms);
    /* IL:8083  SET err连接超时 */
    if (self->连接超时) { (*err连接超时) = 1; }
    /* IL:8035  RST err连接超时 */
    if (RE(&e1, self->连接成功)) { (*err连接超时) = 0; }
    /* IL:8037  TCP_CONNECT Socket_扫码枪 IP地址 端口号 连接成功 - - 连接故障 */
    TCP_CONNECT(&self->Socket_扫码枪, &(*IP地址), &(*端口号), &self->连接成功, 0, 0, &self->连接故障);
    /* IL:8039  RST 手动扫码 */
    if (!(self->连接成功)) { (*手动扫码) = 0; }
    /* IL:8040  RST 自动扫码 */
    if (!(self->连接成功)) { (*自动扫码) = 0; }
    /* IL:8041  RST 扫码触发 */
    if (!(self->连接成功)) { self->扫码触发 = 0; }
    /* IL:8043  TONR K50 - 延时tt - */
    TON(NULL, NULL, 50, (self->进行重扫码), (self->延时tt), dt_ms);
    /* IL:8084  SET 扫码触发 */
    if (RE(&e2, ((((*手动扫码)) || ((*自动扫码))) || (self->延时tt)) && (self->连接成功))) { self->扫码触发 = 1; }
    /* IL:8050  ZRST 接收的条码[0] 接收的条码[19] */
    if (RE(&e2, ((((*手动扫码)) || ((*自动扫码))) || (self->延时tt)) && (self->连接成功))) { FILL(&self->接收的条码[0], 0, 20); }
    /* IL:8051  RST 进行重扫码 */
    if (RE(&e2, ((((*手动扫码)) || ((*自动扫码))) || (self->延时tt)) && (self->连接成功))) { self->进行重扫码 = 0; }
    /* IL:8053  LEN 发送触发扫码数据 发送长度 */
    if (M8000) { self->发送长度[0] = STRLEN(&(*发送触发扫码数据)); }
    /* IL:8056  TCP_SEND Socket_扫码枪 发送触发扫码数据 发送长度[0] 发送OK - - - - */
    TCP_SEND(&self->Socket_扫码枪, &(*发送触发扫码数据), &self->发送长度[0], &self->发送OK, 0, 0, 0, 0);
    /* IL:8058  TCP_RECEIVE Socket_扫码枪 接收的条码 K100 接收完成 - - 接收err - */
    TCP_RECEIVE(&self->Socket_扫码枪, &self->接收的条码[0], 100, &self->接收完成, 0, 0, &self->接收err, 0);
    /* IL:8061  RST 扫码触发 */
    if ((self->接收完成) || ((*err接收超时))) { self->扫码触发 = 0; }
    /* IL:8062  RST 手动扫码 */
    if ((self->接收完成) || ((*err接收超时))) { (*手动扫码) = 0; }
    /* IL:8063  RST 自动扫码 */
    if ((self->接收完成) || ((*err接收超时))) { (*自动扫码) = 0; }
    /* IL:8065  TONR K5000 - 接收超时 - */
    TON(NULL, NULL, 5000, (self->发送OK), (self->接收超时), dt_ms);
    /* IL:8087  SET err接收超时 */
    if (self->接收超时) { (*err接收超时) = 1; }
    /* IL:8069  RST err接收超时 */
    if ((*报警复位)) { (*err接收超时) = 0; }
    /* IL:8070  RST err连接超时 */
    if ((*报警复位)) { (*err连接超时) = 0; }
    /* IL:8071  RST err扫码NG */
    if ((*报警复位)) { (*err扫码NG) = 0; }
    /* IL:8118  SET 进行NG扫码对比 */
    if (self->接收完成) { self->进行NG扫码对比 = 1; }
    /* IL:8079  INCP NG扫码计数 */
    if ((((self->进行NG扫码对比) && (((NG字符[0]) == (self->接收的条码[0])))) && (((NG字符[1]) == (self->接收的条码[1])))) && (((NG字符[3]) == (self->接收的条码[2])))) { self->NG扫码计数 += 1; }
    /* IL:8158  SET 进行重扫码 */
    if (((self->进行NG扫码对比) && (((self->NG扫码计数) != (0)))) && (((self->NG扫码计数) < ((*重扫次数))))) { self->进行重扫码 = 1; }
    /* IL:8085  RST 进行NG扫码对比 */
    if (self->进行NG扫码对比) { self->进行NG扫码对比 = 0; }
    /* IL:8165  SET err扫码NG */
    if (((self->NG扫码计数) > ((*重扫次数)))) { (*err扫码NG) = 1; }
    /* IL:8088  MOV K0 NG扫码计数 */
    if (((self->NG扫码计数) > ((*重扫次数)))) { self->NG扫码计数 = 0; }
    /* IL:8090  BMOV 接收的条码 当前条码 K40 */
    if (M8000) { BLKMOV(&(*当前条码), &self->接收的条码[0], 40); }
}
