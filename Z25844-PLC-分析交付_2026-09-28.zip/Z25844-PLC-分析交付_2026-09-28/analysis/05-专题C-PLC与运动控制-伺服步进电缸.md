# 05 专题C：PLC 与运动控制 —— 伺服 / 步进 / 电缸

> 本章回答三个问题：
> 1. **"运动控制板卡"和 PLC 是什么关系**？这台机为什么没有独立的运动控制卡？
> 2. PLC 怎么控**伺服**、怎么控**步进**？
> 3. PLC 怎么控**电缸**（这台机有 10 个，还用两种完全不同的方式）？

---

## 5.0 先搞清概念：运动控制卡 vs PLC 内置运动控制

| | 传统"运动控制板卡"方案 | 本机（汇川 H5U）方案 |
|---|---|---|
| 拓扑 | PC + PCIe/PCI 运动控制卡，卡出**脉冲/模拟量**给驱动器；PLC 只管 IO 和逻辑 | PLC **内置运动控制引擎**（软运动），EtherCAT/脉冲直接出轴，逻辑与运动在同一个 CPU 里 |
| 编程 | 卡厂商的 SDK/C 库（`dll` 调用），程序跑在 PC 上 | PLC 侧 **PLCopen 标准功能块**（`MC_Power` 等），梯形图/ST 直接调用，和气缸逻辑同源 |
| 同步性 | 需要自己处理 PC 与卡的实时性、通信延迟 | 轴在 PLC 扫描周期内执行，逻辑与运动天然同周期、无通信抖动 |
| 轴数量 | 受卡通道数限制，扩容要加卡 | 受 PLC 支持轴数/EtherCAT 从站数限制，加从站即可 |
| 适用 | 高速多轴插补、轨迹（贴片机、CNC） | 点位/压装/插接类自动化设备（**本机就是这一类**） |

**关键概念：H5U 内部的"轴对象"（`_sMCAXIS_INFO`）**

AutoShop 的 H5U 运动控制不是"给个脉冲就完事"，每个轴都有一整套标准对象（本次分析从 `Axis_FB.FB` 里完整提取，共 90 多个字段），涵盖：

| 分组 | 字段（节选） | 说明 |
|---|---|---|
| 控制模式 | `WMODESOFOPERATION` / `WMODESOFOPERATIONDISPLAY` | CiA402 控制模式（位置/速度/力矩） |
| PLCopen 状态机 | `WPLCOPENSTATE` | 轴状态机（Standstill/Discrete Motion/Continuous/ErrorStop…），`MC_*` 指令据此动作 |
| 指令触发位 | `BPOWERON` `BHOME` `BJOGP/BJOGN` `BABSPOS` `BRELPOS` `BVELOCITY` `BTORQUE` `BSTOP` `BRESET` `BSETPOS` `BREVPOS` `BENTERDEBUG` | 对应每个 `MC_*` 指令的使能 |
| 参数 | `FTARPOSITION1/2` `FTARVELOCITY1/2` `FTARACCELERATION1/2` `FTARDECELARATION1/2` `FTARTORQUE` `FMAXVELOCITY` `FMAXACC` `FLIMITVELOCITY` | 定位位置/速度/加减速/力矩/最大速度 |
| 反馈（只读，PDO） | `DACTPOSITION`(0x6064) `DACTVELOCITY` `DACTTORQUE` `FFOLLOWPOS` `WSTATUSWORD` `WMODESOFOPERATIONDISPLAY` `WERRORCODE` `WAXISERROR` `WSERVOERROR` | 伺服对象字典直通（注释里明确写了 `0x6064`） |
| 回零 | `IHOMEMETHOD` `FHOMEVELOCITY` `FHOMEACCELERATION` `FHOMEAPPROACHVELOCITY` `FPOSITIONOFFSER` `DHOMETIMEOUT` `BHOMESTATE` | 原点回归方式/速度/偏移/超时 |
| 限位 | `BPSLIMIT` `BNSLIMIT` `BPHLIMIT` `BNHLIMIT` `FPLIMIT` `FNLIMIT` `FERRORSTOPDECELERATION` | 软/硬限位、限位减速度 |
| **探针（Touch Probe）** | `WTOUCHFUNCTION` `WTOUCHSTATUS` `DTOUCH1PPOS/NPOS` `DTOUCH2PPOS/NPOS` | 位置锁存/飞拍（≈ 板卡的"位置比较输出/锁存"） |
| 机械参数 | `DNUMERATOR`/`DDENOMINATOR`（齿轮比）、`FUNITS`、`DPLUSEPRECYCLE`（一圈脉冲数）、`ILINEROTATEMODE`（线性/旋转） | 电子齿轮、单位换算 |
| 调试 | `BENTERDEBUG` `BDEBUGSTATE` `WDEBUGMOTIONTYPE` | 手动调试（点动/寸动） |
| 本地脉冲轴专用 | `DLOCIALAXISSETPOS` "本地脉冲轴设置位置"、`IPLUSEMETHOD` "脉冲输出方式（本地脉冲轴有效）"、`DHOMETIMEOUT`（本地脉冲轴） | **说明 H5U 同时支持脉冲轴** → 这就是"控步进/脉冲型伺服"的路子 |

> **结论（可背下来）**：
> - H5U 的运动控制 = **轴对象 + PLCopen 指令**，**总线轴**（EtherCAT/CiA402）和**本地脉冲轴**（脉冲+方向）共用同一套轴对象；
> - "控步进"和"控伺服"在 PLC 侧编程**几乎一样**，差别只在轴配置（脉冲轴设脉冲数/方向，总线轴设 PDO/对象字典）；
> - 所以这台机没有运动控制板卡：**1 个伺服轴 + 5 个总线电缸**都挂在 EtherCAT 上，由 PLC 直接当主站。

本工程实际用到的运动控制指令（从 `il_log.log` 全量指令统计得到，全部出现在 `Axis_FB` 本体里）：

```
MC_POWER             使能
MC_HOME              原点回归
MC_JOG               点动
MC_MOVEABSOLUTE      绝对定位
MC_MOVERELATIVE      相对定位
MC_STOP              停止
MC_RESET             报警复位
MC_SETPOSITION       设置当前位置
MC_READACTUALPOSITION / MC_READAXISERROR / MC_READDIGITALINPUT   状态读取
```

**`Axis_FB` 就是把上面这些指令 + 状态处理 + HMI 交互封装成一个可实例化的功能块**，实例名叫 `下料Y轴`，驱动一个 CiA402 伺服（`_IQ1_*`）。
每个引脚的完整含义见 5.4 与附录。

---

## 5.1 结论速览
| 结论 | 证据 |
|---|---|
| EtherCAT 从站**共 6 个**: 5 台 SMC `JXCE1`(JXC 电缸控制器) + 1 台汇川 `InoSV630N`(CiA402 伺服) | `EtherCat.dat`: 5 段 `JXCE1 EtherCAT JXC Rev.1.1` + 1 段 `InoSV630N`;`IL 27-SBR_报警:6055` `BITDW 从站在线状态[0] 驱动通讯故障集合 K6` + `_ECATSlave[0..5]`(IL:6059-6087) |
| 伺服轴**只有 1 根**, 即 `下料Y轴`(下料机械手升降轴), 驱动器节点名 `下料Y轴伺服`(型号 SV630N, 节点 `SV630_1Axis_03715`) | `EtherCat.dat`(`InoSV630N#/SV630_1Axis_03715$/.../下料Y轴伺服*`);`IL 34-SBR_轴实例化:7572` |
| `Axis_FB` 在**全工程只有 1 个实例**(`下料Y轴`), 在 `SBR_轴实例化` 中调用 | `IL 34-SBR_轴实例化:7572` 全工程唯一 `CALL_FB Axis_FB` |
| 电缸共 **10 台**, 分两类: EtherCAT `ETC电缸` 实例 5 台(`_IQ3/_IQ5/_IQ7/_IQ9/_IQ11`), GL20 并行 IO 点位码式 5 台(`Y130-Y177`/`X130-X177`) | `IL 30-SBR_电缸控制:7322/7341/7360/7379/7398`(5 次 `CALL_FB ETC电缸`);`IL 30-SBR_电缸控制:6619` `WBIT 电缸控制字[0] Y130 K3` |
| FB 库里的 `FB_中断定长`(Touch Probe/中断定长)**未被任何程序实例化**, 探针功能在本工程**未使用** | `功能块实例.fbi.strings.txt` 无 `FB_中断定长`;全工程 grep `中断定长`/`MC_TOUCHPROBE` 无 CALL 记录 |
| `FB_位置比较比较` **不是**位置比较(touch probe)功能块, 而是「带允差的浮点比较器」, 用于暂停位判定 | `FB_位置比较比较.FB.strings.txt:20-27`(`DEADD IF_数据1 IF允许波动值→VAR_数据1上限`);被 `EXECUTE _STB101`(ST 步骤, `IL 27-SBR_报警:6049`)以循环下标调用(`IL 35-FB_BODIES:17840` `… FBI_001 HMI_轴当前位置[i] HMI_暂停位置[i] E0.3`);另有实例 `暂停开机位置比较/暂停开机位置比较1`(`功能块实例.fbi.strings.txt:16-21`) |

---

## 5.2 EtherCAT 与运动执行机构总览
### 5.2.1 EtherCAT 从站清单(以 `EtherCat.dat` 为准)

`EtherCat.dat` 中每个从站段的字段顺序为 `节点名#` → `EDS/XML 描述$` → `100003f%`(配置字) → `EtherCAT&` → `Rx PDO1 Mapping` … `Tx PDO1 Mapping`。

| 序号 | 节点名 | 描述(ESI) | 过程映像前缀 | 对应机构 |
|---|---|---|---|---|
| 1 | `JXCE1` | `JXCE1 EtherCAT JXC Rev.1.1` | `_IQ3_*` | FL左X电缸 |
| 2 | `JXCE1_1` | `JXCE1 EtherCAT JXC Rev.1.1` | `_IQ5_*` | FL左Y电缸 |
| 3 | `JXCE1_2` | `JXCE1 EtherCAT JXC Rev.1.1` | `_IQ7_*` | FL左Z电缸 |
| 4 | `JXCE1_3` | `JXCE1 EtherCAT JXC Rev.1.1` | `_IQ9_*` | FL右Y电缸 |
| 5 | `JXCE1_4` | `JXCE1 EtherCAT JXC Rev.1.1` | `_IQ11_*` | FL右Z电缸 |
| 6 | `InoSV630N` | `SV630_1Axis_03715`(DC-Synchron) | `_IQ1_*` | 下料Y轴伺服 |

> 说明: `EtherCat.dat` 里 5 台 JXC 的书写顺序是 `JXCE1_4 → JXCE1_3 → JXCE1_2 → JXCE1_1 → JXCE1 → InoSV630N`(倒序), 与从站号无关;上表按过程映像顺序(`_IQ3 < _IQ5 < _IQ7 < _IQ9 < _IQ11 < _IQ1`? 不成立)重排为「从站号 K1..K5」的顺序,依据是 FB 实例传入的 `etc从站号`: `IL 30-SBR_电缸控制:7322/7341/7360/7379/7398` 分别为 `K1/K2/K3/K4/K5`, 且 `_IQ3/_IQ5/_IQ7/_IQ9/_IQ11` 与之逐一对应。
> GL20 远程 IO **不在 EtherCAT 上**: 它们是 H5U 右侧本地扩展总线模块(`GL20ModuleCfg.data.strings.txt`: 5×`GL20(GL20S)-3200END` 覆盖 X0-X247, 5×`GL20(GL20S)-0032ETN` 覆盖 Y0-Y247, 末端 `GE20-232/485-RTC`)。

### 5.2.2 三类运动执行机构

| 类别 | 数量 | 控制方式 | 定位数据 | 程序载体 |
|---|---|---|---|---|
| ① CiA402 总线伺服轴 | 1 | H5U 内置 PLCopen 运动指令(`MC_Power/MC_MoveAbsolute/…`), 周期 PDO(0x6040/0x6041/0x607A/0x6064) | 浮点**用户单位**(REAL), 位置数组 25 点 | `Axis_FB`(1 实例) |
| ② EtherCAT JXC 电缸 | 5 | 自写 FB `ETC电缸`, 直接读写 JXC 的 Rx/Tx PDO 字(启动标志/目标位置/推压力…), 走 SDO `0x2260` 改点动速度 | 32 位整数位置(`Target position`/`Current position`), 位置数组 15 点 | `ETC电缸`(5 实例) |
| ③ GL20 并行 IO 点位码电缸 | 5 | 梯形图位握手: `电缸控制字[n]` 经 `WBIT` 送 3 位「点位码」至 `Y…_IN0/1/2`;`BITW` 读回 `X…_OUT0/1/2` | **无位置数值**, 只有点位号 1..7 | `SBR_电缸控制` 直接编写(无 FB) |

---

## 5.3 轴/电缸清单表
### 5.3.1 表 A — CiA402 总线伺服轴(1 台)

| 序号 | 名称 | 轴号/索引 | 机械用途 | 物理驱动器 / 从站 | 关键符号前缀与地址 |
|---|---|---|---|---|---|
| 1 | `下料Y轴`(实例名) / `下料Y轴伺服`(轴对象名) | 枚举 `axis_枚举` 中 `下料Y轴0`(索引 0);HMI 数组下标一律写 `[下料Y轴0]` | 下料机械手**升降轴**(与 `下料机械手升降气缸.原位OK` 做防撞互锁;轴本身在下料工位,负责把产品在下料位与下料皮带之间升降) | EtherCAT CiA402 伺服 `InoSV630N`, 节点 `SV630_1Axis_03715`, DC-Synchron | 过程数据 `_IQ1_0.._IQ1_12`(地址 `0X2101420`…`0X2104390`);HMI 变量 `HMI_轴1定位`/`HMI_轴1定位位置`/`HMI_轴1读取位置`/`HMI_轴手动速度`/`HMI_轴自动高速`/`HMI_轴加速度`/`HMI_轴减速度`/`HMI_回原偏移`/`HMI寸动位置`/`HMI_轴当前位置`/`HMI_轴报警`/`HMI_轴运行中`/`HMI_轴回原OK`/`HMI_轴原点`/`HMI_正限位`/`HMI_反限位`/`HMI_断使能`/`HMI_轴没使能` |

`axis_枚举.enum.strings.txt` 里 `下料Y轴0` 后还有 `前Y1轴1 … 料仓BZ轴12`(FANUC 机器人轴)和 `伺服轴13 … 伺服轴31`(保留),但**这些都不是 H5U 的运动轴**,只是给 HMI 轴参数数组(长度 25/32)预留的枚举索引。

HMI 位置点(`hmi轴参数.gvt.strings.txt`,`HMI_轴1定位位置` 元素名): `暂停位[0]`, `0点位[1]`, `待机位[2]`, `取料位[3]`, `下料OK位[4]`, `下料NG位[5]`(与 `功能块实例.fbi.strings.txt` 中实例初始化 `下料Y轴I(HMI_定位OK:=[2(),待机位,取料位,下料OK位,下料NG位])` 一致:有效点位为 2..5)。**注意索引从 0 起**,所以「待机位」= `轴绝对定位位置[2]`,不是 [0]。

### 5.3.2 表 B — EtherCAT JXC 电缸(5 台, `ETC电缸` FB 实例)

调用点: `IL 30-SBR_电缸控制:7322 / 7341 / 7360 / 7379 / 7398`(FB 本体展开见 `IL 35-FB_BODIES:14061-14358` 等 5 段)。

| 序号 | 电缸名 | HMI 索引(`HMI_电缸N…`) | 从站号(`etc从站号`) | 过程映像 | 定位/在当前位数组 | 机械用途(由点位名推断, 标「推断」) |
|---|---|---|---|---|---|---|
| 6 | `FL左X电缸` | `[5]` | `K1` | `_IQ3_*` | `HMI_电缸6定位位置`/`HMI_电缸6定位`/`g_x自动电缸6定位`/`HMI_电缸6在当前位`(480bit=15×DINT) | FL 左工位 **X(推入)方向**;点位 `待机位/夹FL位/FL下压位/推入FL位/…/视觉纠偏位` |
| 7 | `FL左Y电缸` | `[6]` | `K2` | `_IQ5_*` | `HMI_电缸7…` | FL 左工位 **Y(下压/抚平)方向**;点位 `待机位/夹FL位/下压FL位/FL推入位` |
| 8 | `FL左Z电缸` | `[7]` | `K3` | `_IQ7_*` | `HMI_电缸8…` | FL 左工位 **Z(升降/夹紧)方向**;点位 `待机位/夹FL位/FL下压位/FL推入位/初始化安全位` |
| 9 | `FL右Y电缸` | `[8]` | `K4` | `_IQ9_*` | `HMI_电缸9…` | FL 右工位 **Y 方向**;点位最多(抚平位1-3/下压FL位/预插入位/插入位/关盖始位/终位/抵住位) |
| 10 | `FL右Z电缸` | `[9]` | `K5` | `_IQ11_*` | `HMI_电缸10…` | FL 右工位 **Z 方向**;点位 `待机位/抚平位1-3/FL下压位/FL推入上位/预插入位/关盖位/关盖下压位/初始化安全位/…` |

实例声明的初始化参数(`功能块实例.fbi.strings.txt`): `FL左X电缸 (加减速度:=5000, 速度:=10)`;另有遗留未调用实例 `FL左X电缸_1 … FL左X电缸_4`(实例表里有,IL 里无调用)。

### 5.3.3 表 C — GL20 并行 IO 点位码电缸(5 台, 无 FB)

控制字/状态字协议(位定义见 §4.2):

| 序号 | 电缸名 | HMI 索引 | 点位码输出(Y) | 反馈输入(X) | 电缸控制字/状态字下标 | 点位(1 位=1 点) |
|---|---|---|---|---|---|---|
| 1 | `撕膜电缸` | `[0]` | `Y130 IN0 / Y131 IN1 / Y132 IN2`, `Y133 原点复位`, `Y134 暂停`, `Y135 运行启动`, `Y136 报警复位`, `Y137 伺服使能ON` | `X130 OUT0 / X131 OUT1 / X132 OUT2`, `X133 动作中`, `X134 步信息区域内`, `X135 原点复位中`, `X136 到达目标位置`, `X137 伺服使能中` | `[0]` | 待机位 K1 / 夹膜位 K2 / 撕膜位 K3 / 废料位 K4 |
| 2 | `机器人1位抚平FPC电缸` | `[1]` | `Y140-Y147`(同上 8 位) | `X140-X147` | `[1]` | 待机位/预定位1/预定位2/预定位3(K1..K4) |
| 3 | `机器人1位抓手升降电缸` | `[2]` | `Y150-Y157` | `X150-X157` | `[2]` | 待机位/关盖位/压盖位(K1..K3) |
| 4 | `机器人1位抓手平移电缸` | `[3]` | `Y160-Y167` | `X160-X167` | `[3]` | 待机位/关盖始位/关盖位(K1..K3) |
| 5 | `机器人2位抚平FPC电缸` | `[4]` | `Y170-Y177` | `X170-X177` | `[4]` | 待机位/预定位1/预定位2/预定位3(K1..K4) |

符号地址: `X130..X177 = 0X58..0X7F`(位), `电缸控制字 = 0X2101520`(160bit=5×DINT), `电缸状态字 = 0X21015C0`(160bit), `电缸启动 = 0X2101670`(10bit), `电缸启动延时 = 0X2101660`(10bit), `电缸统一手动条件 = 0X2100075`(`VarNameAndAddr.csv.txt`)。

> 命名遗留(来自 `电缸控制.gvt.strings.txt` 的注释项): `机器人1位抓手升降电缸(已删除）`、`机器人1位抓手平移电缸(已删除）` —— 说明这两个 Y 位曾改版;`HMI_电缸控制字`/`状态字` 仍保留 5 个元素。

### 5.3.4 轴实例化: `SBR_轴实例化`

整个程序只有 19 行 IL(`IL 34-SBR_轴实例化:7561-7580`):

```
7555 LD M8000              ; 安全条件 = 升降气缸在位
7556 AND 下料机械手升降气缸.原位OK
7557 OUT g_x下料Y轴安全条件
7559 LD M8000
7587 MPS
7560  LDI h_x维修中
7561  AND 下料机械手升降气缸.原位OK
7562  OR 设备状态机.QB_自动中
7563  OR 设备状态机.QB_初始化中
7564  OR 设备状态机.QB_自动暂停中
7589 ANB → 7566 INV → 7567 OUT 下料Y轴.急停
7593 MPP
7569 AND 下料Y轴.急停 → 7570 OUT err_下料Y轴防撞不能运行
7571 LD M8000
7572 CALL_FB Axis_FB 下料Y轴 下料Y轴伺服 - MIAN_停机 …(共 43 个实参)
7594 SRET
```

要点:

1. **只实例化 1 根轴**;`下料Y轴` 是实例名,`下料Y轴伺服` 是 EtherCAT 轴对象名(即 `EtherCat.dat` 里的节点名),二者通过 `Axis` 引脚绑定。
2. 轴号与 HMI 数组的对应:实参里所有下标都写枚举 `下料Y轴0`(值 0) → `HMI_轴手动速度[下料Y轴0]`、`HMI_轴加速度[下料Y轴0]`、`HMI_轴自动高速[下料Y轴0]`、`HMI_正限位[下料Y轴0]`、`err_x负限位报警[下料Y轴0]` …;而 `HMI_轴1定位`/`HMI_轴1定位位置`/`HMI_轴1读取位置`/`HMI_轴当前位置` 是**专用标量名**(不带下标),因为该轴是工程里唯一轴(命名习惯从"轴1"直接映射到 `下料Y轴0`)。
3. `电缸控制字[n]`/`电缸状态字[n]` 与 `ETC电缸` 无关:前者只属于表 C 的 5 台 IO 电缸(下标 0..4),后者用 PDO 字(`etc控制字/etc状态字`),二者是不同的「控制字/状态字」概念,不要混用。
4. `下料Y轴.急停` 只用于产生报警 `err_下料Y轴防撞不能运行`(IL:7569-7570);它**没有**接到 `Axis_FB` 的 `急停` 引脚(该引脚实参为 `-`)→ 该互锁当前只报警、不直接停轴(轴由 `MIAN_停机` 经 `停止` 引脚停)。

### 5.3.5 编号对照速查

| `HMI_电缸N定位*` 下标 | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
|---|---|---|---|---|---|---|---|---|---|---|
| 电缸 | 撕膜 | 机器人1位抚平FPC | 机器人1位抓手升降 | 机器人1位抓手平移 | 机器人2位抚平FPC | FL左X | FL左Y | FL左Z | FL右Y | FL右Z |
| 类别 | C | C | C | C | C | B | B | B | B | B |
| `电缸控制字/状态字[n]` | ● | ● | ● | ● | ● | – | – | – | – | – |
| `ETC电缸` 从站号 | – | – | – | – | – | K1 | K2 | K3 | K4 | K5 |

(`电缸控制.gvt.strings.txt` 的 `HMI_电缸速度` 元素名 `[5(), 左X电缸, 左Y电缸, 左Z电缸, 右Y电缸, 右Z电缸]` 印证 0..4 为另一类。)

---

## 5.4 `Axis_FB` 引脚与内部指令
`Axis_FB.FB.strings.txt` 文件头注释即 `_sMCAXIS_INFO` 轴结构体成员(「引脚注释齐全」指这一块),`Axis_FB` 自身对外是 43 个引脚。

### 5.4.1 43 个接口引脚(完整, 顺序即 `CALL_FB` 实参顺序)

| # | 引脚名 | 方向 | 类型/位宽 | 注释/语义 | 本工程实际接线(`IL 34:7572`) |
|---|---|---|---|---|---|
| 1 | `Axis` | 输入 | `_sMCAXIS_INFO`(轴结构体, 32bit 引用) | 轴对象(PLCopen 轴) | `下料Y轴伺服` |
| 2 | `急停` | 输入 | BOOL | 急停 | `-`(**未接**;FB 内 `ANDI 急停`/`ORP 急停` 恒不动作) |
| 3 | `停止` | 输入 | BOOL | 停止 | `MIAN_停机` |
| 4 | `半自动允许` | 输入 | BOOL | 半自动允许 | `设备状态机.QB_半自动中` |
| 5 | `设备状态` | 输入 | INT(16) | 设备状态(0 停止/10 手动/20 维修/30 回原/40 自动/50 半自动) | `设备状态机.QF_设备状态` |
| 6 | `故障复位` | 输入 | BOOL | 故障复位 | `MIAN_故障清除` |
| 7 | `HMI_轴使能` | 输入 | BOOL | HMI 使能(**低有效**:`LDI HMI_轴使能 → MC_POWER`) | `HMI_断使能[下料Y轴0]` |
| 8 | `HMI_找原` | 输入 | BOOL | 回原点请求 | `HMI_轴回原[下料Y轴0]` |
| 9 | `HMI_手动定位触发` | 输入 | BOOL[25] | 手动选点触发 | `HMI_轴1定位` |
| 10 | `HMI_JOG正转` | 输入 | BOOL | 手动 JOG+ | `HMI_正向点动[下料Y轴0]` |
| 11 | `HMI_JOG反转` | 输入 | BOOL | 手动 JOG− | `HMI_反向点动[下料Y轴0]` |
| 12 | `hmi_寸动距离` | 输入 | REAL | 寸动距离(带符号) | `HMI寸动位置[下料Y轴0]` |
| 13 | `hmi_正寸动` | 输入 | BOOL | 正寸动(上升沿) | `HMI_正寸动[下料Y轴0]` |
| 14 | `hmi_负寸动` | 输入 | BOOL | 负寸动(上升沿) | `HMI_负寸动[下料Y轴0]` |
| 15 | `HMI_位置保存` | 输入 | BOOL[25] | 示教保存当前位置 | `HMI_轴1读取位置` |
| 16 | `HMI_手动速度` | 输入 | REAL | 手动速度 | `HMI_轴手动速度[下料Y轴0]` |
| 17 | `HMI_加速度` | 输入 | REAL | 加速度 | `HMI_轴加速度[下料Y轴0]` |
| 18 | `HMI_减速度` | 输入 | REAL | 减速度 | `HMI_轴减速度[下料Y轴0]` |
| 19 | `HMI_定位速度` | 输入 | REAL | 自动定位速度 | `HMI_轴自动高速[下料Y轴0]` |
| 20 | `HMI_回原定位速度` | 输入 | REAL | 回原定位速度 | 常数 `E50`(=50.0,硬编码) |
| 21 | `自动定位ID` | 输入 | INT(16) | 自动选点号 | `-`(程序用 `下料Y轴.自动定位ID` 直接写: `IL 07-SBR_03自动NG下料模组:2657` `MOV K3 下料Y轴.自动定位ID`) |
| 22 | `定位方向` | 输入 | INT(16) | `MC_MoveAbsolute` 的 Direction | `-` |
| 23 | `JOG条件` | 输入 | BOOL | JOG 附加允许条件(`ANDI JOG条件`) | `-` |
| 24 | `初始化找原` | 输入 | BOOL | 初始化强制找原 | `-`(程序直接写成员: `IL 22-SBR_13下料工位初始化:4890` `SET 下料Y轴.初始化找原`) |
| 25 | `自动互锁` | 输入 | BOOL | 自动定位附加允许(`ANDI 自动互锁`) | `-` |
| 26 | `回原偏移` | 输入 | REAL | 回零后 `MC_SetPosition` 的偏置位置 | `HMI回原偏移[下料Y轴0]` |
| 27 | `自动JOG正` | 输入 | BOOL | 自动正向 JOG | `-` |
| 28 | `自动JOG负` | 输入 | BOOL | 自动反向 JOG | `-` |
| 29 | `自动JOG速度` | 输入 | REAL | 自动 JOG 速度 | `-` |
| 30 | `轴绝对定位位置` | 输入 | REAL[25] | 定位位置表(示教点) | `HMI_轴1定位位置` |
| 31 | `HMI_定位OK` | 输出 | BOOL[30] | 各点到位标志 | `-`(引脚未接;实际由流程程序读成员 `下料Y轴.HMI_定位OK[2]`,见 `IL 22-SBR_13下料工位初始化:4912`) |
| 32 | `HMI_正限位触发` | 输出 | BOOL | 硬件正限位 | `HMI_正限位[下料Y轴0]` |
| 33 | `HMI_负限位触发` | 输出 | BOOL | 硬件负限位 | `HMI_反限位[下料Y轴0]` |
| 34 | `HMI_原点触发` | 输出 | BOOL | 原点开关 | `HMI_轴原点[下料Y轴0]` |
| 35 | `轴报警` | 输出 | BOOL | 轴/驱动器报警 | `HMI_轴报警[下料Y轴0]` |
| 36 | `轴使能OK` | 输出 | BOOL | 轴使能成功 | `-` |
| 37 | `轴BUSY` | 输出 | BOOL | 运动忙(`Jog_Busy∨Home_Busy∨Abs_Busy∨Rel_Busy∨buffer_Busy`) | `HMI_轴运行中[下料Y轴0]` |
| 38 | `轴找原OK` | 输出 | BOOL | 回零完成 | `HMI_轴回原OK[下料Y轴0]` |
| 39 | `负限位报警` | 输出 | BOOL | 负限位报警(锁存) | `err_x负限位报警[下料Y轴0]` |
| 40 | `正限位报警` | 输出 | BOOL | 正限位报警(锁存) | `err_x正限位报警[下料Y轴0]` |
| 41 | `相对定位OK` | 输出 | BOOL | 相对定位结束/异常 | `-` |
| 42 | `轴当前位置` | 输出 | REAL | 当前位置(`Axis.fActPosition`) | `HMI_轴当前位置[下料Y轴0]` |
| 43 | `轴没使能` | 输出 | BOOL | 轴未使能 | `HMI_轴没使能[下料Y轴0]` |

**FB 内部(非接口)却参与逻辑的成员**(`VarNameAndAddr.csv.txt` 中 `下料Y轴.*`, 均**从未被外部赋值**):

| 成员 | 类型/位宽 | 用法(IL 证据) | 后果 |
|---|---|---|---|
| `HMI_定位互锁` | BOOL[30] | `IL 35-FB_BODIES:17415-17487` 手动定位链里逐点 `ANDI HMI_定位互锁[n]` | 恒 0 → 手动选点互锁**未启用** |
| `ix_软限位使能` | BOOL(1) | `IL 35-FB_BODIES:17536` `AND ix_软限位使能` | 恒 0 → 软限位判定网络不执行 |
| `HMI_正软限位`/`HMI_负软限位` | REAL | `IL 35-FB_BODIES:17538/17541` | 恒 0.0 → **软限位功能未启用**(HMI 上的 `HMI_轴正软限位[..]`/`HMI_轴负软限位[..]` 全工程无引用) |
| `HMI_手动相对触发` | BOOL[25] | `IL 35-FB_BODIES:17499-17501`(启动相对定位)、`17658`、`17676 RST` | 无 SET → 该启动路径不生效;寸动靠 `hmi_正/负寸动` 上升沿 |
| `多段目标位置`/`多段目标速度` | REAL[16]×2 | 无引用 | 多段位置(buffer)功能未用 |

### 5.4.2 `Axis` 引脚的结构成员(`_sMCAXIS_INFO`)—— 完整清单

以下按 `Axis_FB.FB.strings.txt:8-266` 原文顺序重排分组;「PDO」注释表示该成员对应 CiA402 对象。

**使能 / 停止 / 复位**

| 成员 | 类型 | 注释原文 |
|---|---|---|
| `bPowerOn` | BOOL | 可写，调试参数 |
| `bPowerState` | BOOL | 轴使能状态 只读，监控用 |
| `bStop` | BOOL | 可写，调试参数 |
| `bReset` | BOOL | 可写，调试参数 |
| `bEnterDebug` | BOOL | 进入监控模式 可写，调试参数 |
| `bDebugState` | BOOL | 轴调试状态（只读，监控用） |
| `wDebugMotionType` | INT | 调试运动类型 可写，调试参数 |
| `dUnused` | DINT | 保留 |

**原点回归**

| 成员 | 类型 | 注释原文 |
|---|---|---|
| `bHome` | BOOL | 原点回归 可写，调试参数 |
| `bHomeState` | BOOL | 原点开关状态（只读，监控用） |
| `fPositionOffser`(原文拼写) | REAL | 原点回归偏移 可写，调试参数 |
| `fPresetPosition` | REAL | 预设位置 可写，调试参数 |
| `iHomeMethod` | INT | 原点回归方式（本地脉冲轴） |
| `iHomePositionMode` | INT | 原点回归位置模式选择 （本地脉冲轴） |
| `fHomeVelocity` | REAL | 原点回归返回速度（本地脉冲轴） |
| `fHomeApproachVelocity` | REAL | 原点返回接近速度（本地脉冲轴） |
| `fHomeAcceleration` | REAL | 原点返回加速度（本地脉冲轴） |
| `dHomeTimeOut` | DINT | 原点返回超时时间（本地脉冲轴） |
| `dHomeTerminalID` | DINT | 原点信号ID |
| `bHomeTerminaPolarity`(原文) | BOOL | 原点信号极性选择 |

**点动 / 连续 / 力矩**

| 成员 | 类型 | 注释原文 |
|---|---|---|
| `bJogP` / `bJogN` | BOOL | Jog+ / Jog- 可写，调试参数 |
| `fJogVelocity` | REAL | 点动速度 可写，调试参数 |
| `fMaxJogVelocity` | REAL | Jog最大速度 |
| `bVelocity` | BOOL | 连续运动 可写，调试参数 |
| `bTorque` | BOOL | 力矩模式 可写，调试参数 |
| `fTarTorque` | REAL | 目标力矩 可写，调试参数 |
| `fTarTorqueSlop` | REAL | 力矩斜坡 可写，调试参数 |
| `fMaxPTorque` / `fMaxNTorque` | REAL | 正/负扭矩最大值（总线伺服轴，仅用于指令检查，不写入伺服） |
| `dTarTorqueSlope` | DINT | 目标转矩斜坡（只读，PDO数据） |

**绝对 / 相对 / 段位置**

| 成员 | 类型 | 注释原文 |
|---|---|---|
| `bAbsPos` | BOOL | 绝对定位 可写，调试参数 |
| `bRelPos` | BOOL | 相对定位 可写，调试参数 |
| `bRevPos` | BOOL | 往复运动 可写，调试参数 |
| `bSetPos` | BOOL | 设置当前位置 可写，调试参数 |
| `fTarPosition1` / `fTarPosition2` | REAL | 目标位置1 / 目标位置2 可写，调试参数 |
| `fTarVelocity1` / `fTarVelocity2` | REAL | 目标速度1 / 目标速度2 可写，调试参数 |
| `fTarAcceleration1` / `fTarAcceleration2` | REAL | 目标加速度1 / 目标加速度2 可写，调试参数 |
| `fTarDecelaration1` / `fTarDecelaration2`(原文拼写) | REAL | 目标减速度1 / 目标减速度2 可写，调试参数 |
| `wCurveType1` / `wCurveType2` | INT | 曲线类型1 / 曲线类型2 可写，调试参数 |
| `fLimitVelocity` | REAL | 限制速度 可写，调试参数 |
| `bSingleSyncMode` | BOOL | 单轴同步控制模式(可写，调试参数) |

**限位 / 保护**

| 成员 | 类型 | 注释原文 |
|---|---|---|
| `bphlimit` / `bnhlimit` | BOOL | 硬件正/负限位状态（只读，监控用） |
| `bpslimit` / `bnslimit` | BOOL | 软件正/负限位状态（只读，监控用） |
| `bSoftLimitEnable` | BOOL | 软件限位使能控制 |
| `fPLimit` / `fNLimit` | REAL | 线性模式下的正向/负向限制值 |
| `fLimitDeceleraion`(原文) | REAL | 限位减速度 |
| `fErrorStopDeceleration` | REAL | 轴故障减速度 |
| `bEnterErrorStop` | BOOL | 轴故障不进入ErrorStop状态 |
| `fFollowErrorWindow` | REAL | 跟随误差阈值 |
| `fFollowPos` | REAL | 跟随误差（只读，监控用） |
| `fInVelocityWindow` | REAL | 速度到达阈值 |
| `dPLimitTerminalID` / `dNLimitTerminalID` | DINT | 正向/负向限位信号ID |
| `bPLimitTerminalPolarity` / `bNLimitTerminalPolarity` | BOOL | 正向/负向限位极性选择 |

**状态 / 故障**

| 成员 | 类型 | 注释原文 |
|---|---|---|
| `wPLCOpenState` | WORD | PLCOpen状态机 只读，监控用 |
| `wConfigState` | WORD | 配置状态 只读，监控用 |
| `wAxisError` | WORD | 轴故障 只读，监控用 |
| `wServoError` | WORD | 驱动器故障 只读，监控用 |
| `bMotionState` | BOOL | 运动状态（只读，监控用） |
| `bTardir` | BOOL | 轴目标运动方向（只读，监控用） |
| `fActPosition` / `fActVelocity` / `fActTorque` / `fAct_Acc_Dec` | REAL | 当前位置/当前速度/当前力矩/当前加速度_减速度 只读，监控用 |
| `fSetPosition` / `fSetVelocity` / `fSetTorque` / `fSet_Acc_Dec` | REAL | 设置位置/设置速度/设置力矩/设置加速度_减速度 只读，监控用 |
| `wAxisID` / `wAxisRingPos` | INT | 轴ID / 轴组态位置(上电初始化，写入不生效) |
| `fUnits` | REAL | 轴齿轮比(上电初始化，写入不生效) |
| `fFilter` | REAL | 设置主轴的滤波系数(上电初始化为1.0, 0.0, 0.0，可写入) |
| `dLocialAxisSetPos` | DINT | 本地脉冲轴设置位置（只读，监控用） |

**CiA402 PDO 只读映射(注释里直接给出对象号)**

| 成员 | 类型 | 注释原文 |
|---|---|---|
| `wControlWord` | WORD | 控制字 只读，PDO数据，0x6040 |
| `wStatusword` | WORD | 状态字 只读，PDO数据，0x6041 |
| `wModesOfOperation` | WORD | 控制模式 只读，PDO数据，0x6060 |
| `wModesOfOperationDisplay` | WORD | 当前控制模式 只读，PDO数据，0x6061 |
| `dSetPosition` | DINT | 目标位置 只读，PDO数据，0x607A |
| `dActPosition` | DINT | 当前位置 只读，PDO数据，0x6064 |
| `dSetVelocity` | DINT | 设置速度 只读，PDO数据，0x60ff |
| `dActVelocity` | DINT | 当前速度 只读，PDO数据，0x606c |
| `dSetTorque` | DINT | 设置力矩 只读，PDO数据，0x6071 |
| `dActTorque` | DINT | 当前力矩 只读，PDO数据，0x6077 |
| `dMaxVelocity` | DINT | 最大速度 只读，PDO数据，0x607f |
| `dProfielVelocity` / `dProfielAcceleration` / `dProfielDeceleration` | DINT | 轮廓速度 0x6081 / 轮廓加速度 0x6083 / 轮廓减速度 0x6084 |
| `wErrorCode` | WORD | 驱动器故障码 只读，PDO数据，0x603f |
| `dDI` | DINT | 数字量输入 只读，PDO数据，0x60fd |
| `dDO` | DINT | 数字量输出 只读，PDO数据，0x60fe:1 |
| `wTouchFunction` | INT | 探针功能设置 只读，PDO数据，0x60b8 |
| `wTouchStatus` | INT | 探针状态 只读，PDO数据，0x60b9 |
| `dTouch1PPos` / `dTouch2PPos` | DINT | 探针1/2上升沿位置 只读，PDO数据，0x60ba / 0x60bc |
| `dTouch1NPos` / `dTouch2NPos` | DINT | 探针1/2下降沿位置 只读，PDO数据，0x60bb / 0x60bd |

**组态(`sConfig`)**

| 子成员 | 类型 | 注释原文 |
|---|---|---|
| `dPlusePreCycle` | DINT | 电机/编码器旋转一圈的脉冲数 |
| `fDistancePreCycle` | REAL | 工作台旋转一圈的移动量 |
| `dNumerator` / `dDenominator` | DINT | 齿轮比分子 / 齿轮比分母 |
| `bDirection` | BOOL | 方向 |
| `bVirtualMode` | BOOL | 虚轴模式 |
| `iEncoderMode` | INT | 编码器模式（总线伺服轴有效） |
| `iLineRotateMode` | INT | 线性/旋转模式选择 |
| `fRotation` | REAL | 旋转模式下的旋转周期 |
| `fMaxVelocity` / `fMaxAcc` | REAL | 最大速度 / 最大加速度 |
| `dTouchProbeID1` / `dTouchProbeID2` | DINT | 探针端子1 ID号 / 探针端子2 ID号 |
| `iPluseMethod` | INT | 脉冲输出方式（本地脉冲轴有效） |

> `Axis_FB` 本体实际只用了 3 个结构体成员: `Axis.wPLCOpenState`(状态机判断, IL:17415/17488/17514/17603/17817…)、`Axis.fActPosition`(`'DEMOV Axis.fActPosition 轴当前位置`, IL:17838)、`Axis.fSetPosition`(定位窗口 `DEADD/DESUB … E0.05`, IL:17698-17699)。

### 5.4.3 FB 内部封装了哪些运动指令(H5U PLCopen 指令, 实际助记符)

| 内部指令(IL 助记符) | 地址 | 实参(照抄 IL) | 作用 |
|---|---|---|---|
| `MC_POWER` | IL:17512 | `Axis 使能done` | 使能轴: 条件 `LDI HMI_轴使能`(低有效) |
| `MC_RESET` | IL:17508 | `Axis` | 由 `故障复位` 触发 |
| `MC_READAXISERROR` | IL:17523 | `Axis - - ErrID[0] ErrID[1]` | 驱动器故障码/轴故障码;`ErrID[0]≠0 且 ≠H5444/H5443` → `SET 轴报警`(IL:17524-17530) |
| `MC_READACTUALPOSITION` | IL:17533 | `Axis` | 刷新 `Axis.fActPosition` |
| `MC_READDIGITALINPUT` | IL:17534 | `Axis - - DIstatus` | `DIstatus.0/.1/.2` → 负/正限位、原点(IL:17806-17813) |
| `MC_JOG` | IL:17593 | `Axis JOG正 JOG负 轴JOG速度 VAR_加速度 VAR_减速度 - Jog_Busy` | 手动/自动点动(方向由 `轴模式` 选源) |
| `MC_HOME` | IL:17608 | `Axis E0` | 原点回归(方式 `E0`), 条件 `ANDP 找原中` |
| `MC_MOVEABSOLUTE` | IL:17611 | `Axis 回原偏移 E30 E500 E500 - - 回原偏移完成` | **回零后的偏置定位**(50 → 偏移位置) |
| `MC_SETPOSITION` | IL:17614 | `Axis E0 - 回原修改位置OK` | 回零流程最后把当前位置设为 0 |
| `MC_MOVEABSOLUTE` | IL:17643 | `Axis VAR_轴绝对定位位置 VAR_目标速度 VAR_加速度 VAR_减速度 - 定位方向` | 正式绝对定位 |
| `MC_MOVERELATIVE` | IL:17669 | `Axis VAR_相对定位 VAR_目标速度 VAR_加速度 VAR_减速度` | 相对定位/寸动 |
| `MC_STOP` | IL:17691 | `Axis E15000 K0` | 急停/停止: 减速度硬编码 15000 |

**没有** `MC_TouchProbe`/`MC_SetOverride`/`MC_GearIn` 等指令 —— 工程里唯一的 `MC_TOUCHPROBE` 出现在未使用的 `FB_中断定长` 内(`IL 35-FB_BODIES`, 见 §6)。

回零流程(IL:17599-17640):

```
LDP HMI_找原 ORP 初始化找原 ANDI 停止 ANDI 急停 AND= Axis.wPLCOpenState K3 → OUT 找原中
MPS:
  ANDP 找原中            → MC_HOME Axis E0
MRD AND HomeOK           → MC_MOVEABSOLUTE Axis 回原偏移 E30 E500 E500   ; 走到偏移位置
MRD AND 回原偏移完成      → MC_SETPOSITION Axis E0                      ; 该点置 0
MPP ANDP 回原修改位置OK   → SET 轴找原OK                                 ; 回零完成
```

### 5.4.4 `轴模式` / 目标速度 / 加减速的选择策略(IL:17104-17160)

```
轴模式 := (设备状态 = 40) OR (设备状态 = 50)          ; 1=自动/半自动, 0=手动(IL:17105-17108)
手动(VAR_手动JOG速度) := HMI_手动速度, 若 ≤0 则 E10.0
自动(VAR_自动JOG速度) := 自动JOG速度, 若 HMI_手动速度 ≤0 则 E10.0     ; 自动JOG速度未接 → 取默认
VAR_目标速度 := 设备状态 0/10 → HMI_手动速度
              设备状态 40    → HMI_定位速度
              设备状态 30    → HMI_回原定位速度
              若 HMI_定位速度 ≤0 → E10.0
VAR_加速度 := HMI_加速度, ≤0 则 E1000.0
VAR_减速度 := HMI_减速度, ≤0 则 E1000.0
```

手动选点(IL:17217-17491): 分支条件 = `(HMI_手动定位触发[n] AND NOT 轴模式 AND NOT HMI_定位互锁[n])…` **或** `(自动定位ID = n AND 轴模式)`;整条链最后与 `ANDI 轴模式 ANDI 急停 AND 轴找原OK ANDI 轴BUSY` 相与 → `SET 轴绝对定位中`(IL:17488-17491/17529)。自动侧由外部写 `下料Y轴.自动定位ID`(K2/K3/K5)。

---

## 5.5 定位机制闭环
### 5.5.1 机制 A — `ETC电缸`(EtherCAT JXC): 请求位 / 目标位置 / 到位 / 超时

**信号分工**

| 信号 | 类型 | 角色 |
|---|---|---|
| `HMI_电缸N定位[n]` | BOOL[15] | **手动**请求位(HMI 按钮),与 `HMI_手自动切换`=0(手动)配对 |
| `g_x自动电缸N定位[n]` | BOOL[15] | **自动**请求位(流程程序 SET),与 `HMI_手自动切换`=1(自动)配对 |
| `HMI_电缸N定位位置[n]` | DINT[15] | 目标位置(32 位,写入 JXC 的 `Target position`) |
| `HMI_电缸N在当前位[n]` | BOOL[15] | **到位判定结果**(FB 输出):`|定位位置[n] − etc当前位置| ≤ 2` 且稳定 |
| `HMI_电缸当前位置[N]` | DINT | 反馈位置(`etc当前位置`) |

**FB 内部实现(以 FL左X电缸为例, `IL 35-FB_BODIES:14061-14358`)**

```text
; ① 请求 → 目标位置(DMOV), 手动/自动二选一
LD 手自动模式=0 AND HMI_定位触发[n]        (LDI 手自动模式)
OR 手自动模式=1 AND g_x自动定位[n]          (LD 手自动模式)
→ DMOV HMI_定位位置[n] etc目标位置            ; 15 个分支, IL:14140-14258

; ② 速度/加减速/推压力(每扫描周期写 PDO)
MOV 速度 etc目标速度        ; 速度引脚 = HMI_电缸速度[N]
MOV 加减速度 etc加速度      ; MOV 加减速度 etc减速度
MOV K100 etc定位推力        ; 硬编码 100
DMOV K300 etc定位宽度       ; 硬编码 300
OUT etc数据标志.4 … .15    ; 数据标志 bit4..15 恒置 1(IL:14118-14129)
OUT etc动作方法.0          ; (=0)

; ③ 触发: 合码 → 未在运动且状态字.8=0 延时 K30 → 上升沿给启动标志
BITW HMI_定位触发 定位组合 K15        ; 15 位合成字(IL:14263)
BITW g_x自动定位 定位组合1 K15        ; IL:14264
(LD<> 定位组合 K0 OR<> 定位组合1 K0) AND NOT 电缸运动中 AND 使能完成 AND NOT etc状态字.8
→ TONR K30 定位触发延时 → ANDP → SET etc启动标志.0        ; IL:14267-14308

; ④ 请求自动清除(谁清除): 启动标志后 K50 → 清 15 位请求
LD etc启动标志.0 → TONR K50 定位触发延时1 → AND 定位触发延时1
→ ZRST HMI_定位触发[0] HMI_定位触发[14]
→ ZRST g_x自动定位[0] g_x自动定位[14]
→ RST etc启动标志.0                                    ; IL:14274-14279

; ⑤ 到位判定(怎么判定): ±2 单位窗口 + K50 稳定延时, 逐点输出
DADD etc当前位置 K2 当前位置上限                        ; IL:14281
DSUB etc当前位置 K2 当前位置下限                        ; IL:14282
(使能完成 AND NOT 状态字.8) → TONR K50 到位延时          ; IL:14283-14286
AND 到位延时 ANDD<= 当前位置下限 HMI_定位位置[n] ANDD>= 当前位置上限  → OUT HMI_当前位[n]
                                                        ; IL:14289-14347(15 分支)

; ⑥ 状态/报警
OUT 使能完成   ← etc状态字.9                            ; IL:14367-14368
OUT 电缸运动中 ← etc状态字.8                            ; IL:14353-14354
etc状态字.15 → SET 电缸报警中                           ; IL:14356-14357
报警复位 → RST 电缸报警中; SET etc控制字.11 → TONR K100 报警复位延时 → RST etc控制字.11  ; IL:14092-14098

; ⑦ 回零: 回原点触发 OR 自动回原点触发 → etc控制字.12 ; 状态字.10 且 |当前位置|≤1 → TONR K50 → SET 回原点完成
; ⑧ 点动: 正向点动 → etc控制字.14, 反向点动 → etc控制字.13(手动且互斥, IL:14100-14108)
; ⑨ 停机: 清 0..9 号请求 + RST 启动标志(IL:14071-14076)
; ⑩ 点动速度修改: LDP HMI_点动速度修改 → ETC_WriteParameter_CoE etc从站号 H2260 K1 K2 HMI_点动速度(IL:14109-14115)
```

**单次 ETC 电缸定位时序伪代码(综合 §4.1 与 `IL 14-SBR_07自动插FL:3610-3615`)**

```text
; —— 请求侧(流程程序, 自动) ——
if 自动流程[15] == K210:
      HMI_电缸速度[7] := HMI_电缸定位高速          ; 选速度
      if  not HMI_电缸8在当前位[1] and not g_x自动电缸8定位[1]:
             g_x自动电缸8定位[1] := TRUE             ; 请求到「夹FL位」
; —— FB 侧(每扫描周期) ——
每个扫描:
    若 (手自动模式 and g_x自动定位[n]) 或 (not 手自动模式 and HMI_定位触发[n]):
          etc目标位置 := HMI_定位位置[n]
          etc目标速度 := 速度; etc加速度 := etc减速度 := 加减速度; etc定位推力 := 100; etc定位宽度 := 300
    若 定位组合 != 0 且 not 电缸运动中 且 使能完成 且 状态字.8 == 0:
          TONR(K30) → 计时到 → etc启动标志.0 := TRUE      ; 下发启动
    若 etc启动标志.0:
          TONR(K50) → 计时到 → 清 all 定位触发/g_x自动定位; etc启动标志.0 := FALSE
    若 使能完成 且 状态字.8 == 0:                        ; 已停稳
          TONR(K50) → 计时到 → HMI_当前位[n] := (|HMI_定位位置[n] − etc当前位置| ≤ 2)
; —— 完成侧 ——
if HMI_电缸8在当前位[1] and not g_x自动电缸8定位[1]:   ; 到位且请求已被 FB 清掉
      自动流程[15] := K250                             ; 进入下一步
```

要点: **请求由使用者(流程程序/HMI)置位;目标位置由 FB 转发;请求由 FB 在发出启动后 K50 自动清除;到位由 FB 用 ±2 窗口判定;`在当前位[n]` 与 `定位[n]` 同时为「到位 & 请求已清」才认为是本次动作完成**。

**报警/超时**

| 项 | 定时器/条件 | 证据 |
|---|---|---|
| 启动前置延时 | `TONR K30 定位触发延时` | IL:14270 |
| 启动后清请求 | `TONR K50 定位触发延时1` | IL:14275 |
| 到位稳定延时 | `TONR K50 到位延时` | IL:14286 |
| 回零到位稳定 | `TONR K50 回原点完成延时`,条件 `etc状态字.10 且 -1 ≤ 当前位置 ≤ 1` | IL:14084-14089 |
| 报警复位脉宽 | `TONR K100 报警复位延时` | IL:14096 |
| 报警源 | `etc状态字.15 → SET 电缸报警中`(`IL 35-FB_BODIES:14356`),锁存;**清除**靠 `报警复位` 引脚(= `MIAN_故障清除`) | IL:14092 |
| **无到位超时报警** | 未发现「定位超时」计时器(对比气缸有 `HMI_气缸到位延时报警`);卡住只能靠 §8.3 的工艺节拍/人工判断 | 全工程 grep 无 `电缸…超时` 逻辑 |

### 5.5.2 机制 B — IO 点位码电缸(`SBR_电缸控制`): 控制字/状态字闭环

**信号分工(以 撕膜电缸 为例, `IL 30-SBR_电缸控制:6520-6700`)**

```text
; —— 手册/自动条件 ——
LD M8000 ANDI MIAN_停机 AND NOT 设备状态机.QB_自动中 → OUT 电缸统一手动条件   ; (IL:6520-6523)
; —— 伺服使能(低有效): ——
M8000 ANDI X137_伺服使能中 AND NOT HMI_电缸使能[0] → SET Y137_伺服使能ON
M8000 AND HMI_电缸使能[0]                          → RST Y137_伺服使能ON      ; (IL:6524-6531)
; —— 回零 ——
(电缸统一手动条件 AND HMI_电缸原点复位[0]) OR g_x自动电缸回零[0] → OUT Y133_原点复位
ANDP X135_原点复位中 → SET g_x电缸回零完成[0];  ANDI X135_原点复位中 → RST g_x电缸回零完成[0]
; —— 运行/暂停/报警复位 ——
(电缸统一手动条件 ANDP HMI_电缸运行启动[0]) OR 电缸启动[0] → OUT Y135_运行启动
HMI_电缸暂停[0] OR MIAN_停机                                → OUT Y134_暂停
HMI_电缸报警复位[0] OR MIAN_故障清除                         → OUT Y136_报警复位
; —— 定位请求 → 点位码(9 分支) ——
(电缸统一手动条件 ANDP HMI_电缸1定位[0]) ORP g_x自动电缸1定位[0] → MOV K1 电缸控制字[0]
… 逐点 K2..K9 对应 定位[1..8] …                                ; (IL:6565-6617)
WBIT 电缸控制字[0] Y130 K3        ; 控制字低 3 位 → Y130/Y131/Y132 = IN0/IN1/IN2(点位码)
BITW X130 电缸状态字[0] K3        ; X130/X131/X132 = OUT0/OUT1/OUT2 → 状态字低 3 位
; —— 启动延时 + 到达清除 ——
(AND> 电缸控制字[0] K0) AND NOT X133_动作中 → TONR K80 电缸启动延时[0] → ANDP → SET 电缸启动[0]
LDP X136_到达目标位置 ORF X133_动作中 ORP QB_初始化中 OR MIAN_停机
   → MOV K0 电缸控制字[0]; RST 电缸启动[0]                    ; (IL:6631-6637)
; —— 请求清除 + 回零请求清除 ——
X133_动作中 OR MIAN_停机 OR QB_初始化中
   → ZRST g_x自动电缸1定位[0..9]; ZRST HMI_电缸1定位[0..9]
   → RST HMI_电缸原点复位[0]; RST g_x自动电缸回零[0]           ; (IL:6639-6646)
; —— 在当前位置(逐点) ——
AND X137_伺服使能中 AND X135_原点复位中 → MPS
   AND= 电缸状态字[0] K1 → OUT HMI_电缸1在当前位[0]  … K9 → [8]     ; (IL:6648-6676)
```

要点与量纲:

* `电缸控制字[n]` = 「点位号 + 标志」,经 `WBIT … K3` 取**低 3 位**送 `Y…_IN0/1/2`;`电缸状态字[n]` 由 `BITW X… K3` 取 `X…_OUT0/1/2`。相同写法的判例: 机器人握手 `WBIT 机器人控制字[0] Y220 K5` / `BITW X220 机器人状态字[0] K5`,而 `X220..X224` 的名称正是 `机器人1当前组合任务号1/2/4/8/16`(`输入映射X.gvt.strings.txt`),**证明位序为 LSB→低位地址、K 为位数**。
* 因此有效点位码是 **1..7**(K1..K7);`定位[7]→K8`、`定位[8]→K9` 的第 4 位不会出现在只读 3 位的状态字里,这两个分支在本工程**恒不成立**(推断;撕膜电缸实际只用 4 点,不影响功能)。
* `K1..K9` 与「点位」一一对应: `HMI_电缸1定位[0]=待机位→K1`, `[1]=夹膜位→K2`, `[2]=撕膜位→K3`, `[3]=废料位→K4`;对 3 点位的抓手升降/平移电缸则只用 K1..K3。
* **谁请求**: 手动 = HMI 按钮 `HMI_电缸N定位[x]`(受 `电缸统一手动条件` 约束)= 非停机且非自动;自动 = 流程程序 `SET g_x自动电缸N定位[x]`(例:`IL 05-SBR_02自动撕膜机构:2113/2139/2154/2183/2221`)。
* **谁清除**: 请求位由本程序在「`X…_动作中`(运动结束)或停机或初始化」时 `ZRST`(IL:6639-6644);`电缸启动[n]`、`电缸控制字[n]` 由「到达目标位置/动作中下降沿/初始化/停机」清除(IL:6631-6637)。
* **到位判定**: 位置反馈 ≠ 到位;真正判据是 `电缸状态字[n] = Kx`(驱动器反馈当前点位号) + 输出 `HMI_电缸N在当前位[x]`;另可读 `X…_到达目标位置`(IL:6631)。
* **超时**: 只有 `TONR K80 电缸启动延时[n]`(置 `电缸启动[n]`→`Y…_运行启动`)**无到位超时报警**(与气缸 `HMI_气缸到位延时报警` 不同)。

**单次定位时序伪代码(机制 B)**

```text
; 自动侧(示范: 撕膜机构 SBR_02)
SET g_x自动电缸1定位[2]              ; 请求去「撕膜位」
; SBR_电缸控制 每扫描周期
若 电缸统一手动条件 且 上升沿(g_x自动电缸1定位[2]) → MOV K3 电缸控制字[0]   ; 点位码=3
WBIT 电缸控制字[0] → Y130..132        ; 送点位码给驱动器
若 电缸控制字[0] > 0 且 X133_动作中 == 0:
      TONR(K80) → 到 → 电缸启动[0] := TRUE → Y135_运行启动 := TRUE
BITW X130..132 → 电缸状态字[0]
若 X137_伺服使能中 且 X135_原点复位中:
      HMI_电缸1在当前位[0..8] := (电缸状态字[0] == K1..K9)
若 上升沿(X136_到达目标位置) 或 下降沿(X133_动作中) 或 停机/初始化:
      电缸控制字[0] := 0; 电缸启动[0] := FALSE
若 X133_动作中 或 停机/初始化:
      清 g_x自动电缸1定位[0..9]、HMI_电缸1定位[0..9]、原点复位/自动回零请求
```

### 5.5.3 机制 C — 伺服轴(`下料Y轴`)请求/到位

| 环节 | 实现 | 证据 |
|---|---|---|
| 目标位置表 | `HMI_轴1定位位置[0..24]`(REAL,800bit) | `VarNameAndAddr.csv.txt` |
| 示教 | `HMI_轴1读取位置[n]` 上升沿 → `轴绝对定位位置[n] := 轴当前位置` | IL:17146-17216 |
| 手动请求 | `HMI_轴1定位[n]` 上升沿(且非自动模式、`HMI_定位互锁[n]`=0、轴已回零、不忙) | IL:17223-17529 |
| 自动请求 | 流程程序写 `下料Y轴.自动定位ID := K2/K3/K5` | `IL 07-SBR_03自动NG下料模组:2657/2749/2798` |
| 初始化请求 | `SET 下料Y轴.初始化找原` → 回零;`SET HMI_轴1定位[2]` → 回待机位 | `IL 22-SBR_13下料工位初始化:4890/4899` |
| 到位判定 | `|轴绝对定位位置[n] − Axis.fSetPosition| ≤ 0.05` 且 `自动定位ID=0` 稳定 K5,且 轴找原OK、不忙 → `HMI_定位OK[n]` | IL:17698-17797 |
| 到位确认(流程侧) | `AND 下料Y轴.HMI_定位OK[2]` | `IL 22-SBR_13下料工位初始化:4912` |
| 跨工位预判 | `FANDD>= 下料Y轴伺服.fSetPosition HMI_轴1定位位置[2]` ⇒ 提前启动 FL 电缸 | `IL 16-SBR_09自动FL电缸提前等待:4285-4287` |

> 注意区别: 伺服轴的到位窗口是 **0.05**(REAL 用户单位,`IL 35-FB_BODIES:17698-17699`),JXC 电缸的到位窗口是 **±2**(驱动器整数单位,`IL 35-FB_BODIES:14281-14282`)。

---

## 5.6 速度 / 位置 / 加减速来源与量纲
### 5.6.1 伺服轴(表 A)

| 参数 | HMI 符号(位长/地址) | 落点 | 生效条件 |
|---|---|---|---|
| 手动速度 | `HMI_轴手动速度`(1024bit=32×REAL @0X40A8C0) | `HMI_手动速度` 引脚 → `VAR_目标速度`(设备状态 0/10)、`VAR_手动JOG速度` | 手动/停止/手动状态 |
| 自动定位速度 | `HMI_轴自动高速`(1024bit @0X40BB80) | `HMI_定位速度` 引脚 → `VAR_目标速度` | 设备状态=40(自动) |
| 自动低速 | `HMI_轴自动低速`(1024bit @0X40AF00) | 工程内**未被 Axis_FB 引用**(推断: 仅 HMI 预留) | — |
| 回原定位速度 | `HMI_回原速度` / `HMI_轴回原速度`(1024bit) | **未接**;`HMI_回原定位速度` 引脚硬编码 `E50`(=50.0) | 设备状态=30(回原) |
| 加速度/减速度 | `HMI_轴加速度`/`HMI_轴减速度`(1024bit) | `HMI_加速度`/`HMI_减速度` → `VAR_加速度`/`VAR_减速度`,≤0 时默认 `E1000.0` | 全程 |
| 回零速度(内部) | — | `MC_HOME` 用轴配置的 `fHomeVelocity`;`MC_MOVEABSOLUTE`(回原偏移)用 `E30/E500/E500`(v=30, acc=dec=500) | 回零流程 |
| 急停减速度 | — | `MC_STOP Axis E15000 K0`(**硬编码 15000**) | 停止/限位/急停 |
| 寸动距离 | `HMI寸动位置`(1024bit @0X40ED80) | `hmi_寸动距离` → `VAR_相对定位`(正寸动 +,负寸动 `DEMUL E-1`) | 手动 |
| 位置点 | `HMI_轴1定位位置`(800bit=25×REAL @0X403E80) | `轴绝对定位位置[0..24]` | 手动选点/自动选点 |
| 回原偏移 | `HMI回原偏移`(1024bit @0X40E740) | `回原偏移` → `MC_SetPosition` 的偏置 | 回零末段 |
| 暂停位 | `HMI_暂停位置`(1024bit @0X40E100) | 与 `HMI_轴当前位置[i]` 一起送入 `FB_位置比较比较`(允差 `E0.3`) | 暂停功能 |

**量纲**: 位置/速度/加减速在 PLC 侧都是 **REAL 用户单位**(H5U 总线伺服轴的「用户单位」由轴组态中的齿轮比 `fUnits`/`sConfig.dNumerator/dDenominator` 决定)。工程文本中**没有**导出这组齿轮比与单位数值(`fUnits` 注释即「轴齿轮比 上电初始化，写入不生效」,提示它在轴配置界面设置;`临时工程\Config.sdt`、`_SYS_ECAT_MASTER.svt` 等在工程里是空壳)。可确定的量化点位: 到位窗口 **0.05 UU**、回零偏移定位速度 **30 UU/s**(推断,`E30`)、急停减速度 **15000**、默认加减速 **1000**、默认点动速度 **10**。**若需 mm 量纲须查 AutoShop 轴配置界面(本工程未导出)**。

### 5.6.2 EtherCAT JXC 电缸(表 B)

| 参数 | HMI 符号(位长/地址) | 写入路径 | 证据 |
|---|---|---|---|
| 定位速度 | `HMI_电缸速度`(160bit=10×INT @0X50DAC0),下标 5..9 | 自动: `MOV HMI_电缸定位高速 HMI_电缸速度[n]`;手动: `MOV HMI_电缸定位低速 HMI_电缸速度[n]`(**每扫描周期覆盖**) | `IL 14-SBR_07自动插FL:3607`;`IL 30-SBR_电缸控制:7317-7318` |
| 高速/低速/关盖速度 | `HMI_电缸定位高速`/`HMI_电缸定位低速`/`HMI_电缸关盖速度`(各 16bit @0X50DDE0/0X50DE00/0X50DE40) | 仅作为上面两条 MOV 的源(INT→INT) | `IL 14-SBR_07自动插FL:4050`(`MOV HMI_电缸关盖速度 HMI_电缸速度[8]`) |
| 加减速 | `HMI_电缸加减速度`(160bit=10×INT) | FB 内 `MOV 加减速度 etc加速度/减速度` → PDO `_IQn_6/_IQn_7` | `IL 35-FB_BODIES:14133-14134` |
| 点动速度 | `HMI_电缸点动速度`(32bit DINT @0X50DE20) → `HMI_点动速度`(320bit=10×DINT) | FB 内 `ETC_WriteParameter_CoE 从站号 H2260 K1 K2 HMI_点动速度`(SDO 0x2260:01, 2 字节) | `IL 35-FB_BODIES:14112` |
| 点动速度修改触发 | `HMI_点动速度修改`(10bit)+ `HMI_点动速度统一修改` | 手动且勾选「统一修改」→ `OUT HMI_点动速度修改[5..9]` → FB 逐台写 SDO | `IL 30-SBR_电缸控制:7289-7296` |
| 目标位置 | `HMI_电缸6..10定位位置`(480bit=15×DINT @0X50BB80/0X50BEA0/0X50C1C0/0X50C4E0/0X50C800) | `DMOV HMI_定位位置[n] etc目标位置` → PDO `_IQn_5` | `IL 35-FB_BODIES:14146` |
| 定位推力/定位宽度 | **无 HMI 参数** | FB 内硬编码 `MOV K100 etc定位推力`、`DMOV K300 etc定位宽度` | `IL 35-FB_BODIES:14135-14136` |

**量纲**: PLC 侧 `HMI_电缸N定位位置` 是 DINT 整数,直接对应 SMC JXC 的 `Target position`(32 位)与 `Speed`(16 位)寄存器;**具体工程单位(mm / 0.1mm / pulse 等)由 SMC JXC 驱动器参数设定,工程文本内不含单位信息**,需查 JXCE1 手册或驱动器参数(标注为不确定项)。`定位推力=100`、`定位宽度=300` 同理是驱动器侧单位(推断为 % 与 0.01mm 量级,未证实)。

### 5.6.3 IO 点位码电缸(表 C)

**无速度/位置参数**: 定位是「点位号」,速度/加减速在电缸驱动器本体设定。证据: 全工程 `HMI_电缸速度[0..4]` 零引用(`grep -c` 结果为空),`SBR_电缸控制` 中表 C 部分只用 `电缸控制字/状态字`、`电缸启动`、`Y…` 输出。

---

## 5.7 `FB_位置比较比较` 与 `FB_中断定长`
### 5.7.1 `FB_位置比较比较` —— 不是 touch probe,是「带允差的比较器」

引脚(`FB_位置比较比较.FB.strings.txt:6-14`):`IF_数据1`(REAL)、`IF_数据2`(REAL)、`IF允许波动值`(REAL)、`QB_满足`(BOOL)、`QB_不满足`(BOOL);内部 `VAR_数据1下限/VAR_数据1上限`。

```
VAR_数据1上限 := IF_数据1 + IF允许波动值          ; DEADD
VAR_数据1下限 := IF_数据1 − IF允许波动值          ; DESUB
QB_满足   := (IF_数据2 <= VAR_数据1上限) AND (IF_数据2 >= VAR_数据1下限)
QB_不满足 := (IF_数据2 >  VAR_数据1上限) OR  (IF_数据2 <  VAR_数据1下限)
```

**实际用途**: 轴「暂停位」判定与机器人点位比对。

* 调用点在 **ST 步骤**里而不是 LD 网络: `IL 27-SBR_报警:6049` `EXECUTE _STB101`(配合 `EXECUTE _STB102`, IL:6051),步骤代码以循环下标调用比较器 —— `IL 35-FB_BODIES:17840` 与 `:17856` 两次 `CALL_FB FB_位置比较比较 FBI_001 HMI_轴当前位置[i] HMI_暂停位置[i] E0.3 - -`,即逐轴(≤32)比较「当前位置 vs 暂停位置」,允差 0.3(`STsteps.dat.strings.txt` 中 `_STB101`/`_STB102` 即这两个 ST 步骤)。
* 与之配套的报警位: `g_x轴不在暂停位` 只在 `MAIN` 被读(`IL 00-MAIN:0026` `LDI gx_气缸条件不满足标记 / ANDI g_x轴不在暂停位 / AND g_x自动启动中 → MAIN_自动启动延时`,即作为「自动启动」的一个门控) 并在 `IL 27-SBR_报警:6044` 被 `RST`;`err_x轴不在暂停位置[0..31]` 只在 `IL 27-SBR_报警:6045` 被 `ZRST`。**在导出的 IL 里看不到这两者的置位指令**(编译日志末尾记录被截断),因此暂停位判定的结果当前是「有比较、无消费者」(推断)。
* 其他实例: `暂停开机位置比较`、`暂停开机位置比较1`(`功能块实例.fbi.strings.txt:16-21`)、`FB_获取机器人点位` 内的 `FB_X…FB_C`(六轴逐轴比对,允差 `E0.1`,`FB_获取机器人点位.FB.strings.txt:166-172`)。
* 该 FB **与 CiA402 的 Touch probe(0x60b8/0x60b9/0x60ba-0x60bd)没有任何关系**。

### 5.7.2 `FB_中断定长` —— 真正的「探针 + 定长」功能块,但**未被调用**

`FB_中断定长.FB.strings.txt` 内可见完整实现,`IL 35-FB_BODIES` 中该 FB 只作为本体展开存在(**无 CALL_FB**),`功能块实例.fbi.strings.txt` 也没有它的实例 → **本工程未使用探针/中断定长功能**。

接口与内部(照抄):

| 名称 | 类型 | 作用 |
|---|---|---|
| `axis` | `_sMCAXIS_INFO` | 轴对象(与 Axis_FB 同一个结构体) |
| `gx_探针故障` | BOOL | MC_TouchProbe 的 Error |
| `gf_上升探针位置` | REAL | MC_TouchProbe 的 `PosPosition`(锁存位置) |
| `ib_运行使能` | BOOL | 启动流程 |
| `if_寻探针加减速度` / `if_中断定长加减速度` / `if_寻探针速度` / `if_定长速度` | REAL | 加减速/速度参数 |
| `if_寻探针相对位置` | REAL | 找探针时的相对运动距离 |
| `if_光电相对距离` | REAL | 光电(探针)相对距离 |
| `if_速度补偿值` | REAL | 初始 `0.0015`;转成 `vf_位置补偿值 = axis.fSetVelocity × 速度补偿值` |
| `vf_中断流程` | INT | 流程号: 0/10/20/30/50/60/70 |
| `qb_运动中` / `vb_寻探针完成` / `vb_定长完成` / `vb_定长报错` / `vb_寻探针报错` / `QB_完成` / `QB_寻探针失败` | BOOL | 中间/输出标志 |

内部流程(`FB_中断定长.FB.strings.txt:60-300` 与 IL):

```
K10: MC_MoveRelative axis if_寻探针相对位置 if_寻探针速度 …
     同时 MC_TouchProbe axis K0 K0 K0 K1 … gf_上升探针位置 gx_探针故障
     (ProbeID=0, TriggerEdge=0, TerminalSource=0, TriggerMode=1, WindowOnly=0)
K20: VF_理论目标位置 := gf_上升探针位置 + if_光电相对距离
   ; 与 Old_上升探针位置 比较,若变化 → MOV K60(报错);无变化 → K30
K50: MC_MoveAbsolute axis VF_补偿后理论目标位置 if_定长速度 …
   ; VF_补偿后理论目标位置 := VF_理论目标位置 + vf_位置补偿值
K70: 完成
```

**与 CiA402 Touch probe 的对应关系**(`FB_中断定长` 引脚注释, `FB_中断定长.FB.strings.txt:64-73`):

| FB/PDO 成员 | CiA402 对象 | 说明 |
|---|---|---|
| `Axis.wTouchFunction` / `dTouchProbeID1/2` | **0x60b8** Touch probe function / 探针端子 ID | 探针功能设置,对应本工程 PDO `_IQ1_2`(`Touch probe function`) |
| `Axis.wTouchStatus` | **0x60b9** | 探针状态 → PDO `_IQ1_9` |
| `Axis.dTouch1PPos` / `dTouch1NPos` | **0x60ba / 0x60bb** | 探针1 上升沿/下降沿位置 → PDO `_IQ1_10`(本工程只映射 pos1) |
| `Axis.dTouch2PPos` / `dTouch2NPos` | **0x60bc / 0x60bd** | 探针2 上升沿/下降沿位置 → PDO `_IQ1_11`(pos2) |

而**本工程伺服的实际 PDO 里 Touch probe 对象是配齐的**(`_IQ1_2`/`_IQ1_9`/`_IQ1_10`/`_IQ1_11`,见 §7.1),说明硬件能力保留、软件未启用。真实工位里「插 FL/抚平/下压」用的是**电缸位置点位 + 到达信号**(例如 `IL 14-SBR_07自动插FL:3610-3615` 用 `HMI_电缸8在当前位[1]` 而不是探针),即**没有飞拍/位置触发/定长送料**功能。

---

## 5.8 EtherCAT PDO 映射表
过程映像符号 = `_IQ<组>_<索引>`,索引为**映射表中的条目序号**(不是字节偏移;实际地址由编译器分配,如 `_IQ1_1=0X2101A90`, `_IQ1_10=0X2103F80`)。

### 5.8.1 CiA402 伺服 `InoSV630N`(节点 `下料Y轴伺服`)→ 组 `_IQ1_*`

| 索引 | 方向 | 对象 | 名称 | 位宽 | 地址 |
|---|---|---|---|---|---|
| `_IQ1_0` | 主站→从站 | 0x6040 | Controlword | 16 | 0X2101420 |
| `_IQ1_1` | 主站→从站 | 0x607A | Target position | 32 | 0X2101A90 |
| `_IQ1_2` | 主站→从站 | 0x60b8 | Touch probe function | 16 | 0X2101430 |
| `_IQ1_3` | 主站→从站 | 0x60fe:1 | Physical outputs | 32 | 0X2101CE0 |
| `_IQ1_4` | 从站→主站 | 0x603f | Error code | 16 | 0X2101AB0 |
| `_IQ1_5` | 从站→主站 | 0x6041 | Statusword | 16 | 0X2101D00 |
| `_IQ1_6` | 从站→主站 | 0x6064 | Position actual value | 32 | 0X2103F30 |
| `_IQ1_7` | 从站→主站 | 0x6077 | Torque actual value | 16 | 0X2101D30 |
| `_IQ1_8` | 从站→主站 | 0x60f4? | Following error actual value | 32 | 0X2103F50 |
| `_IQ1_9` | 从站→主站 | 0x60b9 | Touch probe status | 16 | 0X2103F70 |
| `_IQ1_10` | 从站→主站 | 0x60ba | Touch probe pos1 pos value | 32 | 0X2103F80 |
| `_IQ1_11` | 从站→主站 | 0x60bc | Touch probe pos2 pos value | 32 | 0X2103FA0 |
| `_IQ1_12` | 从站→主站 | 0x60fd | Digital inputs | 32 | 0X2104390 |

`EtherCat.dat` 中还列出了该从站可选 PDO(`Ethercat.dat` 里的 ESI 定义块): Rx 可选 `Controlword/Target position/Target velocity/Target torque/Modes of operation/Touch probe function/Max profile velocity/…`,Tx 可选 `Error code/Statusword/Position actual value/Torque actual value/Modes of operation display/Following error actual value/Velocity actual value/…`;末尾还给出对象号对照: `16#60fe#01:Physical outputs`, `16#60b8#00:Touch probe function`, `16#607a#00:Target position`, `16#6040#00:Controlword`, `16#603f#00:Error code`, `16#60bc#00/16#60ba#00/16#60b9#00:探针`, `16#60fd#00:Digital inputs`, `16#6077#00:Torque actual value`, `16#6064#00:Position actual value`, `16#6041#00:Statusword`。同步模式 `DC-Synchron`。

### 5.8.2 JXC 电缸 `JXCE1`(5 台同构)→ 组 `_IQ3_* / _IQ5_* / _IQ7_* / _IQ9_* / _IQ11_*`

以 FL左X电缸(`_IQ3_*`,从站号 K1)为例(**名称与位宽取自 `EtherCat.dat` + `VarNameAndAddr.csv.txt`**):

**Rx PDO1(主站→从站,输出)**

| 索引 | 名称 | 位宽 | 地址 | `ETC电缸` 中的用法 |
|---|---|---|---|---|
| `_IQ3_0` | *(表中首行显示名 = `Output port to which signals are allcated`)* | 16 | 0X2103FC0 | 接 FB 的 `etc控制字`(bit9 使能/bit11 报警复位/bit12 回原点/bit13 反向点动/bit14 正向点动) |
| `_IQ3_1` | Numerical data flag | 16 | 0X21043B0 | `etc数据标志`(bit4..15 恒置 1) |
| `_IQ3_2` | Start flag | 8 | 0X2101758 | `etc启动标志`(bit0 启动) |
| `_IQ3_3` | Operation Method | 8 | 0X2101778 | `etc动作方法`(bit0=0) |
| `_IQ3_4` | Speed | 16 | 0X21043C0 | `etc目标速度` ← `HMI_电缸速度[N]` |
| `_IQ3_5` | Target position | 32 | 0X21043D0 | `etc目标位置` ← `DMOV HMI_电缸N定位位置[n]` |
| `_IQ3_6` | Acceleration | 16 | 0X21043F0 | `etc加速度` ← `HMI_电缸加减速度[N]` |
| `_IQ3_7` | Deceleration | 16 | 0X2104400 | `etc减速度` ← `HMI_电缸加减速度[N]` |
| `_IQ3_8` | Pushing force | 16 | 0X2104410 | — |
| `_IQ3_9` | Trigger LV | 16 | 0X2104420 | — |
| `_IQ3_10` | Pushing speed | 16 | 0X2104430 | — |
| `_IQ3_11` | Pushing force for positioning | 16 | 0X2104440 | `etc定位推力` ← 常数 K100 |
| `_IQ3_12` | Area1 | 32 | 0X2104450 | — |
| `_IQ3_13` | Area2 | 32 | 0X2104470 | — |
| `_IQ3_14` | Positioning width | 32 | 0X2104590 | `etc定位宽度` ← 常数 K300 |

**Tx PDO1(从站→主站,输入)**

| 索引 | 名称 | 位宽 | 地址 | `ETC电缸` 中的用法 |
|---|---|---|---|---|
| `_IQ3_15` | *(表中首行显示名 = `Signal allocated to the input port`)* | 16 | 0X2104990 | 接 FB 的 `etc状态字`(bit8 运动中 / bit9 使能完成 / bit10 回零完成 / bit15 报警) |
| `_IQ3_16` | Controller information flag | 16 | 0X21049A0 | — |
| `_IQ3_17` | Current position | 32 | 0X21049B0 | `etc当前位置` → `HMI_电缸当前位置[N]`,并用于 ±2 到位窗口 |
| `_IQ3_18` | Current speed | 16 | 0X21049D0 | `etc当前速度`(未接,监控用) |
| `_IQ3_19` | Current pushing force | 16 | 0X21049E0 | — |
| `_IQ3_20` | Target position | 32 | 0X21049F0 | — |
| `_IQ3_21..24` | Alarm1..Alarm4 | 8×4 | 0X2101D48/0X2104A10/0X2104A18/0X2104A20 | 未接(FB 只取状态字 bit15) |

> **映射表首行问题(重要, 供后续维护)**: 每个方向的首行在工程里被赋予了过程映像符号(`_IQn_0` / `_IQn_15`)且显示名是表格标题文字;`ETC电缸` 正是把 `etc控制字`/`etc状态字` 接到了这两行。结合 FB 对 bit 语义的使用(bit9=使能完成、bit8=运动中、bit15=报警)以及位宽序列(`_IQn_17`=32 位=Current position),可判定「首行」实际就是驱动器**第一个字:数值数据标志(主站侧)/控制器信息标志(从站侧)**,而名称列相对条目**错位一格**(推断,依据:位宽与名称的对应关系在 `_IQn_17..24` 上完全吻合)。故上表按「FB 实际读写语义」标注,名称列照抄工程显示名。

### 5.8.3 `_IQ` 组归属汇总

| 组 | 归属 | 从站号 | 备注 |
|---|---|---|---|
| `_IQ1_*` | 伺服 `InoSV630N`(CiA402 PDO) | — | 只有 1 组,证明**线上只有 1 台伺服** |
| `_IQ3_*` | `JXCE1`(FL左X电缸) | K1 | JXC 电缸 PDO(25 条) |
| `_IQ5_*` | `JXCE1_1`(FL左Y电缸) | K2 | 同上 |
| `_IQ7_*` | `JXCE1_2`(FL左Z电缸) | K3 | 同上 |
| `_IQ9_*` | `JXCE1_3`(FL右Y电缸) | K4 | 同上 |
| `_IQ11_*` | `JXCE1_4`(FL右Z电缸) | K5 | 同上 |

即题目所问的 `_IQ1_x` = **伺服(CiA402)**;`_IQ3_x / _IQ5_x / _IQ7_x / _IQ9_x / _IQ11_x` = **JXC 电缸**。**GL20 与 GE20 不在 EtherCAT 过程映像里**(本地扩展 IO,`GL20ModuleCfg.data`);机器人走 EtherNet/IP(`EIP.dat`: `192.168.1.60`, `192.168.1.61`, `FANUC_Robot_R30iB_Plus`)。

---

## 5.9 多轴互锁与安全
### 5.9.1 全局停机链(所有运动的最终闸门)

```text
g_x停止 := HMI_停止 OR NOT X1_停止按钮        ; 停止按钮常闭, 断开即停  (IL 00-MAIN:41-43)
g_x急停 := NOT X3_前急停按钮                                                     (IL 00-MAIN:44-45)
MIAN_停机 := M8000 AND [ ((QB_初始化中 OR QB_自动中) AND HMI_设备报警)
                        OR g_x停止 OR err_x前急停报警 OR err_x后急停报警 ]        (IL 00-MAIN:46-54)
```

`MIAN_停机` 同时送到: `Axis_FB.停止`(→ `ANDI 停止` 门控所有运动 + `MC_Stop`)、`ETC电缸.停机`(清请求)、表 C 的 `电缸统一手动条件`/暂停/清除请求路径。

### 5.9.2 `Axis_FB` 内部互锁

| 互锁 | 表达式(IL) | 后果 |
|---|---|---|
| 停止 | `ANDI 停止` 门控 `MC_JOG`/`MC_HOME`/`MC_MoveAbsolute`/`MC_MoveRelative` | 停轴 |
| `MC_Stop` 触发 | `(LD 停止) OR (QX_正软限位中 ANDI JOG负) OR (QX_负软限位中 ANDI JOG正)`(IL:17683-17691) | 减速停(15000) |
| 软限位 | `ix_软限位使能 AND (HMI_正软限位 / HMI_负软限位)`(IL:17536-17567) | **本实例未启用**(内部变量恒 0) |
| 方向互锁 JOG | `LDI QX_正软限位中 ANDI QX_负软限位中`(IL:17583-17592) | 因软限位恒 0,实际不限制方向 |
| 硬限位报警 | `HMI_负限位触发(=DIstatus.0) AND <> wPLCOpenState K7 AND NOT Home_Busy` → `OUT 负限位报警`,自保持直至 `故障复位`(IL:17816-17836) | 报告警(锁存) |
| 回零中的限位屏蔽 | `HMI_正/负限位触发 AND <> Axis.wPLCOpenState K7 AND NOT Home_Busy` | 回零过程中不报限位 |
| 驱动器故障 | `MC_READAXISERROR` → `ErrID[0]≠0 且 ≠H5444/H5443` → `SET 轴报警` | 报警(清:H5443/H5444 例外) |
| 轴未使能 | `wPLCOpenState = 0 AND NOT 轴使能OK` → `轴没使能` | 送 `HMI_轴没使能` → 报警集合 |
| 机械防撞 | `下料Y轴.急停 = NOT((非维修中 AND 升降气缸原位OK) OR 自动中 OR 初始化中 OR 自动暂停中)` → `err_下料Y轴防撞不能运行`(`IL 34:7560-7570`) | **只报警**;`Axis_FB.急停` 引脚未接 |
| 半自动允许 | `半自动允许` 引脚(=`QB_半自动中`)参与使能/运动允许 | 未在 FB 内门控(仅传入) |
| 定位互锁 | `HMI_定位互锁[n]`(内部 BOOL[30]) | 恒 0 → 未启用 |
| 自动互锁 | `自动互锁` 引脚(`ANDI 自动互锁`,IL:17632) | 未接 → 无附加约束 |

**多轴/多机构联动与互锁实例**

* 左右两侧同步动作按钮(手动): `ANDI HMI_手自动切换 AND HMI_左右Y同时到下压位 → SET HMI_电缸7定位[2]; SET HMI_电缸9定位[4]`(Y 侧两台同时下压);`左右Z同时到下压位 → SET 电缸8定位[2];SET 电缸10定位[4]`;推入位同理(`IL 30-SBR_电缸控制:7297-7333`)。
* 一台驱动器带两侧同时点动: `HMI_电缸Y一起正向点动 → OUT FL左Y电缸.正向点动` 与 `OUT FL右Y电缸.正向点动`(同一按钮驱动两台,IL:7331-7377)。
* 跨机构提前动作(缩短节拍): `IL 16-SBR_09自动FL电缸提前等待:4285` 用**轴的目标位置** `下料Y轴伺服.fSetPosition ≥ HMI_轴1定位位置[2]` 作为前置条件,提前把 FL 三台电缸(6/7/10)推向 `夹FL位[1]`,再以 `HMI_电缸6/7/10在当前位[1]` 同时满足作为放行条件(IL:4290-4296)。
* 初始化顺序互锁: `SBR_13下料工位初始化` 里 8 号电缸→10 号电缸→`SET 下料Y轴.初始化找原`→等 `轴找原OK`→`SET HMI_轴1定位[2]`→等 `HMI_定位OK[2]`(IL:4865-4912)。

### 5.9.3 电缸互锁/安全

| 项 | 机制 A(ETC电缸) | 机制 B(IO 电缸) |
|---|---|---|
| 手动允许 | `LDI 手自动模式` 才接受 `HMI_定位触发` | `电缸统一手动条件 = M8000 AND NOT MIAN_停机 AND NOT QB_自动中` |
| 停机 | `停机` 引脚 → 清 0..9 号请求 + `RST etc启动标志.0`(IL:14071-14076) | `MIAN_停机` → `Y…_暂停`、清请求、`MOV K0 电缸控制字` |
| 暂停 | 无独立暂停引脚;靠点动/停止/请求清除 | `HMI_电缸暂停[n] OR MIAN_停机 → OUT Y…_暂停` |
| 报警 | `etc状态字.15 → SET 电缸报警中`(锁存),`报警复位`(= `MIAN_故障清除`)清除;`ZRST` 位置 | 无驱动器报警字位;`HMI_电缸报警复位[n] OR MIAN_故障清除 → OUT Y…_报警复位` |
| 使能 | `etc控制字.9`,手动模式随 `HMI_电缸使能[N]` 取反(低有效) | `Y…_伺服使能ON` 随 `HMI_电缸使能[n]` 取反(低有效) |
| 回零 | `回原点触发 OR 自动回原点触发 → etc控制字.12`;`状态字.10 且 |位置|≤1` → `TONR K50` → `回原点完成` | `Y…_原点复位`;`ANDP X…_原点复位中 → g_x电缸回零完成[n]` |

### 5.9.4 报警聚合(`SBR_报警`)

```text
BITDW HMI_电缸报警中 → 电缸故障集合 K10                         (IL 27-SBR_报警:6053)
BITDW HMI_轴报警[0] → 轴故障集合 K32                            (IL:6013)
(非初始化中 AND 非自动中) → BITDW HMI_轴没使能[0] → 轴未使能集合 K16   (IL:6015-6018)
BITDW 从站在线状态[0..5] → 驱动通讯故障集合 K6                  (IL:6055, 判据 _ECATSlave[i].bSlaveRunState / wALState == K8)
MIAN_故障清除 → DMOV K0 轴未使能集合/驱动通讯故障集合; DWBIT 回写 HMI_轴没使能/HMI_驱动通讯报警 (IL:6020-6024)
```

### 5.9.5 与库模板 `SBR0-伺服回零 / 伺服点动 / 伺服报警 / 轴紧急停止` 的差异

工程目录里虽存在 `SBR0-伺服回零.libtemp`、`SBR0-伺服点动.libtemp`、`SBR0-伺服报警.libtemp`、`SBR0-轴紧急停止.libtemp` 等**库模板文件,但内容均为空**(`*artifacts/text/SBR0-*.libtemp.strings.txt` 全部只有 4 行文件头 `AutoShop/6.0/6.0/clQobtqa`,且 `folder.txt` 的工程树中不含这些程序)。因此:

* 本工程**没有使用**汇川模板库的伺服子程序;回零/点动/相对定位/绝对定位/报警/急停**全部自写**在 `Axis_FB` 内(§3.3),好处是 25 点位/示教/低有效使能/软件限位开关等 HMI 定制需求集中在一个 FB;代价是模板里的`轴紧急停止`独立安全路径**缺失**——急停只到 `MIAN_停机`→`MC_Stop`,而 `Axis_FB.急停` 引脚悬空(§2.4)。
* 模板 `SBR0-跑点位绝对定位/相对定位` 的等价物是 FB 的 `自动定位ID + 轴绝对定位位置[25]` 机制(§4.3)。

---

## 5.10 不确定项 / 待现场确认
1. **轴齿轮比与用户单位**: `下料Y轴` 的 `fUnits`(轴齿轮比)与工程单位数值未随文本导出,文档只能给出「窗口 0.05 UU」「E30/E50/E1000/E15000」等常量。需在 AutoShop「轴配置」界面确认后才可换算 mm。
2. **SMC JXC 位置/速度/推力单位**: `HMI_电缸N定位位置`(DINT)与 `Speed`(INT)对应驱动器内部单位,`定位推力=100`、`定位宽度=300` 亦然;SMC 手册不在工程内,未能证实(标注为推断)。
3. **JXC 状态字位定义**: bit8=运动中、bit9=使能完成、bit10=回零完成、bit15=报警 由 FB 用法反推,未与 SMC 手册逐位核对。
4. **PDO 映射首行(见 §7.2 注)**: 工程配置把每个方向第一条映射行的显示名写成了表格标题文字;`ETC电缸` 的 `etc控制字/etc状态字` 就接在该行上。若后续误改该行,整套 FL 电缸会失效。
5. **机制 B 的 K8/K9 分支**(`定位[7]/[8]`)在 3 位状态码下恒不成立(推断),未在实机上验证是否为死代码。
6. `FB_中断定长` 与 `MC_TouchProbe` 未使用;`EtherCat.dat` 里伺服仍配置了 Touch probe PDO(`_IQ1_2/_IQ1_9/_IQ1_10/_IQ1_11`)——若将来启用飞拍/位置触发,可直接复用该 PDO 与 `FB_中断定长`。
7. 表 C 的 5 台电缸«点位码 1..7» 与驱动器「步信息」编号的实际对应(是否 1 起、有无 0 号)未确认;`X…_步信息区域内` 语义亦未在程序中直接使用。

## 5.11 三种控制层级一页对比
| 维度 | A. IO 型智能电缸（5 台） | B. 总线型电缸（5 台） | C. PLCopen 伺服轴（1 台） |
|

## 5.12 PLC 控步进电机的三条路（为什么这台机没有步进）

你问的是"**PLC 对步进 or 伺服的控制**"。先说结论：**这台机没有步进电机**——全工程找不到任何脉冲口/脉冲当量/步进相关符号，
`PLS` 指令只出现 1 次且用于"密码错误计时复位"（`35-FB_BODIES.il.txt:7900`），与运动无关。
但 H5U 具备控步进的能力（轴对象里有"本地脉冲轴"专用字段），所以三条路都值得知道：

| 路线 | 接线 | PLC 侧怎么做 | 优点 | 缺点 | 本机对应 |
|---|---|---|---|---|---|
| **① PLC 高速脉冲口 + 步进驱动器** | PLC `Y0/Y1/Y2/Y3`（脉冲/方向/使能）→ 驱动器 → 步进电机 | 把该 Y 口配成"本地脉冲轴"，用轴对象 + `MC_*`（或脉冲指令）编程；要设**脉冲当量**（一圈脉冲数 `DPLUSEPRECYCLE`）、最大频率、加减速、回零方式（`IHOMEMETHOD`） | 便宜、通用、接线简单 | 开环会丢步、高速力矩下降、距离受脉冲频率限制 | 无（本机未用脉冲口） |
| **② 闭环步进/一体式步进电缸 + IO 或总线** | 驱动器/控制器内置在机构上 | 总线型：读写 PDO（位置/速度/状态）；IO 型：只管"选点 + 启动 + 到位反馈" | PLC 侧极简、厂家把运动算法封好 | 灵活性受限（点位由驱动器侧定） | **本机 10 台电缸就是这条路**（5 台 EtherCAT + 5 台 IO 点位码） |
| **③ 脉冲型伺服（脉冲/方向接口）** | 同 ①，驱动器换伺服 | 与 ① 完全一样（PLC 侧不区分步进/伺服） | 比步进力矩大、可闭环 | 仍是脉冲接口，受频率限制 | 无（本机的伺服走 EtherCAT 总线型，属于 C 类） |

**"控步进"和"控伺服"在 PLC 编程层面几乎一样**，真正要搞清的是这几件事（无论哪种路线都会被问到）：

1. **脉冲当量 / 电子齿轮比**：1 个脉冲走多少毫米（或"电机一圈多少脉冲 × 机械减速比"）。
   本工程的伺服/电缸都是**总线轴**，等价参数是"齿轮比 `DNUMERATOR/DDENOMINATOR`、`FUNITS`"，以及**到位窗口**（伺服 ±0.05 用户单位、JXC 电缸 ±2 驱动器单位，见 5.6）。
2. **加减速**：梯形/S 曲线。本工程在 HMI 上有 `HMI_轴加速度/减速度`、`HMI_电缸加减速度`（自动/手动两套，手动常限速）。
3. **回零**：步进通常靠原点开关 + 编码器 Z 相；H5U 轴对象里有 `IHOMEMETHOD / FHOMEVELOCITY / FHOMEAPPROACHVELOCITY / FPOSITIONOFFSER / DHOMETIMEOUT`。
   本机两条回零路：伺服 `MC_HOME`；IO 型电缸靠"原点复位"输出 + `X*5_原点复位中` 反馈（点位由电缸控制器自己记）。
4. **限位与安全**：硬限位（行程开关进 PLC 输入）、软限位（轴参数）、以及"停止类别"（急停/停止/暂停）。
   ⚠ 本工程"软限位使能与定位互锁"**未启用**，`Axis_FB.急停` 引脚悬空，防撞互锁只报警不停轴（详见 5.9）——这是安全上值得向上游提出的改进点。
5. **是否闭环**：丢步了 PLC 知不知道？——这就是为什么现场越来越倾向"总线伺服/一体式电缸"（有位置反馈、有报警、能读当前推力）。

> 一句话选型建议：**精度/推力要求高的压接、插接动作 → 总线伺服或一体式电缸（本机的选择）；
> 只有简单来回、成本敏感的场合 → 脉冲步进 + 本地脉冲轴**。
