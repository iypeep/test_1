# tools —— 分析复现脚本

| 脚本 | 作用 | 用法 |
|---|---|---|
| `dump_strings.py` | 从 AutoShop 二进制工程文件（`.LD/.FB/.gvt/.stru`…）抽取 UTF-8 明文串（含中文注释、FB 引脚注释），生成 `*.strings.txt`；UTF-16 的 `*.csv` 直接转码 | `python dump_strings.py <工程目录> [输出目录]` |
| `split_il.py` | 把编译输出 `il_log.log`（全工程指令表）按 `SRET` 切分为各程序，用符号签名自动命名；末尾 FB 展开区单独成段 | `python split_il.py <il_log.log> <text目录> [输出目录]` |
| `export_symbols.py` | 把 `VarNameAndAddr.csv`（6009 个符号）转成上位机可用地址字典 `symbols.csv` / `symbols.json` | `python export_symbols.py <VarNameAndAddr.csv> [输出目录]` |

## 典型流程

```bash
# 1) 把工程二进制转成可读文本
python tools/dump_strings.py "project/临时工程" artifacts/text
# 2) 切分编译后的指令表（工程里 Compile/ 或 il_log.log）
python tools/split_il.py "project/临时工程/il_log.log" artifacts/text artifacts/il
# 3) 导出符号地址字典（上位机对接用）
python tools/export_symbols.py "project/临时工程/VarNameAndAddr.csv" artifacts/definitions
```

依赖：仅 Python 3.8+ 标准库。
