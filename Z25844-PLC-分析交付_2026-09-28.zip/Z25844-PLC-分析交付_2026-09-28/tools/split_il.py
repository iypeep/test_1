#!/usr/bin/env python3
"""把 AutoShop 编译输出的 il_log.log（全工程指令表）按程序切分并命名。

il_log.log 形如（<地址>\\t<指令> <操作数>）：
    0000	LD M8000
    0002	AND 设备状态机.QB_手动中
    0279	CALL SBR_CT产能
    ...
    1026	SRET
    17854	FBRET FB_位置比较比较

分段策略：
  * 以 `SRET` 为界切出各 LD 程序体，段数 = MAIN + 被调用子程序数；
  * 用每个程序对应的 `.strings.txt` 提取的符号集合做“签名匹配”，自动判定段落属于哪个程序；
  * `FBRET <FB名>` 之后到文件末尾为各 FB 的实例/本体展开区，单独成段。

用法：
    python split_il.py <il_log.log> <text_dir> [输出目录]
"""
import collections
import re
import sys
from pathlib import Path

TOK = re.compile(r'[\u4e00-\u9fff][\u4e00-\u9fffA-Za-z_0-9]{2,}|[A-Za-z_][A-Za-z_0-9]{3,}')


def ins(line: str) -> str:
    return line.split('\t', 1)[1] if '\t' in line else line


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    il_path, text_dir = Path(sys.argv[1]), Path(sys.argv[2])
    out = Path(sys.argv[3]) if len(sys.argv) > 3 else (il_path.parent.parent / '_il')
    out.mkdir(parents=True, exist_ok=True)

    lines = il_path.read_text(encoding='utf-8', errors='replace').splitlines()

    # 各程序的符号签名（来自 dump_strings.py 的输出）
    sigs = {p.name[:-len('.LD.strings.txt')]: set(TOK.findall(p.read_text(encoding='utf-8')))
            for p in text_dir.glob('*.LD.strings.txt')}

    sret = [i for i, l in enumerate(lines) if ins(l).strip() == 'SRET']
    bounds = [-1] + sret + [len(lines) - 1]

    index = []
    for k in range(len(bounds) - 1):
        body = lines[bounds[k] + 1: bounds[k + 1] + 1]
        toks = set(TOK.findall("\n".join(body)))
        best = max(((len(toks & s), n) for n, s in sigs.items()), default=(0, f'chunk{k}'))
        name = best[1] if best[0] > 20 else f'chunk{k}'
        fn = f'{k:02d}-{name}.il.txt'
        (out / fn).write_text("\n".join(body), encoding='utf-8')
        index.append((fn, bounds[k] + 2, bounds[k + 1] + 1, len(body)))

    (out / 'INDEX.md').write_text(
        "# il_log.log 分段索引\n\n| 文件 | 原始行范围 | 规模 |\n|---|---|---|\n" +
        "\n".join(f'| {f} | {a}-{b} | {n} 条指令 |' for f, a, b, n in index) + "\n",
        encoding='utf-8')
    print(f'切出 {len(index)} 段 → {out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
