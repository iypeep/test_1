#!/usr/bin/env python3
"""il2c.py —— 把 AutoShop 编译输出的 IL（il_log.log / artifacts/il/*.il.txt）重建为可读的 C 工程。

设计目标：**可读 + 可跳转 + 可编译运行**（不是逐位仿真 PLC）。
  * 每个 LD 子程序 → 一个 C 函数；每个 FB → 一个 struct + 一个函数（实例 = struct 变量）
  * 每个网络（rung）→ 一个 `if (条件) { 动作 }`，并带 `/* IL:地址 */` 注释便于与 AutoShop 对照
  * 边沿触点 / 定时器 → 每调用点一份静态状态（与原 PLC 语义一致）
  * 未在本工程出现的指令一律不生成（生成器对无法翻译的指令会报错，不会静默丢弃）

用法：
    python il2c.py --il-dir artifacts/il --symbols artifacts/text/VarNameAndAddr.csv.txt \
                   --out cproject
"""
from __future__ import annotations

import argparse
import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

# ----------------------------------------------------------------------------- 符号层

BIT_PREFIX = set("XYMSTCB")          # 位软元件前缀
WORD_PREFIX = set("DWR")             # 字软元件前缀


@dataclass
class Sym:
    name: str
    bits: int
    addr: str = ""
    comment: str = ""

    @property
    def is_array(self) -> bool:
        return self.bits > 32 or (self.bits > 16 and self.bits % 32 == 0 and self.bits > 32) \
            or self.bits in (64, 96, 128, 160, 200, 224, 320, 640, 3200, 1600, 800, 400, 1600)

    def ctype(self) -> str:
        b = self.bits
        if b == 1:
            return "plc_bit"
        if b <= 16:
            return "int16_t"
        if b <= 32:
            return "int32_t"
        # 数组：按元素宽度推断
        if b % 32 == 0 and b // 32 in (2, 4, 6, 8, 10, 16, 20, 40, 50, 100, 200):
            return "int32_t"
        if b % 16 == 0:
            return "int16_t"
        return "plc_bit"

    def carray(self) -> str:
        """返回数组长度（0 = 标量）。"""
        b, t = self.bits, self.ctype()
        if t == "plc_bit":
            return str(b) if b > 1 else "0"
        if t == "int16_t":
            return str(b // 16) if b > 16 else "0"
        if t == "int32_t":
            return str(b // 32) if b > 32 else "0"
        return "0"


def load_symbols(csv_path: Path) -> dict[str, Sym]:
    syms: dict[str, Sym] = {}
    for line in csv_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        p = line.split("\t")
        name = p[0].strip()
        bits = int(p[3]) if len(p) > 3 and p[3].strip().isdigit() else 1
        if name:
            syms[name] = Sym(name, bits, p[1].strip() if len(p) > 1 else "",
                             p[2].strip() if len(p) > 2 else "")
    return syms


# ----------------------------------------------------------------------------- 操作数

def is_const(tok: str) -> bool:
    return bool(re.fullmatch(r"[KHB]-?\d+", tok)) or tok in ("-",)


def const_value(tok: str) -> str | None:
    if re.fullmatch(r"K-?\d+", tok):
        return tok[1:]
    if re.fullmatch(r"H[0-9A-Fa-f]+", tok):
        return "0x" + tok[1:]
    if re.fullmatch(r"B[01]+", tok):
        return "0b" + tok[1:]
    # 浮点常数：E50 / E0.3 / E-1.5
    if re.fullmatch(r"E-?\d+(\.\d+)?", tok):
        return tok[1:] if "." in tok else tok[1:] + ".0"
    return None


def flatten_device_bit(tok: str) -> str | None:
    """W0.10 / X0.3 → W0_10（位级建模，避免 C 里做位域）"""
    m = re.fullmatch(r"([A-Z]+\d+)\.(\d+)", tok)
    if m and m.group(1)[0] in "WMXY":
        return f"{m.group(1)}_{m.group(2)}"
    return None


def ident(name: str) -> str:
    """把符号名转成合法 C 标识符（保留中文；首字符非法时前缀下划线）。"""
    n = name.replace(".", "__") if not re.fullmatch(r"[\w\u4e00-\u9fff]+(\.[\w\u4e00-\u9fff]+)*", name) else name
    if n and (n[0].isdigit() or n[0] == "_" and len(n) > 1 and n[1].isdigit()):
        n = "_" + n
    return n


def operand(tok: str, fb_pins: set[str] | None, enums: set[str]) -> str:
    """IL 操作数 → C 表达式。"""
    tok = tok.strip()
    cv = const_value(tok)
    if cv is not None:
        return cv
    flat = flatten_device_bit(tok)
    if flat:
        return ident(flat)
    m = re.fullmatch(r"([^.\[\]]+)\[([^\]]+)\]", tok)
    if m:
        base, idx = m.group(1), m.group(2)
        idx_c = operand(idx, fb_pins, enums) if not re.fullmatch(r"\d+", idx) else idx
        if fb_pins and base in fb_pins:                 # 数组型引脚：形参本身已是元素指针
            return f"{ident(base)}[{idx_c}]"
        if CUR_LOCALS and base in CUR_LOCALS:           # FB 局部数组（实例成员）
            return f"self->{ident(base)}[{idx_c}]"
        return f"{ident(base)}[{idx_c}]"
    if fb_pins and tok in fb_pins:
        return f"(*{ident(tok)})"      # 引脚 = 指针形参（别名：实例成员或外部绑定变量）
    if CUR_LOCALS and tok in CUR_LOCALS:
        # FB 局部量 = 实例成员；若它是数组，整体使用等价于第 0 个元素
        return f"self->{ident(tok)}" + ("[0]" if tok in LOCAL_ARRAYS else "")
    mb = re.fullmatch(r"(.+)\.(\d+)", tok)
    if mb:                                         # 字软元件按位访问：etc控制字.9
        return f"BIT_R({operand(mb.group(1), fb_pins, enums)}, {mb.group(2)})"
    if "." in tok:
        base, mem = tok.split(".", 1)
        if fb_pins and base in fb_pins:            # 引脚（指针）的成员：(*Axis).fActPosition
            return f"(*{ident(base)}).{ident(mem)}"
        if CUR_LOCALS and base in CUR_LOCALS:
            return f"self->{ident(base)}.{ident(mem)}"
        return f"{ident(base)}.{ident(mem)}"
    return ident(tok)


# ----------------------------------------------------------------------------- 翻译单元

@dataclass
class Ctx:
    lines: list[str] = field(default_factory=list)     # 生成的 C 语句
    cur: str | None = None                            # 当前块表达式
    pending: list[str] = field(default_factory=list)  # LD 压入的待合并块
    br: list[str] = field(default_factory=list)       # MPS/MRD/MPP 分支栈
    edge: list[tuple[str, str]] = field(default_factory=list)  # (变量名, 类型)
    statics: list[tuple[str, str, str]] = field(default_factory=list)
    n_tmp: int = 0
    n_edge: int = 0
    todo: list[str] = field(default_factory=list)

    def ind(self, s: str, lvl: int = 1) -> None:
        self.lines.append("    " * lvl + s)

    def tmp(self, ty: str = "double") -> str:
        self.n_tmp += 1
        name = f"t{self.n_tmp}"
        self.statics.append((name, ty, "tmp"))
        return name

    def edgevar(self, kind: str) -> str:
        self.n_edge += 1
        name = f"e{self.n_edge}"
        self.edge.append((name, kind))
        return name


CMP = {
    "=": "==", "<>": "!=", ">": ">", "<": "<", ">=": ">=", "<=": "<=",
    "><": "!=",
}


def cond_cmp(mn: str, args: list[str], ctx: Ctx, pins, enums) -> str:
    """比较类触点：AND= / LD<> / ANDD>= / FANDD<= / OR> ..."""
    m = re.fullmatch(r"(F)?(LD|AND|OR)(D)?([=<>]{1,2})", mn)
    assert m, mn
    op = CMP[m.group(4)]
    kind = ("F" if m.group(1) else "") + (m.group(3) or "")
    a, b = operand(args[0], pins, enums), operand(args[1], pins, enums)
    if kind.startswith("F"):
        return f"((double)({a}) {op} (double)({b}))"
    if kind.startswith("D"):
        return f"((int32_t)({a}) {op} (int32_t)({b}))"
    return f"(({a}) {op} ({b}))"


def contact(mn: str, arg: str, ctx: Ctx, pins, enums) -> str:
    """单操作数触点（可带边沿）。"""
    ex = operand(arg, pins, enums)
    if mn in ("LDP", "ANDP", "ORP"):
        v = ctx.edgevar("re")
        return f"RE(&{v}, {ex})"
    if mn in ("LDF", "ANDF", "ORF"):
        v = ctx.edgevar("fe")
        return f"FE(&{v}, {ex})"
    if mn in ("LDI", "ANDI", "ORI"):
        return f"!({ex})"
    return ex


def build_expr(mn: str, args: list[str], ctx: Ctx, pins, enums) -> str:
    if re.fullmatch(r"(F)?(LD|AND|OR)(D)?[=<>]{1,2}", mn):
        return cond_cmp(mn, args, ctx, pins, enums)
    if mn in ("LD", "LDI", "LDP", "LDF", "AND", "ANDI", "ANDP", "ANDF", "OR", "ORI", "ORP", "ORF"):
        return contact(mn, args[0], ctx, pins, enums)
    raise KeyError(mn)


def combine(mn: str, expr: str, ctx: Ctx) -> None:
    if mn in ("LD", "LDI", "LDP", "LDF") or mn.startswith("LD"):
        if ctx.cur is not None:
            ctx.pending.append(ctx.cur)
        ctx.cur = expr
    elif mn.startswith("OR"):
        ctx.cur = expr if ctx.cur is None else f"({ctx.cur}) || ({expr})"
    else:  # AND*
        ctx.cur = expr if ctx.cur is None else f"({ctx.cur}) && ({expr})"


def gate(ctx: Ctx, body: str, addr: str | None, il: str | None, already: bool = False) -> None:
    c = ctx.cur if ctx.cur is not None else "1"
    if already:
        ind = "\n    ".join(body.split("\n"))
        ctx.lines.append(f"    if ({c}) {{ {ind} }}")
        return
    ctx.lines.append(f"    /* IL:{addr}  {il} */")
    ctx.lines.append(f"    if ({c}) {{ {body} }}")


def gate_edge(ctx: Ctx, body: str, addr: str, il: str) -> None:
    c = ctx.cur if ctx.cur is not None else "1"
    v = ctx.edgevar("re")
    ctx.lines.append(f"    /* IL:{addr}  {il} */")
    ctx.lines.append(f"    if (RE(&{v}, {c})) {{ {body} }}")


ACT_MOVE = {"MOV", "DMOV", "MOVP", "DMOVP", "DEMOV", "EMOV", "DEMOVP"}


def stmt(mn: str, args: list[str], ctx: Ctx, pins, enums, addr: str, raw: str) -> None:
    op = lambda i: operand(args[i], pins, enums)
    if mn in ("OUT",):
        mb = re.fullmatch(r"(.+)\.(\d+)", args[0])
        if mb:                                       # OUT 字软元件的位
            gate(ctx, f"BIT_W({operand(mb.group(1), pins, enums)}, {mb.group(2)}, "
                      f"({ctx.cur if ctx.cur is not None else '1'}));", addr, raw)
        else:
            gate(ctx, f"{op(0)} = ({ctx.cur if ctx.cur is not None else '1'});", addr, raw)
    elif mn in ("SET", "RST"):
        mb = re.fullmatch(r"(.+)\.(\d+)", args[0])
        if mb:
            gate(ctx, f"BIT_{'SET' if mn == 'SET' else 'CLR'}"
                      f"({operand(mb.group(1), pins, enums)}, {mb.group(2)});", addr, raw)
        else:
            gate(ctx, f"{op(0)} = {1 if mn == 'SET' else 0};", addr, raw)
    elif mn == "ZRST":
        mo = [re.fullmatch(r"(.+)\[(\d+)\]", a) for a in args[:2]]
        if all(mo):
            base, i, j = mo[0].group(1), int(mo[0].group(2)), int(mo[1].group(2))
            fn = "FILLB" if base in BIT_ARRAYS else "FILL"
            gate(ctx, f"{fn}(&{operand(f'{base}[{i}]', pins, enums)}, 0, "
                      f"{abs(j - i) + 1});", addr, raw)
        else:
            gate(ctx, f"/* ZRST 未翻译: {raw} */", addr, raw)
    elif mn in ACT_MOVE:
        if mn.endswith("P"):
            gate_edge(ctx, f"{op(1)} = {op(0)};", addr, raw)
        else:
            gate(ctx, f"{op(1)} = {op(0)};", addr, raw)
    elif mn in ("BMOV", "DBMOV", "FMOV", "WSFL", "STRMOV", "LEN", "WTODW", "DFLT", "DDIV", "DMOD",
                "DADD", "DSUB", "DMUL", "DEDIV", "DEMUL", "DEADD", "DESUB", "DFLOOR", "INV",
                "TACR", "TONR", "BITW", "WBIT", "BITDW", "DWBIT", "TRD", "TWR", "PLSMNH",
                "INC", "DEC", "INCP", "DECP", "MUL", "ADD", "SUB", "DIV", "MOD", "EMUL", "EADD",
                "ESUB", "EDIV", "LDD"):
        emit_misc(mn, args, ctx, pins, enums, addr, raw)
    elif mn == "PLS":
        gate(ctx, f"PLS_({op(0)});", addr, raw)
    elif mn in LIB_MN:
        emit_lib_call(mn, args, ctx, pins, enums, addr, raw)
    elif mn == "CALL":
        target = PROG_ALIAS.get(args[0], args[0])   # 大小写差异（SBR_06自动NG… vs .ng…）
        if target in MISSING_PROGS:       # 本体未包含在编译输出里（厂商加密块）
            ctx.lines.append(f"    /* IL:{addr}  {raw} */")
            ctx.lines.append(f"    /* 注：子程序「{args[0]}」本体未包含在本工程编译输出中（未实例化到 C） */")
        else:
            gate(ctx, f"{ident(target)}();", addr, raw)
    elif mn == "EXECUTE":
        fname = ident(args[0])
        extra = [ident(p) for p in ST_PINS.get(args[0], [])] if pins else []
        argv = ([("self" if pins else None)] if pins else []) + extra
        gate(ctx, f"{fname}({', '.join(a for a in argv if a)});", addr, raw)
    elif mn in ("CALL_FB",):
        emit_call_fb(args, ctx, addr, raw)
    elif mn in FBNATIVE:
        gate(ctx, f"{FBNATIVE[mn]}", addr, raw)
    else:
        ctx.todo.append(f"{addr}\t{raw}")
        ctx.lines.append(f"    /* TODO 未翻译: IL:{addr}  {raw} */")


ZRST_FN = "ZRST"
FBNATIVE: dict[str, str] = {}

# 外部耦合指令（运动控制 / 网络 / EtherCAT SDO）→ 交给 library_shims.c 的替身函数
LIB_MN = ["MC_POWER", "MC_HOME", "MC_JOG", "MC_MOVEABSOLUTE", "MC_MOVERELATIVE", "MC_STOP",
          "MC_RESET", "MC_SETPOSITION", "MC_READACTUALPOSITION", "MC_READAXISERROR",
          "MC_READDIGITALINPUT", "TCP_CONNECT", "TCP_SEND", "TCP_RECEIVE",
          "ETC_WRITEPARAMETER_COE"]


def emit_lib_call(mn, args, ctx, pins, enums, addr, raw):
    parts = []
    for a in args:
        if a == "-":
            parts.append("0")
            continue
        cv = const_value(a)
        parts.append(cv if cv is not None else "&" + operand(a, pins, enums))
    ctx.lines.append(f"    /* IL:{addr}  {raw} */")
    ctx.lines.append(f"    {mn}({', '.join(parts)});")


def emit_misc(mn, args, ctx, pins, enums, addr, raw):
    if mn == "INV" and not args:
        # 空 INV：反转当前母线结果（工程里与 MPS/ANB/MPP 配合，出"非"条件的输出）
        ctx.cur = f"!({ctx.cur or '1'})"
        return
    op = lambda i: operand(args[i], pins, enums)

    def _is_sym(name: str) -> bool:
        """该操作数是不是工程里的变量/实例/引脚/局部量（否则按字符串常量处理）。"""
        base = name.split("[")[0].split(".")[0]
        return (base in SYMS or base in INST_FB or base in CUR_LOCALS
                or bool(pins and base in pins) or const_value(name) is not None)

    forms = {
        "INC":  lambda: f"{op(0)} += 1;",
        "INCP": lambda: f"{op(0)} += 1;",
        "DEC":  lambda: f"{op(0)} -= 1;",
        "DECP": lambda: f"{op(0)} -= 1;",
        "ADD":  lambda: f"{op(2)} = {op(0)} + {op(1)};",
        "SUB":  lambda: f"{op(2)} = {op(0)} - {op(1)};",
        "MUL":  lambda: f"{op(2)} = {op(0)} * {op(1)};",
        "DIV":  lambda: f"{op(2)} = DIV16({op(0)}, {op(1)});",
        "MOD":  lambda: f"{op(2)} = MOD16({op(0)}, {op(1)});",
        "DADD": lambda: f"{op(2)} = {op(0)} + {op(1)};",
        "DSUB": lambda: f"{op(2)} = {op(0)} - {op(1)};",
        "DMUL": lambda: f"{op(2)} = {op(0)} * {op(1)};",
        "DDIV": lambda: f"{op(2)} = DIV32({op(0)}, {op(1)});",
        "DMOD": lambda: f"{op(2)} = MOD32({op(0)}, {op(1)});",
        "EADD": lambda: f"{op(2)} = {op(0)} + {op(1)};",
        "ESUB": lambda: f"{op(2)} = {op(0)} - {op(1)};",
        "EMUL": lambda: f"{op(2)} = {op(0)} * {op(1)};",
        "EDIV": lambda: f"{op(2)} = DIVF({op(0)}, {op(1)});",
        "DEADD": lambda: f"{op(2)} = {op(0)} + {op(1)};",
        "DESUB": lambda: f"{op(2)} = {op(0)} - {op(1)};",
        "DEMUL": lambda: f"{op(2)} = {op(0)} * {op(1)};",
        "DEDIV": lambda: f"{op(2)} = DIVF({op(0)}, {op(1)});",
        "DFLT": lambda: f"{op(1)} = (double)({op(0)});",
        "DFLOOR": lambda: f"{op(1)} = floor({op(0)});",
        "INV": (lambda: f"{op(1)} = ~({op(0)});") if len(args) > 1 else None,
        "LDD": lambda: f"{op(1)} = {op(0)};",
        "BMOV": lambda: (f"FILLB(&{op(1)}, {op(0)}, {op(2)});" if args[0] in BIT_ARRAYS else
                         (f"FILL(&{op(1)}, {op(0)}, {op(2)});" if const_value(args[0]) is not None else
                          f"BLKMOV(&{op(1)}, &{op(0)}, {op(2)});")),
        "DBMOV": lambda: (f"FILL32(&{op(1)}, {op(0)}, {op(2)});" if const_value(args[0]) is not None else
                          f"BLKMOV32(&{op(1)}, &{op(0)}, {op(2)});"),
        "FMOV": lambda: f"FILL(&{op(1)}, {op(0)}, {op(2)});",
        "WSFL": lambda: f"WSHIFT(&{op(1)}, {op(2)}, {op(0)});",
        "STRMOV": lambda: (f"STRCPY(&{op(1)}, &{op(0)});" if _is_sym(args[0])
                           else f'STRCPY(&{op(1)}, "{args[0]}");'),   # 非变量 → 原工程里的字符串常量
        "LEN": lambda: f"{op(1)} = STRLEN(&{op(0)});",
        "WTODW": lambda: f"WTODW(&{op(1)}, &{op(0)}, {op(2)});",
        "BITW": lambda: f"{op(1)} = PACK_BITS(&{op(0)}, {op(2)});",
        "WBIT": lambda: f"UNPACK_BITS(&{op(1)}, {op(0)}, {op(2)});",
        "BITDW": lambda: f"{op(1)} = PACK_BITS32(&{op(0)}, {op(2)});",
        "DWBIT": lambda: f"UNPACK_BITS32(&{op(1)}, {op(0)}, {op(2)});",
        "TRD": lambda: f"RTC_READ(&{op(0)});",
        "TWR": lambda: f"RTC_WRITE(&{op(0)});",
        "PLS": lambda: f"PLS_({op(0)});",
        "TONR": None,
        "TACR": None,
    }
    if mn in ("TONR", "TACR"):
        # TONR / TACR ：PT Q R ET（`-` = 未使用）—— q/et 需要指针，未使用时传 NULL
        def _a(k):
            return "0" if k >= len(args) or args[k] == "-" else operand(args[k], pins, enums)
        pt, q, rst, et = _a(0), _a(1), _a(2), (_a(3) if len(args) > 3 else "0")
        c = ctx.cur if ctx.cur is not None else "1"
        fn = "TON" if mn == "TONR" else "TACC"
        qq = "NULL" if q == "0" else "&" + q
        ee = "NULL" if et == "0" else "&" + et
        ctx.lines.append(f"    /* IL:{addr}  {raw} */")
        ctx.lines.append(f"    {fn}({qq}, {ee}, {pt}, ({c}), ({rst}), dt_ms);")
        return
    f = forms.get(mn)
    if f is None:
        ctx.todo.append(f"{addr}\t{raw}")
        ctx.lines.append(f"    /* TODO 未翻译: IL:{addr}  {raw} */")
        return
    try:
        body = f()
    except Exception as exc:                       # 参数个数/形态异常 → 记录而不是崩溃
        ctx.todo.append(f"{addr}\t{raw}\t({type(exc).__name__})")
        ctx.lines.append(f"    /* TODO 未翻译: IL:{addr}  {raw} */")
        return
    gate(ctx, body, addr, raw)


ST_PINS: dict[str, list[str]] = {}    # ST 块 → 需要透传的 FB 引脚（指针）
LOCAL_ARRAYS: set[str] = set()        # 当前单元里属于数组的 FB 局部量
MISSING_PROGS: set[str] = set()       # 被 CALL 但本体不在编译输出里的子程序
PROG_ALIAS: dict[str, str] = {}        # 调用名 → 实际程序名（大小写差异映射）
FB_LOCAL_ARRAYS: dict[str, set[str]] = {}
CUR_LOCALS: set[str] = set()          # 当前单元里属于 FB 局部量的名字
FB_LOCALS: dict[str, set[str]] = {}   # FB 名 → FB 局部量（实例成员，跨周期保持）
PIN_TYPE_OVERRIDE: dict[str, dict[str, str]] = {}   # 由引脚绑定证据修正的引脚类型
BIT_ARRAYS: set[str] = set()          # 位数组（ZRST/BMOV 需按字节填充）
FB_PINS: dict[str, list[str]] = {}      # FB 名 → 引脚顺序（由驱动在生成前填充）
FB_TYPES: dict[str, dict[str, str]] = {}  # FB 名 → 引脚类型
INST_FB: dict[str, str] = {}              # 实例名 → FB 名
EXTRA_SYMS: dict[str, str] = {}           # 绑定里出现、但变量表没有的符号 → C 类型


def fb_arg(bind: str, pin: str, ty: str, inst: str, ctx: Ctx, i: int) -> str:
    """把一个引脚绑定变成指针实参，语义与 AutoShop 的引脚绑定一致：
       未绑定（`-`）→ 实例自己的成员；字面量 → 借用临时变量；变量 → 取地址。"""
    arr = pin in ARRAY_PINS.get(inst, set())
    if bind in ("-", ""):
        return (f"{ident(inst)}.{ident(pin)}" if arr
                else f"&{ident(inst)}.{ident(pin)}")
    cv = const_value(bind)
    if cv is not None:
        return f"&({ty}){{{cv}}}"       # 复合字面量：块内自动存储，无重名风险
    base = bind.split("[")[0].split(".")[0]
    if base not in SYMS and "." not in bind and base not in INST_FB:
        EXTRA_SYMS.setdefault(base, ty)
    e = operand(bind, None, set())
    if re.fullmatch(r"[^.\[\]]+", bind) and base in ARRAY_SYMS:
        return e
    return "&" + e


def emit_call_fb(args: list[str], ctx: Ctx, addr: str, raw: str) -> None:
    fb, inst = args[0], args[1]
    if fb not in FB_PINS:                # 该 FB 本体不在编译输出里 → 不生成调用
        ctx.lines.append(f"    /* IL:{addr}  {raw} */")
        ctx.lines.append(f"    /* 注：FB「{fb}」本体未包含在本工程编译输出中（未实例化到 C） */")
        return
    pins = FB_PINS.get(fb, [])
    tys = FB_TYPES.get(fb, {})
    binds = args[2:2 + len(pins)]
    call_args = [fb_arg(binds[i] if i < len(binds) else "-", pins[i],
                        tys.get(pins[i], "plc_bit"), inst, ctx, i)
                 for i in range(len(pins))]
    body = (f"/* IL:{addr}  {raw} */\n    {ident(fb)}_call(&{ident(inst)}"
            + (", " + ", ".join(call_args) if call_args else "") + ");")
    gate(ctx, body, None, None, already=True)


# ----------------------------------------------------------------------------- 单元解析

@dataclass
class Unit:
    name: str            # 程序名 / FB 名
    kind: str            # 'prog' | 'fb'
    body: list[tuple[str, str]] = field(default_factory=list)   # (地址, 指令文本)
    pins: list[str] = field(default_factory=list)               # FB 形参顺序（来自 CALL_FB 的 inst.member 列表）


def split_lines(text: str) -> list[tuple[str, str]]:
    out = []
    for ln in text.splitlines():
        if not ln.strip():
            continue
        a, _, t = ln.partition("\t")
        out.append((a.strip(), t.strip()))
    return out


def parse_programs(il_dir: Path) -> list[Unit]:
    units = []
    for f in sorted(il_dir.glob("*.il.txt")):
        if f.name.startswith("35-"):
            continue
        name = f.name.split("-", 1)[1][:-len(".il.txt")]
        units.append(Unit(name, "prog", split_lines(f.read_text(encoding="utf-8"))))
    return units


def parse_fbs(il_dir: Path) -> list[Unit]:
    """从 FB 展开区抽取每个 FB 的第一份本体（各实例本体一致，已核实）"""
    lines = split_lines((il_dir / "35-FB_BODIES.il.txt").read_text(encoding="utf-8"))
    units: dict[str, Unit] = {}
    cur = None
    for addr, text in lines:
        if text.startswith("CALL_FB "):
            parts = text.split()
            fb, inst = parts[1], parts[2]
            pins = [t.split(".", 1)[1] for t in parts[3:] if t.startswith(inst + ".")]
            cur = units.setdefault(fb, Unit(fb, "fb", pins=pins)) if fb not in units else None
            continue
        if text.startswith("FBRET"):
            cur = None
            continue
        if cur is not None:
            cur.body.append((addr, text))
    return list(units.values())


# ----------------------------------------------------------------------------- FB 形参类型推断

BIT_MN = ("LD", "LDI", "LDP", "LDF", "AND", "ANDI", "ANDP", "ANDF", "OR", "ORI", "ORP", "ORF",
          "OUT", "SET", "RST", "PLS", "MEP", "MEF")


def infer_pin_types(unit: Unit) -> dict[str, str]:
    tys: dict[str, str] = {}
    for addr, text in unit.body:
        parts = text.split()
        mn, args = parts[0], parts[1:]
        for i, a in enumerate(args):
            base = a.split("[")[0].split(".")[0]
            if base not in unit.pins:
                continue
            if mn.startswith(("ANDD", "ORD", "LDD", "DADD", "DSUB", "DMOV", "DBMOV", "DDIV")):
                tys[base] = "int32_t"
            elif mn[:1] == "F" or mn.startswith(("DEMOV", "DEADD", "DESUB", "DEDIV", "DFLT", "DFLOOR")):
                tys.setdefault(base, "double")
            elif re.fullmatch(r"(AND|OR|LD)[=<>]{1,2}", mn):
                tys.setdefault(base, "int16_t")
            else:
                tys.setdefault(base, "plc_bit")
    for p in unit.pins:
        tys.setdefault(p, "plc_bit")
    if "Axis" in tys:
        tys["Axis"] = "mca_axis_info_t"          # 轴数据结构（对应 _sMCAXIS_INFO）
    for p, ty in PIN_TYPE_OVERRIDE.get(unit.name, {}).items():
        if p in tys:
            tys[p] = ty                          # 引脚绑定里的字面量（K5000/E0.3）给出的类型证据
    return {p: tys[p] for p in unit.pins}


# ----------------------------------------------------------------------------- 生成 C

def gen_unit_fn(unit: Unit) -> tuple[str, list[str]]:
    global CUR_LOCALS
    pins = set(unit.pins) if unit.kind == "fb" else None
    global LOCAL_ARRAYS
    CUR_LOCALS = FB_LOCALS.get(unit.name, set()) if unit.kind == "fb" else set()
    LOCAL_ARRAYS = FB_LOCAL_ARRAYS.get(unit.name, set()) if unit.kind == "fb" else set()
    ctx = Ctx()
    for addr, text in unit.body:
        parts = text.split()
        if not parts:
            continue
        mn, args = parts[0], parts[1:]
        if mn in ("SRET", "FBRET", "MAINEND", "P", "END"):
            continue
        if mn in ("ANB", "ORB"):
            b = ctx.pending.pop() if ctx.pending else None
            if b is None:
                ctx.lines.append(f"    /* IL:{addr}  {mn}: 无可合并块 */")
                continue
            ctx.cur = f"({b}) && ({ctx.cur or '1'})" if mn == "ANB" else f"({b}) || ({ctx.cur or '1'})"
            continue
        if mn == "MPS":
            ctx.br.append(ctx.cur or "1"); continue
        if mn == "MRD":
            ctx.cur = ctx.br[-1] if ctx.br else ctx.cur; continue
        if mn == "MPP":
            ctx.cur = ctx.br.pop() if ctx.br else ctx.cur; continue
        if mn in ("MEP", "MEF"):
            v = ctx.edgevar("re" if mn == "MEP" else "fe")
            f = "RE" if mn == "MEP" else "FE"
            ctx.cur = f"{f}(&{v}, {ctx.cur or '1'})"
            continue
        if re.fullmatch(r"(F)?(LD|AND|OR)(D)?[=<>]{1,2}", mn) or mn in (
                "LD", "LDI", "LDP", "LDF", "AND", "ANDI", "ANDP", "ANDF", "OR", "ORI", "ORP", "ORF"):
            combine(mn, build_expr(mn, args, ctx, pins, set()), ctx)
            continue
        stmt(mn, args, ctx, pins, set(), addr, text)

    name = ident(unit.name)
    if unit.kind == "fb":
        tys = infer_pin_types(unit)
        sig = ", ".join(f"{tys[p]} *{ident(p)}" for p in unit.pins)
        head = f"void {name}_call({name}_t *self, {sig})" if unit.pins else f"void {name}_call({name}_t *self)"
    else:
        head = f"void {name}(void)"
    decl = [f"    static plc_bit {v} = 0;   /* 边沿: {k} */" for v, k in ctx.edge]
    decl += [f"    static {ty} {v} = 0;" for v, ty, _ in ctx.statics]
    body = "\n".join(decl + ([""] if decl else []) + ctx.lines)
    return f"{head} {{\n{body}\n}}\n", ctx.todo


def emit_symbols_h(syms: dict[str, Sym], used: set[str]) -> str:
    groups: dict[str, list[Sym]] = defaultdict(list)
    for n in sorted(used):
        s = syms.get(n)
        if s is None or "." in n:
            continue
        p = n[0]
        if p in "XY":
            groups["物理 IO（X 输入 / Y 输出）"].append(s)
        elif p in "MW":
            groups["内部位与 EtherNet/IP W 区"].append(s)
        elif p in "DR":
            groups["数据寄存器（D/R）"].append(s)
        elif n.startswith(("HMI_", "h_", "i_")):
            groups["HMI 交互量"].append(s)
        elif n.startswith(("MIAN_", "g_", "gx_", "err_")):
            groups["主控标志与报警"].append(s)
        elif n.startswith(("_IQ", "_")):
            groups["EtherCAT 过程数据与系统区"].append(s)
        else:
            groups["工程变量（机构实例等）"].append(s)
    out = ['#pragma once', '#include "plc.h"', "",
           "/* 自动生成：工程符号 → C 变量。变量名与 AutoShop 工程一致，便于对照梯形图。*/", ""]
    for g, items in groups.items():
        out.append(f"/* ===== {g}（{len(items)} 个）===== */")
        for s in items:
            arr, cmt = s.carray(), f"  /* {s.addr}{('  ' + s.comment) if s.comment else ''} */"
            out.append(f"extern {s.ctype()} {ident(s.name)}[{arr}];{cmt}" if arr != "0"
                       else f"extern {s.ctype()} {ident(s.name)};{cmt}")
        out.append("")
    return "\n".join(out) + "\n"


def emit_symbols_c(syms: dict[str, Sym], used: set[str]) -> str:
    out = ['#include "symbols.h"', ""]
    for n in sorted(used):
        s = syms.get(n)
        if s is None or "." in n:
            continue
        arr = s.carray()
        out.append(f"{s.ctype()} {ident(s.name)}[{arr}];" if arr != "0" else f"{s.ctype()} {ident(s.name)};")
    return "\n".join(out) + "\n"


CALL_ORDER = ["SBR_CT产能", "SBR_压力传感器", "SBR_扫码相机", "SBR_机器人", "SBR_电缸控制",
              "SBR_皮带控制", "SBR_报警", "SBR_气缸映射", "SBR_真空映射", "SBR_轴实例化",
              "SBR_0整机初始化", "SBR_10撕膜工位初始化", "SBR_11机器人1位初始化",
              "SBR_12机器人2位初始化", "SBR_13下料工位初始化", "SBR_01自动撕膜位进料",
              "SBR_02自动撕膜机构", "SBR_01自动机器人1位进料", "SBR_03自动机器人1插接FPC2",
              "SBR_自动机器人1插接FPC2抚平动作", "SBR_01自动机器人2位进料", "SBR_02自动机器人2插接",
              "SBR_01自动CCD进料", "SBR_02自动保压", "SBR_03自动NG下料模组", "SBR_04自动下料皮带4段",
              "SBR_05自动下料皮带1段", "SBR_05自动下料皮带2段", "SBR_05自动下料皮带3段",
              "SBR_06自动ng下料皮带", "SBR_07自动插FL", "SBR_08自动FL抚平", "SBR_09自动FL电缸提前等待",
              "SBR_10自动流道2出料"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--il-dir", default="artifacts/il")
    ap.add_argument("--symbols", default="artifacts/text/VarNameAndAddr.csv.txt")
    ap.add_argument("--out", default="cproject")
    a = ap.parse_args()

    syms = load_symbols(Path(a.symbols))
    progs = parse_programs(Path(a.il_dir))
    fbs = parse_fbs(Path(a.il_dir))

    used: set[str] = set()
    written: dict[str, str] = {}
    todos: list[str] = []
    for u in progs + fbs:
        code, td = gen_unit_fn(u)
        written[u.name] = code
        todos += [f"{u.name}: {t}" for t in td]
        for m in re.finditer(r"[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*", code):
            if m.group(0) in syms:
                used.add(m.group(0))

    out = Path(a.out)
    (out / "include").mkdir(parents=True, exist_ok=True)
    (out / "src").mkdir(parents=True, exist_ok=True)
    (out / "include" / "symbols.h").write_text(emit_symbols_h(syms, used), encoding="utf-8")
    (out / "src" / "symbols.c").write_text(emit_symbols_c(syms, used), encoding="utf-8")
    for name, code in written.items():
        (out / "src" / f"{ident(name)}.c").write_text(
            f'#include "symbols.h"\n#include "fb.h"\n\n{code}', encoding="utf-8")
    print(f"程序 {len(progs)} 个 / FB {len(fbs)} 个 / 用到工程符号 {len(used)} 个")
    print(f"待处理条目 {len(todos)}：")
    for t in todos[:50]:
        print("   ", t)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
