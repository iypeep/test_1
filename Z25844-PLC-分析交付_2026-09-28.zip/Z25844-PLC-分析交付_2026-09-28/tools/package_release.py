#!/usr/bin/env python3
"""package_release.py —— 把「文档 + PLC 工程 + C 工程」打包成**净化后**的 zip。

净化（默认排除）：
  * 版本库与缓存：`.git/`、`__pycache__/`、`.pytest_cache/`
  * 构建产物：`*.exe`、`*.o`、`*.obj`、`*.dmp`、`*.pdb`
  * 本次生成的临时文件：以 `_` 开头的文件/目录（`_build_err.txt`、`_dlptest/`…）
  * 我的中间草稿：`artifacts/dive/_scratch/`
  * 凭据类：文件名含 password/passwd/pwd/login/credential/secret/token/`.key`
  * 厂商软件与手册（本来就不在仓库里，此处再兜底一次）：路径含 `AutoShop/`、`Manual/`、`*.pdf`、`*.chm`

用法：
    python tools/package_release.py --out "E:/Desktop/Z25844-PLC-分析交付_2026-09-28.zip"
"""
from __future__ import annotations

import argparse
import re
import sys
import zipfile
from pathlib import Path

SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", ".idea", "_scratch"}
SKIP_SUFFIX = {".exe", ".o", ".obj", ".dmp", ".pdb", ".pyc", ".pdf", ".chm"}
CRED_PAT = re.compile(r"(?i)(password|passwd|pwd|login|credential|secret|token|\.key$)")
TOP_DIRS = ["analysis", "cproject", "project", "artifacts", "tools"]
TOP_FILES = ["README.md", "NOTICE.md", "交付说明.md"]
# 内容里出现即提示（不阻断）：常见敏感线索
HINT_PAT = re.compile(r"(?i)(password|passwd|192\.168\.|10\.\d+\.\d+\.\d+|sftp|ftp://)")


def keep(rel: Path) -> bool:
    if any(part in SKIP_DIRS for part in rel.parts):
        return False
    if rel.name.startswith("_"):
        return False
    if rel.suffix.lower() in SKIP_SUFFIX:
        return False
    if CRED_PAT.search(rel.name):
        return False
    if "AutoShop" in rel.parts or "Manual" in rel.parts:
        return False
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--out", required=True, help="输出 zip 路径")
    ap.add_argument("--name", default=None, help="zip 内顶层目录名")
    a = ap.parse_args()

    root = Path(a.root).resolve()
    out = Path(a.out)
    top = a.name or out.stem
    if out.exists():
        out.unlink()
    out.parent.mkdir(parents=True, exist_ok=True)

    files, skipped, hints = [], 0, []
    for rel_top in TOP_DIRS:
        base = root / rel_top
        if not base.exists():
            continue
        for p in sorted(base.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(root)
            if not keep(rel):
                skipped += 1
                continue
            files.append(rel)
    for f in TOP_FILES:
        if (root / f).exists():
            files.append(Path(f))
    # 便携工具链说明（不含二进制）
    tc = "cproject/编译说明.txt"

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in files:
            src = root / rel
            data = src.read_bytes()
            try:
                txt = data.decode("utf-8")
                if HINT_PAT.search(txt):
                    hints.append(str(rel))
            except UnicodeDecodeError:
                pass
            z.writestr(f"{top}/{rel.as_posix()}", data)

    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
        n = len(z.namelist())
    head = out.read_bytes()[:4]
    print(f"已生成：{out}")
    print(f"  条目 {n} 个 / 体积 {out.stat().st_size/1e6:.2f} MB / 排除 {skipped} 个文件")
    print(f"  完整性自检 testzip() = {bad or 'OK'}；首字节 = {head!r}（PK\\x03\\x04 表示明文 zip）")
    print(f"  内容含敏感线索的文件 {len(hints)} 个（前 10）：")
    for h in hints[:10]:
        print("    -", h)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
