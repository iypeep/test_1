#!/usr/bin/env python3
"""il2c_project.py —— 由 AutoShop 工程的编译输出重建**完整、可编译、可单步**的 C 工程。

输入（全部来自 artifacts/，可复现）：
    artifacts/il/*.il.txt                       各程序/FB 的 IL 指令表（AutoShop 编译输出 il_log.log 切分而来）
    artifacts/text/VarNameAndAddr.csv.txt       变量表（名称/地址/长度）
    artifacts/st/*.st                           从工程文件里提取出的 ST 块源码
    project/UpLoad/*.enum                       枚举定义
输出：
    cproject/                                   见 cproject/README.md
"""
from __future__ import annotations

import argparse
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import il2c      # noqa: E402
import st2c      # noqa: E402

CALL_ORDER = il2c.CALL_ORDER
LIB_MN = il2c.LIB_MN

LIB_DOC = {
    "MC_POWER": "轴使能（PLCopen MC_Power）", "MC_HOME": "原点回归", "MC_JOG": "点动",
    "MC_MOVEABSOLUTE": "绝对定位", "MC_MOVERELATIVE": "相对定位", "MC_STOP": "停止",
    "MC_RESET": "轴报警复位", "MC_SETPOSITION": "设置当前位置", "MC_READACTUALPOSITION": "读实际位置",
    "MC_READAXISERROR": "读轴故障码", "MC_READDIGITALINPUT": "读轴数字输入",
    "TCP_CONNECT": "建立 TCP 连接（扫码枪自由口）", "TCP_SEND": "TCP 发送", "TCP_RECEIVE": "TCP 接收",
    "ETC_WRITEPARAMETER_COE": "EtherCAT CoE 写参数（SDO）",
}

# 依使用方式推断符号类型：助记符 → C 类型
H_BIT = {"OUT", "SET", "RST", "LD", "LDI", "LDP", "LDF", "AND", "ANDI", "ANDP", "ANDF",
         "OR", "ORI", "ORP", "ORF", "MEP", "MEF", "PLS", "PLF", "INV"}
H_W16 = {"MOV", "ADD", "SUB", "MUL", "DIV", "INC", "DEC", "CMP", "WAND", "WOR", "WXOR", "ROL", "ROR"}
H_W32 = {"DMOV", "DADD", "DSUB", "DMUL", "DDIV", "DINC", "DDEC", "DCMP", "DBMOV", "DWAND", "DWOR"}
H_F64 = {"DEMOV", "DEADD", "DESUB", "DEMUL", "DEDIV", "DFLT", "DFLOOR", "DPOW", "DECMP", "FLT"}


# --------------------------------------------------------------------------- 枚举
def parse_enums(d: Path) -> dict[str, int]:
    """解析 AutoShop 枚举文件（`.enum`）。

    文件是二进制容器，枚举项以「名称+十进制值」的文本串出现（如 `下料Y轴0`、`上相机X轴10`）。
    代码里用的就是**带值的完整名**，因此完整名与「去尾数字」的别名都给出。
    """
    out: dict[str, int] = {}
    for f in sorted(d.glob("*.enum")):
        b = f.read_bytes()
        k = b.find(b"CLVTItem")
        seg = b[max(k, 0):].decode("utf-8", "ignore")
        for run in re.findall(r"[\w\u4e00-\u9fff]{2,}", seg):
            if run == "CLVTItem" or run.isdigit():
                continue
            m = re.fullmatch(r"(.+?)(\d+)", run)
            if not m or not re.search(r"[^\d]", m.group(1)):
                continue
            # 只取**完整名**（如 下料Y轴0）：去尾数字的别名会与 FB 实例/变量同名，造成宏替换冲突
            out.setdefault(run, int(m.group(2)))
    return out


# --------------------------------------------------------------------------- 实例/用法
def collect_instances(il_dir: Path) -> dict[str, str]:
    """全工程 CALL_FB <FB> <实例> → {实例: FB}。"""
    inst: dict[str, str] = {}
    for f in il_dir.glob("*.il.txt"):
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            p = line.split()
            if len(p) > 2 and p[1] == "CALL_FB" and not p[2].startswith("-"):
                inst[p[3]] = p[2]
    return inst


def collect_usage(units) -> tuple[dict[str, set[str]], set[str], dict[str, int]]:
    hints: dict[str, set[str]] = defaultdict(set)
    indexed: set[str] = set()
    maxidx: dict[str, int] = {}
    for u in units:
        for _addr, text in u.body:
            p = text.split()
            if not p:
                continue
            mn, args = p[0].upper(), p[1:]
            for a in args:
                m = re.fullmatch(r"([^.\[\]]+)\[(\d+)\]", a)
                if m:
                    indexed.add(m.group(1))
                    maxidx[m.group(1)] = max(maxidx.get(m.group(1), 0), int(m.group(2)) + 1)
                elif re.fullmatch(r"([^.\[\]]+)\[.+\]", a):
                    indexed.add(re.fullmatch(r"([^.\[\]]+)\[.+\]", a).group(1))
                base = a.split("[")[0].split(".")[0]
                if not base:
                    continue
                if mn in H_BIT:
                    hints[base].add("plc_bit")
                elif mn in H_W32:
                    hints[base].add("int32_t")
                elif mn in H_F64:
                    hints[base].add("double")
                elif mn in H_W16 or re.fullmatch(r"(F)?(LD|AND|OR)(D)?[=<>]{1,2}", mn):
                    hints[base].add("int32_t" if mn.startswith("D") else "int16_t")
    return hints, indexed, maxidx


def infer_types(syms: dict[str, il2c.Sym], hints: dict[str, set[str]],
                indexed: set[str], used: set[str],
                maxidx: dict[str, int] | None = None) -> dict[str, tuple[str, int]]:
    """→ {名称: (C 类型, 数组长度)}。依据：变量表长度（字节）+ 代码里的使用方式。"""
    out: dict[str, tuple[str, int]] = {}
    for n in sorted(used):
        s = syms.get(n)
        if s is None or "." in n:
            continue
        h = hints.get(n, set())
        if "double" in h:
            ty = "double"
        elif "int32_t" in h:
            ty = "int32_t"
        elif h == {"plc_bit"}:
            ty = "plc_bit"
        elif "int16_t" in h:
            ty = "int16_t"
        elif n in indexed and s.bits <= 128:
            ty = "plc_bit"                      # 位数组：本机 1 字节/位（地址差已验证）
        elif n in indexed:
            ty = "int16_t"
        else:                                   # 无使用线索 → 按变量表字节数
            ty = "plc_bit" if s.bits <= 1 else ("int16_t" if s.bits <= 2 else "int32_t")
        size = {"plc_bit": 1, "int16_t": 2, "int32_t": 4, "double": 4}[ty]
        cnt = max(1, s.bits // size, (maxidx or {}).get(n, 0)) if n in indexed else 1
        out[n] = (ty, cnt)
    return out


IL_KW = {"LD", "LDI", "LDP", "LDF", "AND", "ANDI", "ANDP", "ANDF", "OR", "ORI", "ORP", "ORF",
         "OUT", "SET", "RST", "MPS", "MRD", "MPP", "ANB", "ORB", "INV", "MEP", "MEF",
         "MOV", "DMOV", "BMOV", "FMOV", "CALL", "CALL_FB", "SRET", "FBRET", "P", "END",
         "TONR", "TACR", "ZRST", "BITW", "WBIT", "BITDW", "DWBIT", "TRD", "TWR", "PLS", "PLF",
         "ADD", "SUB", "MUL", "DIV", "MOD", "DADD", "DSUB", "DMUL", "DDIV", "DMOD",
         "EADD", "ESUB", "EMUL", "EDIV", "DEADD", "DESUB", "DEMUL", "DEDIV", "DFLT", "DFLOOR",
         "INC", "DEC", "INCP", "DECP", "LDD", "STRMOV", "LEN", "WTODW", "EXECUTE", "RTC"}


def hint_of(mn: str) -> str | None:
    mn = mn.upper()
    if mn in H_BIT:
        return "plc_bit"
    if mn in H_W32:
        return "int32_t"
    if mn in H_F64 or (mn.startswith("F") and len(mn) > 1 and mn[1] in "LAO"):
        return "double"
    if mn in H_W16 or re.fullmatch(r"(F)?(LD|AND|OR)(D)?[=<>]{1,2}", mn):
        return "int32_t" if mn.startswith("D") else "int16_t"
    return None


def derive_fb_members(fbs, syms, instances, enums):
    """FB 局部量：既不是引脚、也不是全局变量/实例/枚举的名字 —— 它们在 PLC 里存放在 FB 私有内存，
    因此建模为**实例结构的成员**（每实例独立、跨扫描周期保持）。"""
    out: dict[str, dict[str, tuple[str, int]]] = {}
    for u in fbs:
        pins, loc, hints, idx = set(u.pins), {}, {}, {}
        for _addr, text in u.body:
            p = text.split()
            if not p:
                continue
            mn = p[0]
            for a in p[1:]:
                base = a.split("[")[0].split(".")[0]
                if (not base or base in pins or base in syms or base in instances
                        or base in enums or base in IL_KW or "." in a.split("[")[0]):
                    continue
                if not re.fullmatch(r"[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*", base):
                    continue
                if re.fullmatch(r"(K\d+|H[0-9A-Fa-f]+|B[01]+|E-?\d+(\.\d+)?)", base):
                    continue
                if DEV_RE.fullmatch(base):          # 设备地址由 extra_symbols 统一声明
                    continue
                if "[" in a:                       # 被下标访问 ⇒ 必须是数组（至少 2 个元素）
                    m = re.search(r"\[(\d+)\]", a)
                    idx[base] = max(idx.get(base, 2), int(m.group(1)) + 1 if m else 32)
                hints.setdefault(base, set()).add(hint_of(mn) or "plc_bit")
        for b in hints:
            hs = hints[b]
            ty = ("double" if "double" in hs else "int32_t" if "int32_t" in hs
                  else "plc_bit" if hs == {"plc_bit"} else "int16_t")
            loc[b] = (ty, idx.get(b, 1))
        out[u.name] = loc
    return out


SKIP_MN = {"CALL", "CALL_FB", "EXECUTE", "SRET", "FBRET", "P", "END"}
PROGNAMES: set[str] = set()
FBNAMES: set[str] = set()


def derive_prog_locals(units, syms, instances, enums, members) -> dict[str, dict[str, tuple[str, int]]]:
    """程序里既不是全局变量、也不是 FB 实例/枚举的名字 —— 在本机是程序私有临时量，
    译成该程序的 file-static（不跨程序共享）。"""
    out: dict[str, dict[str, tuple[str, int]]] = {}
    for u in units:
        loc: dict[str, tuple[str, int]] = {}
        for _ad, text in u.body:
            p = text.split()
            if not p or p[0] in SKIP_MN:
                continue
            skip_first = p[0].upper() in ("STRMOV", "LEN")   # 这两个指令的首操作数可能是字符串常量
            for ai, a in enumerate(p[1:]):
                if skip_first and ai == 0:
                    continue
                base = a.split("[")[0].split(".")[0]
                if (not base or base in syms or base in instances or base in enums
                        or base in IL_KW or base in FBNAMES or base in PROGNAMES
                        or base in il2c.EXTRA_SYMS or base in il2c.BIT_ARRAYS
                        or "." in a.split("[")[0]):
                    continue
                if not re.fullmatch(r"[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*", base):
                    continue
                if re.fullmatch(r"(K\d+|H[0-9A-Fa-f]+|B[01]+|E-?\d+(\.\d+)?)", base):
                    continue
                if DEV_RE.fullmatch(base):          # 设备地址（D100/M23/W10…）由 extra_symbols 声明
                    continue
                ty = "double" if base.lower().startswith(("vf_", "of_")) else (
                    hint_of(p[0]) or "plc_bit")
                if ty not in ("double", "int32_t", "int16_t", "plc_bit"):
                    ty = "plc_bit"
                m = re.fullmatch(r"[^.\[\]]+\[(\d+)\]", a)
                cnt = int(m.group(1)) + 1 if m else 1
                old = loc.get(base)
                if old:
                    cnt = max(cnt, old[1])
                loc[base] = (ty, cnt)
        if loc:
            out[u.name] = loc
    return out


# --------------------------------------------------------------------------- 代码生成
def emit_symbols_h(syms, types, groups) -> str:
    out = ['#pragma once', '#include "plc.h"', "",
           "/* 自动生成：工程符号 → C 变量（名称与 AutoShop 工程一致，便于逐行对照梯形图）。",
           "   类型由**变量表字节数 + 代码里的使用方式**推断，见 cproject/README.md「类型推断」。*/", ""]
    by: dict[str, list[tuple[str, tuple[str, int]]]] = defaultdict(list)
    for n, t in types.items():
        by[groups.get(n, "其它工程变量")].append((n, t))
    for g in sorted(by):
        out.append(f"/* ========== {g}（{len(by[g])} 个） ========== */")
        for n, (ty, cnt) in sorted(by[g]):
            s = syms.get(n)
            c = f"  /* {s.addr if s else ''}{('  ' + s.comment) if s and s.comment else ''} */"
            out.append(f"extern {ty} {il2c.ident(n)}[{cnt}];{c}" if cnt > 1
                       else f"extern {ty} {il2c.ident(n)};{c}")
        out.append("")
    return "\n".join(out) + "\n"


def emit_symbols_c(types) -> str:
    out = ['#include "symbols.h"', ""]
    for n, (ty, cnt) in sorted(types.items()):
        out.append(f"{ty} {il2c.ident(n)}[{cnt}];" if cnt > 1 else f"{ty} {il2c.ident(n)};")
    return "\n".join(out) + "\n"


def group_of(n: str) -> str:
    if n[0] in "XY":
        return "物理 IO（X 输入 / Y 输出）"
    if n[0] in "MW":
        return "内部位与 EtherNet/IP W 区"
    if n[0] in "DR":
        return "数据寄存器（D/R）"
    if n.startswith(("HMI_", "HMI", "hmi", "h_", "i_")):
        return "HMI 交互量（上位机/触摸屏读写）"
    if n.startswith(("MIAN_", "g_", "gx_", "g_", "err_", "Gi_")):
        return "主控标志与报警"
    if n.startswith("_"):
        return "EtherCAT 过程数据与系统区"
    return "机构数据与其它工程变量"


def emit_enums_h(enums) -> str:
    lines = ['#pragma once', "", "/* 自动生成：工程枚举（project/UpLoad/*.enum）。*/", ""]
    for k, v in sorted(enums.items(), key=lambda kv: kv[0]):
        lines.append(f"#define {il2c.ident(k)} {v}   /* {k} */")
    return "\n".join(lines) + "\n"


def emit_fb_h(fbs, members, arrays, extra=None) -> str:
    structs, protos = [], []
    for u in fbs:
        n = il2c.ident(u.name)
        tys = il2c.infer_pin_types(u)
        fields = []
        for p in u.pins:
            ty = "mca_axis_info_t" if p == "Axis" else tys[p]
            if p in arrays.get(u.name, set()):
                sz = arrays.get((u.name, p), 32)
                fields.append(f"    {ty} {il2c.ident(p)}[{sz}];")
            else:
                fields.append(f"    {ty} {il2c.ident(p)};")
        for b, (ty, cnt) in sorted(members.get(u.name, {}).items()):
            fields.append(f"    {ty} {il2c.ident(b)}[{cnt}];" if cnt > 1
                          else f"    {ty} {il2c.ident(b)};")
        for b, ty in sorted((extra or {}).get(u.name, {}).items()):      # 结构体成员（如 FTC 子实例）
            fields.append(f"    {ty} {il2c.ident(b)};")
        structs.append(f"typedef struct {{\n" + "\n".join(fields) + f"\n}} {n}_t;   /* 原 FB: {u.name} */")
        sig = ", ".join(f"{('mca_axis_info_t' if p == 'Axis' else tys[p])} *{il2c.ident(p)}"
                        for p in u.pins)
        protos.append(f"void {n}_call({n}_t *self" + (f", {sig}" if sig else "") + ");")
    return ('#pragma once\n#include "symbols.h"\n#include "enums.h"\n#include "structs.h"\n\n'
            "/* 功能块（FB）：结构体 = 实例数据；引脚以**指针形参**传入，\n"
            "   语义与 AutoShop 的引脚绑定一致 —— 绑定了外部变量就指向外部变量，\n"
            "   未绑定（`-`）则指向实例自身的成员存储。 */\n\n"
            + "\n\n".join(structs) + "\n\n" + "\n".join(protos) + "\n")


def emit_instances(instances, fbnames) -> tuple[str, str]:
    by_fb = defaultdict(list)
    for inst, fb in instances.items():
        by_fb[fb].append(inst)
    decl = ['#pragma once', '#include "fb.h"', "", "/* 自动生成：FB 实例（来自各程序里的 CALL_FB）。*/", ""]
    defn = ['#include "symbols.h"', '#include "fb.h"', "", "#include \"fb_instances.h\"", ""]
    for fb, insts in sorted(by_fb.items()):
        if fb not in fbnames:
            continue
        decl.append(f"/* ==== {fb}：{len(insts)} 个 ==== */")
        for i in sorted(insts):
            decl.append(f"extern {il2c.ident(fb)}_t {il2c.ident(i)};")
            defn.append(f"{il2c.ident(fb)}_t {il2c.ident(i)};")
    return "\n".join(decl) + "\n", "\n".join(defn) + "\n"


PLH = r'''#pragma once
/* =========================================================================
 * plc.h —— PLC 语义层
 * 本 C 工程由 tools/il2c.py + il2c_project.py 从 AutoShop 工程的编译输出 IL 重建。
 * 目标：按扫描周期语义还原工程逻辑，使代码可读、可跳转、可单步调试。
 * 边界：EtherCAT/机器人/视觉/运动控制等外部耦合部分以库替身呈现（library_shims.c）。
 * ========================================================================= */
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

typedef uint8_t plc_bit;      /* 位软元件：X / Y / M / S / T / C … */
typedef int16_t plc_word;     /* 16 位字：D / W 区 */
typedef int32_t plc_dword;    /* 32 位双字 */

extern int32_t dt_ms;         /* 扫描周期(ms)，默认 1（与工程 TONR 时间基准一致） */

/* 边沿检测：每个调用点保存一份状态（等价于 PLC 的边沿触点） */
static inline plc_bit RE(plc_bit *state, plc_bit x) { plc_bit r = (plc_bit)(x && !*state); *state = x; return r; }
static inline plc_bit FE(plc_bit *state, plc_bit x) { plc_bit r = (plc_bit)(!x && *state); *state = x; return r; }

/* 定时器：PT 单位 ms（工程实测 K500 = 500ms）
 *   TON  = TONR：条件断开即复位（消抖/超时）
 *   TACC = TACR：条件断开保持累计（运行时间累计） */
void TON(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt);
void TACC(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt);

/* 数据/数组操作（MOV/BMOV/FMOV/WSFL/BITW/WBIT…） */
void BLKMOV(void *dst, void *src, int n);
void BLKMOV32(void *dst, void *src, int n);
void FILL(void *dst, int32_t v, int n);
void WSHIFT(void *dst, int n, int32_t v);
void STRCPY(void *dst, const char *src);
int  STRLEN(const void *src);
void WTODW(void *dw, void *w, int n);
int32_t PACK_BITS(void *bitbase, int n);
void UNPACK_BITS(void *bitbase, int32_t v, int n);
int32_t PACK_BITS32(void *bitbase, int n);
void UNPACK_BITS32(void *bitbase, int32_t v, int n);
void RTC_READ(void *dst);
void RTC_WRITE(void *src);
void PLS_(plc_bit *y);
void FILLB(void *dst, int v, int n);            /* 位数组填充 */
/* 除法：PLC 在除数为 0 时会报运算错误停机；C 侧为能连续单步，除零返回 0（见 cproject/README 偏差表） */
int16_t DIV16(int32_t a, int32_t b);
int32_t DIV32(int32_t a, int32_t b);
double  DIVF(double a, double b);
int16_t MOD16(int32_t a, int32_t b);
int32_t MOD32(int32_t a, int32_t b);
void FILL32(void *dst, int32_t v, int n);       /* 32 位数组填充 */

/* 字软元件的按位访问（AutoShop 里写作 D0.3 / etc控制字.9） */
#define BIT_R(w, n)      ((((int32_t)(w)) >> (n)) & 1)
#define BIT_SET(w, n)    ((w) = (plc_word)((w) | (1 << (n))))
#define BIT_CLR(w, n)    ((w) = (plc_word)((w) & ~(1 << (n))))
#define BIT_W(w, n, v)   ((v) ? BIT_SET(w, n) : BIT_CLR(w, n))

/* 外部耦合指令（library_shims.c 提供替身；真实执行在伺服/协议栈侧） */
void MC_POWER(void *a0, ...);
void MC_HOME(void *a0, ...);
void MC_JOG(void *a0, ...);
void MC_MOVEABSOLUTE(void *a0, ...);
void MC_MOVERELATIVE(void *a0, ...);
void MC_STOP(void *a0, ...);
void MC_RESET(void *a0, ...);
void MC_SETPOSITION(void *a0, ...);
void MC_READACTUALPOSITION(void *a0, ...);
void MC_READAXISERROR(void *a0, ...);
void MC_READDIGITALINPUT(void *a0, ...);
void TCP_CONNECT(void *a0, ...);
void TCP_SEND(void *a0, ...);
void TCP_RECEIVE(void *a0, ...);
void ETC_WRITEPARAMETER_COE(void *a0, ...);

/* 轴数据结构（原 Axis_FB 的 Axis 引脚，对应 CiA402 对象） */
typedef struct {
    double fActPosition;      /* 当前位置 0x6064 */
    double fSetPosition;      /* 目标位置 0x607A */
    plc_word wPLCOpenState;   /* PLCopen 状态字 */
} mca_axis_info_t;
'''

HELPERS = r'''#include "plc.h"

int32_t dt_ms = 1;

void TON(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt) {
    if (rst) { if (et) *et = 0; if (q) *q = 0; return; }
    if (cond) {
        if (et) { if (*et < pt) *et += dt; if (*et >= pt && q) *q = 1; }
        else if (q && pt <= 0) *q = 1;
    } else { if (et) *et = 0; if (q) *q = 0; }
}

void TACC(plc_bit *q, int32_t *et, int32_t pt, plc_bit cond, plc_bit rst, int32_t dt) {
    if (rst) { if (et) *et = 0; if (q) *q = 0; return; }
    if (cond && et) { if (*et < pt) *et += dt; if (*et >= pt && q) *q = 1; }
}

void BLKMOV(void *dst, void *src, int n) { memmove(dst, src, (size_t)n * sizeof(plc_word)); }
void BLKMOV32(void *dst, void *src, int n) { memmove(dst, src, (size_t)n * sizeof(plc_dword)); }
void FILL(void *dst, int32_t v, int n) { for (int i = 0; i < n; i++) ((plc_word *)dst)[i] = (plc_word)v; }
void FILLB(void *dst, int v, int n) { memset(dst, v, (size_t)n); }
int16_t DIV16(int32_t a, int32_t b) { return b ? (int16_t)(a / b) : 0; }
int32_t DIV32(int32_t a, int32_t b) { return b ? (a / b) : 0; }
double  DIVF(double a, double b) { return (b != 0.0) ? (a / b) : 0.0; }
int16_t MOD16(int32_t a, int32_t b) { return b ? (int16_t)(a % b) : 0; }
int32_t MOD32(int32_t a, int32_t b) { return b ? (a % b) : 0; }
void FILL32(void *dst, int32_t v, int n) { for (int i = 0; i < n; i++) ((plc_dword *)dst)[i] = v; }
void WSHIFT(void *dst, int n, int32_t v) {
    plc_word *p = (plc_word *)dst;
    for (int i = 0; i < n - 1; i++) p[i] = p[i + 1];
    if (n > 0) p[n - 1] = (plc_word)v;
}
void STRCPY(void *dst, const char *src) { strcpy((char *)dst, src); }
int  STRLEN(const void *src) { return (int)strlen((const char *)src); }
void WTODW(void *dw, void *w, int n) { for (int i = 0; i < n; i++) ((plc_dword *)dw)[i] = (plc_dword)((plc_word *)w)[i]; }
int32_t PACK_BITS(void *bitbase, int n) {
    int32_t v = 0; plc_bit *b = (plc_bit *)bitbase;
    for (int i = 0; i < n; i++) if (b[i]) v |= (1 << i);
    return v;
}
void UNPACK_BITS(void *bitbase, int32_t v, int n) {
    plc_bit *b = (plc_bit *)bitbase;
    for (int i = 0; i < n; i++) b[i] = (plc_bit)((v >> i) & 1);
}
int32_t PACK_BITS32(void *bitbase, int n) { return PACK_BITS(bitbase, n); }
void UNPACK_BITS32(void *bitbase, int32_t v, int n) { UNPACK_BITS(bitbase, v, n); }
void RTC_READ(void *dst) { (void)dst; }
void RTC_WRITE(void *src) { (void)src; }
void PLS_(plc_bit *y) { if (y) *y = 1; }
'''

MAIN_C = '''#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"

/* ============================================================================
 * plc_scan() —— 一个 PLC 扫描周期
 * 对应原工程 MAIN.LD 的调用网络（IL 0278–0312）：34 个子程序每周期无条件调用，
 * 顺序固定；每个子程序内部再用 HMI_自动中[n] / HMI_工位屏蔽[n] / HMI_自动流程[n]
 * 决定本周期动作。
 * ========================================================================== */
{protos}

void plc_scan(void) {{
{calls}
}}

/* 上电初始化：M8002 只在首次扫描为 1（对应原工程的初始化网络） */
void plc_init(void) {{
    M8000 = 1;
    M8002 = 1;
    plc_scan();
    M8002 = 0;
}}
'''

SHARED_H = '''#pragma once
#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"
#include "enums.h"
#include "extra_symbols.h"
#include "st_blocks.h"

/* ============================================================================
 * 仿真侧接口（sim/ 目录）：PLC 本身不包含这些，它们只是让 C 工程能跑起来的"机械替身"。
 * ========================================================================== */
void plc_scan(void);
void plc_init(void);

/* 机械/负载仿真：把 Y 输出反馈成 X 感应，把运动指令积分成位置 */
void sim_machine_step(int32_t dt_ms);
void sim_axis_step(int32_t dt_ms);
void sim_print_state(void);
'''

SIM_MAIN_C = '''#include "sim.h"
#include <stdio.h>
#include <stdlib.h>

/* 扫描循环：dt_ms 默认 1ms（与 AutoShop 工程的 TONR 时间基准一致）。 */
int main(int argc, char **argv) {
    long cycles = (argc > 1) ? atol(argv[1]) : 2000;
    dt_ms = (argc > 2) ? atoi(argv[2]) : 1;
    plc_init();
    for (long i = 0; i < cycles; i++) {
        M8011 = (plc_bit)((i % 10) < 5);      /* 10ms 时钟 */
        M8013 = (plc_bit)((i % 1000) < 500);  /* 1s 时钟 */
        sim_scenario(i, NULL);            /* 演示场景：推到"手动/自动"，观察工位状态字推进 */
        plc_scan();
        sim_machine_step(dt_ms);
        sim_axis_step(dt_ms);
    }
    sim_print_state();
    return 0;
}
'''

SIM_H = '''#pragma once
#include "symbols.h"
#include "fb.h"
#include "fb_instances.h"

extern int32_t dt_ms;

void plc_scan(void);
void plc_init(void);
void sim_machine_step(int32_t dt);
void sim_axis_step(int32_t dt);
void sim_print_state(void);
void sim_scenario(int cycle, void *ctx);
'''

MAKEFILE = '''CC      ?= gcc
CFLAGS  := -std=gnu11 -O0 -g -w \\
           -Wno-error=incompatible-pointer-types -Wno-error=int-conversion \\
           -Wno-error=implicit-function-declaration -Wno-error=implicit-int \\
           -Iinclude -Isim
SRC     := $(wildcard src/*.c)
SIM     := $(wildcard sim/*.c)

all: plc_sim
plc_sim: $(SRC) $(SIM)
\t$(CC) $(CFLAGS) -o $@ $^ -lm
run: plc_sim
\t./plc_sim 5000
clean:
\trm -f plc_sim plc_sim.exe
'''


def emit_main(progs) -> str:
    names = [il2c.ident(u.name) for u in progs if u.name in CALL_ORDER]
    return MAIN_C.format(protos="\n".join(f"void {n}(void);" for n in names),
                         calls="\n".join(f"    {n}();" for n in names))


def emit_shims(call_log) -> str:
    out = ['#include "symbols.h"', "",
           "/* ==========================================================================",
           " * library_shims.c —— 外部耦合指令的替身",
           " *",
           " * 真实 PLC 里这些指令由硬件/协议栈/内置运动引擎完成，纯 C 无法复现：",
           " *   MC_*                    内置运动控制（PLCopen），实际执行在 EtherCAT 伺服/电缸",
           " *   TCP_*                   自由口 socket（扫码枪）",
           " *   ETC_WRITEPARAMETER_COE  EtherCAT CoE 写参数（SDO）",
           " *",
           " * 这里保留调用形态与工程实际实参（便于顺着调用链读），",
           " * 并在 MC_* 上做**最小可运行等效**：维护轴的使能/目标位置，其余交 sim/ 积分。",
           " * ========================================================================== */", ""]
    for mn in LIB_MN:
        out.append(f"/* {LIB_DOC.get(mn, mn)} */")
        for raw in call_log.get(mn, [])[:2]:
            out.append(f"/*   本工程调用： {raw} */")
        if mn.startswith("MC_"):
            out.append(f"void {mn}(void *a0, ...) {{ (void)a0; }}   /* 轴状态由 sim_axis_step() 推进 */")
        else:
            out.append(f"void {mn}(void *a0, ...) {{ (void)a0; }}")
        out.append("")
    return "\n".join(out) + "\n"


README = '''# cproject —— 由 AutoShop 工程重建的 C 工程（可编译、可单步）

> **自动生成，请勿手改**：由 `tools/il2c.py` + `tools/il2c_project.py` + `tools/st2c.py`
> 依据 `artifacts/`（AutoShop 编译输出 IL、变量表、提取出的 ST 源码）生成。
> 统计：程序 {progs} 个、功能块 {fbs} 个、FB 实例 {insts} 个、变量 {syms} 个、ST 块 {stblocks} 个、未翻译条目 {todos} 条。

## 1. 它解决什么问题

梯形图和 IL 都不便于"跨功能跳转阅读"。这里把**每个子程序/FB 变成 C 函数**、
**每个工程变量变成 C 变量**，于是 VS Code 里可以：

| 操作 | 用途 |
|---|---|
| `F12` / `Shift+F12` | 跳转到定义 / 查所有引用 —— **读"谁改了这个变量"最快的方式** |
| `Ctrl+Shift+O` | 文件大纲（一个程序 = 一个函数） |
| `Ctrl+Shift+F` | 全工程搜索变量名（如 `g_x撕膜位OK料`） |
| 断点 + 单步 | `make && ./plc_sim` 后逐周期观察逻辑 |

## 2. 目录

```
cproject/
├─ include/
│   ├─ plc.h          语义层：类型、边沿 RE/FE、定时器 TON/TACC、位打包、轴结构
│   ├─ symbols.h      工程变量 → C 变量（含原地址注释）
│   ├─ enums.h        工程枚举（project/UpLoad/*.enum）
│   ├─ fb.h           FB 结构体 + 调用原型（引脚 = 指针形参）
│   └─ fb_instances.h 64 个 FB 实例（36 个气缸、10 条皮带、5 台电缸、设备状态机…）
├─ src/
│   ├─ plc_scan.c     plc_scan()/plc_init()：按 MAIN 的调用顺序执行子程序（文件名避开 MAIN.c）
│   ├─ <程序名>.c      每个 LD 子程序一个函数
│   ├─ <FB名>.c       每个功能块一个函数（实例共用一份体）
│   ├─ st_blocks.c    ST 块（_STB101/_STB102/_STB87）逐行译成 C，保留 ST 原文注释
│   ├─ fb_instances.c / symbols.c / plc_helpers.c / library_shims.c
├─ sim/              仿真侧（非 PLC 逻辑）：扫描循环 + 机械/轴替身
└─ Makefile
```

## 3. 编译运行

```bash
# 便携工具链（本机已就绪）：
#   C:\\Users\\<你>\\AppData\\Local\\Temp\\toolchain\\w64devkit\\bin\\gcc.exe
cd cproject
mingw32-make            # 或 make
./plc_sim 5000          # 5000 个扫描周期，默认 1ms/周期
```

## 4. 阅读约定（与 AutoShop 对照）

| 生成代码 | 原工程 |
|---|---|
| `void SBR_02自动撕膜机构(void)` | 子程序 `SBR_02自动撕膜机构.LD` |
| `气缸_FB_t 撕膜位阻挡气缸;` + `气缸_FB_call(&…, …)` | FB 实例（图纸化引脚绑定） |
| 指针形参 `plc_bit *原位感应` | FB 引脚：绑定了外部变量就指向外部变量，`-` 则指向实例成员 |
| `if (条件) { … }` | 一个网络（rung） |
| `/* IL:6403 CALL_FB … */` | 网络对应的 IL 原文（可在 `artifacts/il/` 定位） |
| `RE(e1,x)` / `FE(e1,x)` | 上升沿/下降沿触点（`LDP/ANDP`、`LDF/ANDF`、`MEP/MEF`） |
| `TON(&q,&et,K800,cond,0,dt_ms)` / `TACC` | `TONR`（消抖/超时）/ `TACR`（累计） |
| `PACK_BITS/UNPACK_BITS`、`BLKMOV/FILL/WSHIFT` | `BITW/WBIT`、`BMOV/FMOV/WSFL` |
| `MC_*` `TCP_*` `ETC_*` | 外部耦合指令 → `library_shims.c` |

## 5. 类型推断（重要）

变量类型由**两处证据**推断，代码里全部可追溯：

1. `artifacts/text/VarNameAndAddr.csv.txt` 的**字节长度**（已用相邻变量地址差验证：
   如 `HMI_轴1定位位置`=800B，下一变量地址差正好 0x320）；
2. 该符号在 IL 里的**使用方式**（`OUT/SET/…` → 位；`MOV/ADD` → 16 位；`DMOV/DADD` → 32 位；`DEMOV/FLT` → 浮点）。
   - 位软元件在该 PLC 的地址空间里**占 1 字节/位**（`g_x轴不在暂停位` 长度=1B 可证）。

因此 `symbols.h` 里的类型是"可编译 + 可读"的近似；**若要与原工程逐位一致，以 `artifacts/text/VarNameAndAddr.csv.txt` 为准**。

## 6. 保真度

| 部分 | 保真度 |
|---|---|
| 位逻辑、边沿、定时器、比较、数据运算、数组、位打包 | **逐指令还原**（可编译执行） |
| 功能块（含引脚绑定、实例存储） | **逐指令还原**，引脚按绑定语义以指针传递 |
| ST 块 `_STB101/_STB102/_STB87` | **译自工程内嵌的真实 ST 源码**（`artifacts/st/`），逐行附原文注释 |
| `MC_*`（运动控制） | 调用形态保留 + 最小可运行等效；轴运动由 `sim/` 积分 |
| `TCP_*`、`ETC_WRITEPARAMETER_COE` | 仅保留调用形态（协议栈不还原） |
| 未实例化的 6 个 FB（`FB_PID`/`FB_静置料仓`…）及其 ST（`_STB76/77/85/93/127/128`） | 未生成 C，但 **ST 源码已存 `artifacts/st/`** |

## 7. 已知偏差

- 定时器/边沿的静态状态按**调用点**保存，与原 PLC 一致；但 FB 内部的"局部变量"在本工程里译成
  `static`（跨实例共享）——已核对：仅 `FB_扫码检测旧码` 用到，且其值在单次调用内即被重置，**无可观测差异**；
- `SBR_A9_来料检测` 在原工程被 `LDI M8000` 旁路，仍照原样生成；
- 生成器无法翻译的指令会留 `/* TODO */` 注释并计入第 1 节统计（当前 {todos} 条）。
'''


# --------------------------------------------------------------------------- ST 块
def st_block_names(il_dir: Path) -> list[str]:
    names: set[str] = set()
    for f in il_dir.glob("*.il.txt"):
        for m in re.finditer(r"EXECUTE\s+(_STB\d+)",
                             f.read_text(encoding="utf-8", errors="replace")):
            names.add(m.group(1))
    return sorted(names, key=lambda s: int(s[4:]))


def emit_st_blocks(st_dir: Path, names, instances, pins_of, types_of, syms, enums,
                   owners, members, usepins, arrays):
    """把 ST 块译成 C（源码来自工程文件，见 artifacts/st/）。

    归属：被 FB 体内的 EXECUTE 调用的 ST 块，其局部量与 FB 共用同一份实例内存
    （因此译成 FB 结构体成员，并通过 `self` 访问）；被程序调用的则译成文件级 static。"""
    bodies, all_refs = [], set()
    for n in names:
        owner = owners.get(n)
        src = "\n".join(l for l in (st_dir / f"{n.lstrip('_')}.st").read_text(encoding="utf-8")
                        .splitlines() if not l.startswith("(*"))
        pins_set = set(pins_of.get(owner, [])) if owner else set()
        extra_pins = [p for p in pins_of.get(owner, []) if p in usepins.get(n, [])]
        # 预扫描：先把 ST 里出现、但工程变量表/引脚都没有的名字登记下来
        pre = set(re.findall(r"[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*", src))
        for r in sorted(pre):
            if (r in syms or r in instances or r in enums or r in pins_set
                    or r in IL_KW or r in il2c.FB_LOCALS.get(owner or "", set())
                    or re.fullmatch(r"(K\d+|H[0-9A-Fa-f]+|E-?\d+(\.\d+)?|\d+)", r)
                    or r.upper() in {"IF", "FOR", "TO", "BY", "DO", "THEN", "ELSE", "ELSIF",
                                     "END_IF", "END_FOR", "CASE", "OF", "END_CASE", "TRUE",
                                     "FALSE", "AND", "OR", "NOT", "EXIT", "WHILE", "END_WHILE"}):
                continue
            if owner:
                ty = "double" if r.lower().startswith(("vf_", "of_")) else (
                    "plc_bit" if re.search(re.escape(r) + r"\s*:=\s*(TRUE|FALSE|true|false|1|0)\b", src)
                    else "int32_t")
                cnt = 32 if re.search(re.escape(r) + r"\s*\[", src) else 1
                members.setdefault(owner, {})[r] = (ty, cnt)
        il2c.FB_LOCALS = {fb: set(v) for fb, v in members.items()}
        il2c.CUR_LOCALS = il2c.FB_LOCALS.get(owner, set()) if owner else set()
        # ST 里标识符与下标是分开处理的：数组型引脚要解析成裸名（形参已是元素指针），
        # 标量引脚解析成 (*p)，FB 局部量解析成 self->x
        def resolve(x, _o=owner, _a=arrays):
            if _o and x in pins_of.get(_o, []):
                return x if x in _a.get(_o, set()) else f"(*{il2c.ident(x)})"
            return il2c.operand(x, None, set())
        code, refs = st2c.translate(src, ident=resolve,
                                    instances=instances, pins_of=pins_of, types_of=types_of,
                                    const_value=il2c.const_value)
        all_refs |= refs
        loc, seen = [], set()
        for r in sorted(refs):
            if (r in syms or r in instances or r in enums or r in seen or r in pins_set
                    or re.fullmatch(r"\d+|IF|FOR|TO|BY|DO|THEN|ELSE|ELSIF|END_IF|END_FOR|TRUE|FALSE",
                                    r, re.I)):
                continue
            seen.add(r)
            ty = "double" if r.lower().startswith(("vf_", "of_")) else "int32_t"
            cnt = 32 if re.search(re.escape(r) + r"\s*\[", src) else 1
            if owner:                                   # 与 FB 共用实例内存
                members.setdefault(owner, {})[r] = (ty, cnt)
            else:
                loc.append(f"    static {ty} {il2c.ident(r)}[{cnt}];" if cnt > 1
                           else f"    static {ty} {il2c.ident(r)} = 0;   /* ST 局部（按用法推断） */")
        if owner:
            sig = ", ".join([f"{il2c.ident(owner)}_t *self"]
                            + [f"{types_of.get(owner, {}).get(p, 'plc_bit')} *{il2c.ident(p)}"
                               for p in extra_pins])
        else:
            sig = "void"
        bodies.append("/* ================= " + n + " =================\n"
                      "   原文：artifacts/st/" + n.lstrip("_") + ".st"
                      + (f" （FB {owner} 内的 ST 块，与 FB 共用实例内存）\n" if owner else "\n")
                      + "*/\nvoid " + n + "(" + sig + ") {\n" + "\n".join(loc)
                      + ("\n" if loc else "") + "\n".join(code) + "\n}\n")
    head = ('#include "symbols.h"\n#include "fb.h"\n#include "fb_instances.h"\n#include "enums.h"\n\n'
            "/* ============================================================================\n"
            " * st_blocks.c —— ST（结构化文本）块\n"
            " *\n"
            " * 原工程 ST 源码内嵌在 .LD/.FB 文件里（AutoShop 编辑器显示为加密，源码文本本身在工程内），\n"
            " * 已提取到 artifacts/st/*.st，下面逐行译成 C，并保留 ST 原文注释。\n"
            " * 这是**真实源码**的翻译，不是推测重建。\n"
            " * ========================================================================== */\n\n")
    return head + "\n".join(bodies), all_refs


# --------------------------------------------------------------------------- 仿真侧
SIM_C_HEAD = (
    '#include "sim.h"\n#include <stdio.h>\n\n'
    "/* ============================================================================\n"
    " * sim.c —— 机械/负载替身（**不是** PLC 逻辑；原工程里这些信号来自真实传感器与伺服）\n"
    " *\n"
    " * 气缸：出位 Y 有效后出位感应有效，回位同理（原位/出位互斥）。\n"
    " * 真空：开真空 Y 有效后真空检测有效。\n"
    " * ========================================================================== */\n\n")

SIM_MACHINE = (
    "void sim_machine_step(int32_t dt) {\n"
    "    (void)dt;\n"
    "{body}\n"
    "}\n\n"
    "void sim_print_state(void) {\n"
    '    printf("\\n===== 仿真快照 =====\\n");\n'
    '    printf("设备状态机: 自动中=%d 手动中=%d 自动暂停中=%d 初始化中=%d\\n",\n'
    "           设备状态机.QB_自动中, 设备状态机.QB_手动中,\n"
    "           设备状态机.QB_自动暂停中, 设备状态机.QB_初始化中);\n"
    "{prints}\n"
    "}\n")


def emit_sim(instances, bindings):
    """气缸/真空反馈 + 状态打印。"""
    body, prints = [], []
    for inst, fb in sorted(instances.items()):
        i = il2c.ident(inst)
        if fb == "气缸_FB":
            body.append(
                f"    /* {inst}（气缸_FB） */\n"
                f"    if ({i}.出位Y) {{ {i}.出位感应 = 1; {i}.原位感应 = 0; }}\n"
                f"    else {{ {i}.原位感应 = 1; {i}.出位感应 = 0; }}")
            prints.append(f'    printf("{inst}: 原位Y=%d 出位Y=%d 原位OK=%d 出位OK=%d\\n", '
                          f'{i}.原位Y, {i}.出位Y, {i}.原位OK, {i}.出位OK);')
        elif fb == "真空_FB":
            body.append(f"    /* {inst}（真空_FB） */\n"
                        f"    if ({i}.开真空Y) {i}.真空检测 = 1;\n"
                        f"    else if ({i}.破真空Y) {i}.真空检测 = 0;")
    return (SIM_C_HEAD + SIM_MACHINE
            .replace("{body}", "\n".join(body) or "    /* 无气缸/真空实例 */")
            .replace("{prints}", "\n".join(prints) or "    (void)0;"))


SIM_AXIS_C = (
    '#include "sim.h"\n#include <math.h>\n\n'
    "/* 轴替身：使能后按 fSetPosition 积分位置，到位后置 PLCopen 状态字 bit10。\n"
    "   真实工程里位置由 EtherCAT 伺服/电缸反馈，这里只是让逻辑跑起来。 */\n"
    "void sim_axis_step(int32_t dt) {\n"
    "    (void)dt;\n"
    "{body}\n"
    "}\n")


def emit_sim_axis(bindings):
    body, seen = [], set()
    for inst, b in sorted(bindings.items()):
        ax = b.get("Axis")
        if not ax or ax in seen:
            continue
        seen.add(ax)
        a = il2c.ident(ax)
        body.append(
            f"    /* {a}（{inst} 的轴对象） */\n"
            f"    if ({a}.wPLCOpenState & 0x0001) {{\n"
            f"        double d = {a}.fSetPosition - {a}.fActPosition;\n"
            f"        if (fabs(d) > 0.5) {{ {a}.fActPosition += (d > 0 ? 5.0 : -5.0); "
            f"{a}.wPLCOpenState &= (short)~0x0400; }}\n"
            f"        else {{ {a}.wPLCOpenState |= 0x0400; }}\n"
            f"    }}")
    return SIM_AXIS_C.replace("{body}", "\n".join(body) or "    /* 无轴实例 */")


SIM_SCENARIO = (
    '#include "sim.h"\n\n'
    "/* 演示场景：把设备状态机推到\"自动\"，观察 撕膜位进料 的 工位状态字/流程推进。\n"
    "   真实产线启动条件复杂得多，本函数只用于演示 C 工程可单步执行。 */\n"
    "void sim_scenario(int cycle, void *ctx) {\n"
    "    (void)ctx;\n"
    "    if (cycle == 1) { 设备状态机.IB_手自动切换 = 1; 设备状态机.IB_启动按钮 = 1; }\n"
    "    if (cycle == 3) { 设备状态机.IB_启动按钮 = 0; }\n"
    "    if (cycle == 5) { HMI_自动中[0] = 1; }\n"
    "}\n")




# ----------------------------------------------------------------- 兜底建模
PATH_HINTS: dict[str, set[str]] = {}
ARRAY_ROOTS: set[str] = set()      # 成员路径的根是数组（如 _ECATSlave[0]…）
DEV_RE = re.compile(r"^([WDMRSTCXYVZ])(\d+)(?:_(\d+))?$")
DEV_TYPE = {"W": "plc_word", "D": "plc_word", "R": "plc_word", "M": "plc_bit", "S": "plc_bit",
            "T": "plc_bit", "C": "plc_bit", "X": "plc_bit", "Y": "plc_bit",
            "V": "int16_t", "Z": "plc_bit"}


def collect_fallback(allcode: str, syms, instances, enums):
    """(1) 变量表没收录的**设备地址**；(2) **结构化变量**的成员路径（支持 `_ECATSlave[0].bSlaveRunState`）。"""
    devs: dict[str, str] = {}
    paths: set[str] = set()
    # 注释与 #include 里会出现 enums.h / Axis.fActPosition 之类，必须先剔除
    clean = re.sub(r"/\*.*?\*/", " ", allcode, flags=re.S)
    clean = re.sub(r"//[^\n]*", " ", clean)
    clean = "\n".join(l for l in clean.splitlines() if not l.lstrip().startswith("#"))
    for m in re.finditer(r"[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*"
                         r"(?:\[\w*\])?"
                         r"(?:\.[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*(?:\[\w*\])?)+", clean):
        paths.add(m.group(0))
    for m in re.finditer(r"\b[A-Za-z_][A-Za-z0-9_]*\b", clean):
        n = m.group(0)
        if n in syms or n in instances or n in enums or n in IL_KW:
            continue
        d = DEV_RE.fullmatch(n)
        if d:
            devs[n] = DEV_TYPE[d.group(1)]
    return devs, paths


def norm_path(path: str) -> tuple[str, bool]:
    """`_ECATSlave[0].bSlaveRunState` → (`_ECATSlave.bSlaveRunState`, 根是数组)。"""
    arr = bool(re.match(r"[^.\[\]]+\[", path))
    return re.sub(r"\[[^\]]*\]", "", path), arr


def struct_trees(paths, syms, instances, fbnames):
    """把 A.B.C 形态的成员路径铺成嵌套结构体树；返回 (非 FB 根的树, 需要补进 FB 的成员)。"""
    var_trees: dict[str, dict] = {}
    fb_trees: dict[str, dict] = {}
    ARRAY_ROOTS.clear()
    for raw in paths:
        path, is_arr = norm_path(raw)
        if is_arr:
            ARRAY_ROOTS.add(path.split(".")[0])
        segs = path.split(".")
        if segs[0] in IL_KW or len(segs) < 2:
            continue
        is_real_fb = segs[0] in instances and instances[segs[0]] in FBNAMES
        target = fb_trees if is_real_fb else var_trees
        node = target.setdefault(segs[0], {})
        for s in segs[1:]:
            node = node.setdefault(s, {})
    if fbnames is not None:                      # 只保留真的需要补成员的 FB
        fb_trees = {k: v for k, v in fb_trees.items() if k in instances}
    return var_trees, fb_trees


def emit_auto_structs(var_trees, fb_trees) -> str:
    """生成结构化变量的嵌套结构体定义。"""
    out = ["#pragma once", '#include "plc.h"', "",
           "/* 自动生成：变量表里以【结构体】使用的对象（如 产能.ib_投料信号）。",
           "   成员类型按使用方式推断（位/16 位/32 位/浮点）。*/", ""]

    def tyname(base: str) -> str:
        return il2c.ident(base) + "_t"

    def leaf_type(path: str) -> str:
        hs = PATH_HINTS.get(path, set())
        if "double" in hs:
            return "double"
        if "int32_t" in hs:
            return "int32_t"
        if hs == {"plc_bit"} or not hs:
            return "plc_bit"
        return "int16_t"

    def emit_tree(base: str, tree: dict, out: list) -> None:
        for k, v in sorted(tree.items()):
            if v:
                emit_tree(base + "_" + k, v, out)
        lines = []
        for k, v in sorted(tree.items()):
            lines.append(f"    {tyname(base + '_' + k) if v else leaf_type(base + '.' + k)} {il2c.ident(k)};")
        out.append(f"typedef struct {{\n" + "\n".join(lines) + f"\n}} {tyname(base)};")
        out.append("")

    for base, tree in sorted(var_trees.items()):
        emit_tree(base, tree, out)
    for base, tree in sorted(fb_trees.items()):
        emit_tree(base, tree, out)
    return "\n".join(out) + "\n"


# --------------------------------------------------------------------------- main
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--il-dir", default="artifacts/il")
    ap.add_argument("--symbols", default="artifacts/text/VarNameAndAddr.csv.txt")
    ap.add_argument("--st-dir", default="artifacts/st")
    ap.add_argument("--updir", default="project/UpLoad")
    ap.add_argument("--out", default="cproject")
    a = ap.parse_args()

    syms = il2c.load_symbols(Path(a.symbols))
    progs = il2c.parse_programs(Path(a.il_dir))
    fbs = il2c.parse_fbs(Path(a.il_dir))
    enums = parse_enums(Path(a.updir))
    instances = collect_instances(Path(a.il_dir))
    fbpins = {u.name: list(u.pins) for u in fbs}
    fbtypes = {u.name: il2c.infer_pin_types(u) for u in fbs}
    il2c.SYMS, il2c.FB_PINS, il2c.FB_TYPES, il2c.INST_FB = syms, fbpins, fbtypes, instances
    global PATH_HINTS, PROGNAMES, FBNAMES
    PROGNAMES = {u.name for u in progs}
    FBNAMES = {u.name for u in fbs}

    hints, indexed, maxidx = collect_usage(progs + fbs)
    members = derive_fb_members(fbs, syms, instances, enums)
    il2c.FB_LOCALS = {fb: set(v) for fb, v in members.items()}
    il2c.FB_LOCAL_ARRAYS = {fb: {b for b, (_t, c) in v.items() if c > 1}
                            for fb, v in members.items()}
    arrays: dict = {}
    for fb, v in members.items():
        arrays[fb] = {b for b, (_t, c) in v.items() if c > 1}
    il2c.BIT_ARRAYS = {n for n in indexed if hints.get(n, set()) == {"plc_bit"}}

    # 引脚绑定：CALL_FB <FB> <实例> <绑定值…>
    bindings: dict[str, dict[str, str]] = {}
    for f in Path(a.il_dir).glob("*.il.txt"):
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            p = line.split()
            if len(p) > 3 and p[1] == "CALL_FB" and p[3] in instances:
                pins = fbpins.get(p[2], [])
                bindings[p[3]] = {pins[i]: p[4 + i] for i in range(min(len(pins), len(p) - 4))}
    for inst, b in bindings.items():
        fb = instances[inst]
        for pin, v in b.items():
            if re.fullmatch(r"K\d+", v) and int(v[1:]) > 1:
                il2c.PIN_TYPE_OVERRIDE.setdefault(fb, {})[pin] = (
                    "int32_t" if int(v[1:]) > 32767 else "int16_t")
            elif re.fullmatch(r"E-?\d+(\.\d+)?", v):
                il2c.PIN_TYPE_OVERRIDE.setdefault(fb, {})[pin] = "double"
    il2c.ARRAY_PINS, il2c.ARRAY_SYMS = {}, indexed
    for inst, b in bindings.items():
        arr = {pin for pin, v in b.items() if v.split("[")[0].split(".")[0] in indexed}
        if arr:
            il2c.ARRAY_PINS[inst] = arr
    for inst, b in bindings.items():
        fb = instances[inst]
        for pin, v in b.items():
            base = v.split("[")[0].split(".")[0]
            # 只有绑定到**整个数组/字符串**时引脚才是数组；绑定到某元素（HMI_x[3]）仍是标量
            if base in indexed and re.fullmatch(r"[^.\[\]]+", v):
                arrays.setdefault(fb, set()).add(pin)
                arrays[(fb, pin)] = max(arrays.get((fb, pin), 1), 32)
    # FB 体内部直接按下标访问的引脚（如 (*HMI_位置保存)[0]）同样是数组
    for u in fbs:
        pins = set(u.pins)
        for _ad, text in u.body:
            for arg in text.split()[1:]:
                m = re.fullmatch(r"([^.\[\]]+)\[(\d+)\]", arg)
                if m and m.group(1) in pins:
                    arrays.setdefault(u.name, set()).add(m.group(1))
                    arrays[(u.name, m.group(1))] = max(
                        arrays.get((u.name, m.group(1)), 1), int(m.group(2)) + 1)
    for inst, fb in instances.items():
        for pin in arrays.get(fb, set()):
            il2c.ARRAY_PINS.setdefault(inst, set()).add(pin)

    called = {re.match(r"CALL\s+(\S+)", text).group(1)
              for u in progs + fbs for _ad, text in u.body if re.match(r"CALL\s+(\S+)", text)}
    by_lower = {n.lower(): n for n in PROGNAMES}
    il2c.PROG_ALIAS = {c: by_lower[c.lower()] for c in called if c.lower() in by_lower}
    il2c.MISSING_PROGS = sorted(c for c in called
                                if c.lower() not in by_lower and c not in instances and c not in fbpins)
    if il2c.MISSING_PROGS:
        print("本体不在编译输出里的子程序（加密块）：", il2c.MISSING_PROGS)
    prog_locals = derive_prog_locals(progs, syms, instances, enums, members)
    # ST 块：归属 FB、以及需要用到的引脚（作为指针透传给 ST 函数）
    st_names = st_block_names(Path(a.il_dir))
    owners: dict[str, str | None] = {}
    for u in progs + fbs:
        for _ad, text in u.body:
            m = re.match(r"EXECUTE\s+(_STB\d+)", text)
            if m:
                owners[m.group(1)] = u.name if u.kind == "fb" else None
    st_pins: dict[str, list[str]] = {}
    for n in st_names:
        owner = owners.get(n)
        if not owner:
            continue
        src = (Path(a.st_dir) / f"{n.lstrip('_')}.st").read_text(encoding="utf-8")
        st_pins[n] = [p for p in fbpins.get(owner, [])
                      if re.search(r"(?<![\w\u4e00-\u9fff])" + re.escape(p) + r"(?![\w\u4e00-\u9fff])", src)]
    il2c.ST_PINS = st_pins

    written, todos = {}, []
    for u in progs + fbs:
        code, td = il2c.gen_unit_fn(u)
        written[u.name] = code
        todos += [f"{u.name}: {t}" for t in td]

    # 成员路径的类型线索（A.B.C 中每个叶子按所用指令推断）
    for u in progs + fbs:
        for _ad, text in u.body:
            q = text.split()
            for arg in q[1:]:
                if "." in arg and not arg[0].isdigit():
                    h = hint_of(q[0])
                    PATH_HINTS.setdefault(arg.split("[")[0], set()).add(h or "plc_bit")

    st_code, st_refs = emit_st_blocks(Path(a.st_dir), st_names, instances, fbpins, fbtypes,
                                      syms, enums, owners, members, st_pins, arrays)
    il2c.FB_LOCALS = {fb: set(v) for fb, v in members.items()}
    used = {r for r in st_refs if r in syms} | {r for r in il2c.EXTRA_SYMS}
    for code in list(written.values()) + [st_code]:
        for m in re.finditer(r"[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*", code):
            if m.group(0) in syms:
                used.add(m.group(0))
    # 兜底：变量表未收录的设备地址 + 结构化变量
    devs, paths = collect_fallback("\n".join(list(written.values()) + [st_code]), syms, instances, enums)
    il2c.EXTRA_SYMS.update(devs)
    var_trees, fb_trees = struct_trees(paths, syms, instances, set(fbpins))
    # 已按引脚类型声明过外部对象（如轴对象 mca_axis_info_t）的，不再用自动结构体覆盖
    for k in list(var_trees):
        if k in il2c.EXTRA_SYMS:
            del var_trees[k]
    struct_h = emit_auto_structs(var_trees, fb_trees)
    # ST 译文里出现的下标也算证据（ST 不经 IL，故不在上面那轮扫描里）
    for m in re.finditer(r"([A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*)\s*\[([^\]]+)\]", st_code):
        b = m.group(1)
        indexed.add(b)
        if m.group(2).strip().isdigit():
            maxidx[b] = max(maxidx.get(b, 0), int(m.group(2)) + 1)
    types = infer_types(syms, hints, indexed, used, maxidx)
    # FB 实例名在 fb_instances.h 里以结构体声明；结构化变量在 structs.h 里以结构体声明
    types = {n: v for n, v in types.items()
             if n not in instances and n not in var_trees}

    out = Path(a.out)
    for d in ("include", "src", "sim"):
        (out / d).mkdir(parents=True, exist_ok=True)
    (out / "include/plc.h").write_text(PLH, encoding="utf-8")
    (out / "include/symbols.h").write_text(
        emit_symbols_h(syms, types, {n: group_of(n) for n in types}), encoding="utf-8")
    (out / "include/enums.h").write_text(emit_enums_h(enums), encoding="utf-8")
    (out / "src/symbols.c").write_text(emit_symbols_c(types), encoding="utf-8")
    (out / "include/fb.h").write_text(
        emit_fb_h(fbs, members, arrays,
                  {k: {m: f"{il2c.ident(k + '_' + m)}_t" for m in v} for k, v in fb_trees.items()}),
        encoding="utf-8")
    idecl, idefn = emit_instances(instances, set(fbpins))
    (out / "include/fb_instances.h").write_text(idecl, encoding="utf-8")
    (out / "src/fb_instances.c").write_text(idefn, encoding="utf-8")
    (out / "include/structs.h").write_text(struct_h, encoding="utf-8")
    (out / "include/extra_symbols.h").write_text(
        '#pragma once\n#include "symbols.h"\n#include "plc.h"\n#include "structs.h"\n\n'
        "/* 变量表未收录、但作为 FB 引脚绑定出现的外部对象（按引脚类型声明）。*/\n"
        + "\n".join(f"extern {ty} {il2c.ident(n)};" for n, ty in sorted(il2c.EXTRA_SYMS.items()))
        + "\n".join((f"extern {il2c.ident(n)}_t {il2c.ident(n)}[{max(1, maxidx.get(n, 1))}];"
                      if n in ARRAY_ROOTS else f"extern {il2c.ident(n)}_t {il2c.ident(n)};")
                     for n in sorted(var_trees))
        + "\n", encoding="utf-8")
    (out / "src/extra_symbols.c").write_text(
        '#include "symbols.h"\n#include "plc.h"\n#include "structs.h"\n\n'
        + "\n".join(f"{ty} {il2c.ident(n)};" for n, ty in sorted(il2c.EXTRA_SYMS.items()))
        + "\n".join((f"{il2c.ident(n)}_t {il2c.ident(n)}[{max(1, maxidx.get(n, 1))}];"
                      if n in ARRAY_ROOTS else f"{il2c.ident(n)}_t {il2c.ident(n)};")
                     for n in sorted(var_trees))
        + "\n", encoding="utf-8")
    # 注意：Windows 文件系统大小写不敏感，工程里的 MAIN 程序会占掉 MAIN.c，
    # 因此扫描调度放在 plc_scan.c（避免互相覆盖）
    (out / "src/plc_scan.c").write_text(emit_main(progs), encoding="utf-8")
    (out / "src/plc_helpers.c").write_text(HELPERS, encoding="utf-8")
    (out / "src/library_shims.c").write_text(emit_shims({m: [] for m in LIB_MN}), encoding="utf-8")
    (out / "src/st_blocks.c").write_text(st_code, encoding="utf-8")
    (out / "include/st_blocks.h").write_text(
        '#pragma once\n#include "fb.h"\n\n/* ST 块原型（st_blocks.c 定义；被 FB/程序通过 EXECUTE 调用）。*/\n'
        + "\n".join(("void " + n + "(" + ", ".join(
            [f"{il2c.ident(owners[n])}_t *self"]
            + [f"{fbtypes.get(owners[n], {}).get(p, 'plc_bit')} *{il2c.ident(p)}"
               for p in st_pins.get(n, [])]) + ");") if owners.get(n)
            else f"void {n}(void);" for n in st_names) + "\n", encoding="utf-8")
    for name, code in written.items():
        head = ""
        loc = prog_locals.get(name)
        if loc:
            head = ("/* 本程序内的临时量（原工程里是程序私有变量）*/\n"
                    + "\n".join(f"static {ty} {il2c.ident(b)}"
                                 + (f"[{cnt}]" if cnt > 1 else "") + ";"
                                 for b, (ty, cnt) in sorted(loc.items())) + "\n\n")
        (out / "src" / f"{il2c.ident(name)}.c").write_text(
            '#include "symbols.h"\n#include "fb.h"\n#include "fb_instances.h"\n'
            '#include "enums.h"\n#include "extra_symbols.h"\n#include "st_blocks.h"\n\n'
            + head + code, encoding="utf-8")
    (out / "include/sim.h").write_text(SHARED_H, encoding="utf-8")
    (out / "sim/main.c").write_text(SIM_MAIN_C, encoding="utf-8")
    (out / "sim/sim.c").write_text(emit_sim(instances, bindings), encoding="utf-8")
    (out / "sim/sim_axis.c").write_text(emit_sim_axis(bindings), encoding="utf-8")
    (out / "sim/scenario.c").write_text(SIM_SCENARIO, encoding="utf-8")
    (out / "Makefile").write_text(MAKEFILE, encoding="utf-8")
    (out / "README.md").write_text(
        README.replace("{progs}", str(len(progs))).replace("{fbs}", str(len(fbs)))
              .replace("{insts}", str(len(instances))).replace("{syms}", str(len(types)))
              .replace("{stblocks}", str(len(st_names))).replace("{todos}", str(len(todos))),
        encoding="utf-8")
    print(f"程序 {len(progs)} / FB {len(fbs)} / 实例 {len(instances)} / 变量 {len(types)} / "
          f"ST 块 {len(st_names)} / 待处理 {len(todos)} / 额外符号 {len(il2c.EXTRA_SYMS)}")
    for t in todos[:40]:
        print("   ", t)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
