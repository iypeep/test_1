#!/usr/bin/env python3
"""st2c.py —— AutoShop 结构化文本（ST）子集 → C 翻译器。

只服务于本工程（汇川 H5U）ST 块的可读重建：
  * 源文本来自工程文件里内嵌的 ST 源码（tools/il2c_project.py 已提取到 artifacts/st/）；
  * 覆盖本工程实际用到的语法：赋值、IF/ELSIF/ELSE、FOR..TO..BY..DO、CASE..OF、
    WHILE、EXIT、FB 具名实参调用；
  * 未识别的行原样变成 `/* ST? */` 注释，绝不会静默丢逻辑。

生成代码的阅读约定：每段翻译前都保留 ST 原文注释，便于与 AutoShop 里对照。
"""
from __future__ import annotations

import re

KW = {"if", "else", "for", "while", "switch", "case", "break", "continue", "return",
      "default", "fabs", "int", "long", "double", "void", "static", "const", "true", "false"}


def _num(e: str) -> str:
    """AutoShop 字面量：E10.0 / E0.3 → 浮点；K100 → 整型；H2260 → 0x2260。"""
    e = re.sub(r"\bE(\d+(?:\.\d+)?)(?![\w.])", r"\1.0" if "." not in r"\1" else r"\1", e, flags=re.I)
    e = re.sub(r"\bE(\d+\.\d+)", r"\1", e, flags=re.I)
    e = re.sub(r"\bK(\d+)", r"\1", e)
    e = re.sub(r"\bH([0-9A-Fa-f]+)", r"0x\1", e)
    return e


def expr(e: str, ident, cond: bool = False) -> str:
    """ST 表达式 → C 表达式。"""
    e = _num(e)
    e = re.sub(r"\bTRUE\b", "1", e, flags=re.I)
    e = re.sub(r"\bFALSE\b", "0", e, flags=re.I)
    e = re.sub(r"\bAND\b|&&", "&&", e, flags=re.I)
    e = re.sub(r"\bOR\b|\|\|", "||", e, flags=re.I)
    e = re.sub(r"\bNOT\b", "!", e, flags=re.I)
    e = re.sub(r"\bMOD\b", "%", e, flags=re.I)
    e = e.replace("<>", "!=")
    if cond:
        e = re.sub(r"(?<![<>=!:+\-*/])=(?!=)", "==", e)   # 条件里的 = 是比较
    e = re.sub(r"\bABS\s*\(", "fabs(", e, flags=re.I)

    def tok(m):
        w = m.group(0)
        if w.lower() in KW:
            return w
        return ident(w)

    return re.sub(r"[A-Za-z_\u4e00-\u9fff][A-Za-z0-9_\u4e00-\u9fff]*", tok, e)


def translate(src: str, *, ident, instances: dict[str, str], pins_of: dict[str, list[str]],
              types_of: dict[str, dict[str, str]], const_value) -> tuple[list[str], set[str]]:
    """ST 源码 → (C 语句列表, 引用到的符号集合)。"""
    out: list[str] = []
    refs: set[str] = set()

    def ref(e: str) -> str:
        for n in re.findall(r"[A-Za-z_\u4e00-\u9fff][A-Za-z0-9_\u4e00-\u9fff]*", e):
            if n not in KW:
                refs.add(n)
        return e

    raw = [l.rstrip() for l in src.splitlines()]
    i = 0
    while i < len(raw):
        line = re.sub(r"[\x00-\x1f]", " ", re.sub(r"//.*$", "", raw[i])).strip()
        if not line:
            i += 1
            continue
        u = line.upper().rstrip(";")

        # ---- FB 具名实参调用：<实例名> ( ... );
        if line in instances:
            buf, j = [], i + 1
            while j < len(raw):
                buf.append(re.sub(r"[\x00-\x1f]", " ", re.sub(r"//.*$", "", raw[j])))
                if ");" in buf[-1]:
                    break
                j += 1
            body = " ".join(buf).strip()
            order = pins_of.get(instances[line], [])
            tys = types_of.get(instances[line], {})
            named = dict(re.findall(r"([A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*)\s*(?::=|=>)\s*([^,()]*)?", body))
            outs = set(re.findall(r"([A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*)\s*=>", body))
            args, decls = [], []
            for k, p in enumerate(order):
                v = (named.get(p) or "").strip()
                ty = tys.get(p, "plc_bit")
                if p in outs or v == "":
                    args.append(f"&{ident(line)}.{ident(p)}")
                elif re.fullmatch(r"-?\d+(\.\d+)?", v) or const_value(v) is not None:
                    lit = v if re.fullmatch(r"-?\d+(\.\d+)?", v) else const_value(v)
                    args.append(f"&({ty}){{{lit}}}")   # 复合字面量取址
                else:
                    args.append("&" + ref(expr(v, ident)))
            out.append(f"    /* ST: {line}(...) */")
            out.extend(decls)
            out.append(f"    {ident(instances[line])}_call(&{ident(line)}"
                       + (", " + ", ".join(args) if args else "") + ");")
            i = j + 1
            continue

        # ---- 控制结构
        m = re.fullmatch(r"FOR\s+(\w+)\s*:=\s*(.+?)\s+TO\s+(.+?)(?:\s+BY\s+(.+?))?\s+DO", line, re.I)
        if m:
            v, a, b, st = (m.group(1), ref(expr(m.group(2), ident)), ref(expr(m.group(3), ident)),
                           (m.group(4) or "1").strip())
            out.append(f"    for ({ident(v)} = {a}; {ident(v)} <= {b}; {ident(v)} += {expr(st, ident)}) {{")
            i += 1
            continue
        m = re.fullmatch(r"IF\s+(.+?)\s*THEN", line, re.I)
        if m:
            out.append(f"    if ({ref(expr(m.group(1), ident, cond=True))}) {{")
            i += 1
            continue
        m = re.fullmatch(r"ELSIF\s+(.+?)\s*THEN", line, re.I)
        if m:
            out.append(f"    }} else if ({ref(expr(m.group(1), ident, cond=True))}) {{")
            i += 1
            continue
        if u == "ELSE":
            out.append("    } else {")
            i += 1
            continue
        if u in ("END_IF", "ENDIF"):
            out.append("    }")
            i += 1
            continue
        if u == "END_FOR":
            out.append("    }")
            i += 1
            continue
        m = re.fullmatch(r"WHILE\s+(.+?)\s+DO", line, re.I)
        if m:
            out.append(f"    while ({expr(m.group(1), ident, cond=True)}) {{")
            i += 1
            continue
        if u in ("END_WHILE", "ENDWHILE"):
            out.append("    }")
            i += 1
            continue
        m = re.fullmatch(r"CASE\s+(.+?)\s+OF", line, re.I)
        if m:
            out.append(f"    switch ({expr(m.group(1), ident)}) {{")
            i += 1
            continue
        if u == "END_CASE":
            out.append("    }")
            i += 1
            continue
        if re.fullmatch(r"\d+\s*:", line):
            out.append(f"    case {line.split(':')[0].strip()}:")
            i += 1
            continue
        if u == "EXIT":
            out.append("    break;")
            i += 1
            continue

        # ---- 赋值 / 其它语句
        m = re.fullmatch(r"(.+?)\s*:=\s*(.+?);?", line)
        if m:
            lhs, rhs = ref(expr(m.group(1).strip(), ident)), ref(expr(m.group(2).strip(), ident))
            out.append(f"    {lhs} = {rhs};")
            i += 1
            continue
        out.append(f"    /* ST? 未能识别: {line} */")
        i += 1
    return out, refs


def split_code_comments(src: str) -> tuple[list[str], list[str]]:
    """把 ST 源码按行保留，用于生成并列注释。"""
    return [l.rstrip() for l in src.splitlines()], []
