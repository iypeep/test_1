#!/usr/bin/env python3
"""从 AutoShop 二进制工程文件中抽取可打印字符串（含中文注释）。

用途：*.LD / *.FB / *.gvt / *.sdt / *.stru / *.enum 等是 AutoShop 的二进制容器，
      内部把指令操作数、变量名、中文网络注释、FB 引脚注释以 UTF-8 明文存放，
      抽取后即可 grep 与人工阅读（配合编译输出 il_log.log 交叉验证效果最好）。

用法：
    python dump_strings.py <工程目录> [输出目录]
"""
import re
import sys
from pathlib import Path

RUN = re.compile(rb'(?:[\x20-\x7e]|[\x80-\xff]){3,}')
EXTS = {'.ld', '.fb', '.gvt', '.gdt', '.stru', '.sdt', '.enum', '.fbi', '.fci',
        '.qmt', '.vi', '.vid', '.tr', '.ecgvt', '.eipgvt', '.esi', '.gdtx',
        '.dat', '.cfg', '.ab', '.am', '.libtemp', '.flib'}


def extract(raw: bytes) -> list[str]:
    """按 UTF-8 解码连续可打印/高位字节串，丢弃非法序列产生的残片。"""
    out = []
    for m in RUN.finditer(raw):
        for chunk in m.group().decode('utf-8', 'replace').split('\ufffd'):
            chunk = chunk.strip()
            if len(chunk) >= 3 and chunk.isprintable():
                out.append(chunk)
    return out


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else src.parent / '_text'
    dst.mkdir(parents=True, exist_ok=True)
    n = 0
    for p in sorted(src.iterdir()):
        if not p.is_file():
            continue
        raw = p.read_bytes()
        if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):          # UTF-16 导出表（如 *.csv）
            (dst / (p.name + '.txt')).write_text(
                raw.decode('utf-16', 'replace'), encoding='utf-8')
            n += 1
        elif raw.startswith(b'AutoShop') or p.suffix.lower() in EXTS:
            (dst / (p.name + '.strings.txt')).write_text(
                "\n".join(extract(raw)), encoding='utf-8')
            n += 1
    print(f'写出 {n} 个文本文件到 {dst}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
