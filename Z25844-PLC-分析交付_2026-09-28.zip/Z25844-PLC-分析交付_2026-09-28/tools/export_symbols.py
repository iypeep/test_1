#!/usr/bin/env python3
"""把工程导出的 VarNameAndAddr.csv（UTF-16）转成上位机可用的符号地址字典。

输入格式（Tab 分隔，UTF-16LE）：
    符号名 <TAB> 0X402660 <TAB> 枚举/注释 <TAB> 位长
例：
    AOI1检测返回结果	0X402640	1OK2NG	16

输出：
    symbols.csv   （utf-8-sig，Excel 可直接打开；列：symbol,address,address_dec,bits,enum）
    symbols.json  （UTF-8，供程序读取）

用法：
    python export_symbols.py <VarNameAndAddr.csv> [输出目录]
"""
import csv
import json
import sys
from pathlib import Path


def build(src: Path) -> list[dict]:
    rows = []
    for line in src.read_bytes().decode('utf-16').splitlines():
        if not line.strip():
            continue
        p = line.split('\t')
        addr = p[1].strip() if len(p) > 1 else ''
        rows.append({
            'symbol': p[0].strip(),
            'address': addr,
            'address_dec': int(addr[2:], 16) if addr.upper().startswith('0X') else '',
            'bits': p[3].strip() if len(p) > 3 else '',
            'enum': p[2].strip() if len(p) > 2 else '',
        })
    return rows


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else src.parent.parent / 'definitions'
    dst.mkdir(parents=True, exist_ok=True)
    rows = build(src)
    with open(dst / 'symbols.csv', 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['symbol', 'address', 'address_dec', 'bits', 'enum'])
        w.writeheader()
        w.writerows(rows)
    json.dump(rows, open(dst / 'symbols.json', 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print(f'{len(rows)} 个符号 → {dst}/symbols.csv|json')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
