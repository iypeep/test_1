# 汇川 H5U PLC 工程分析与学习手册（Z25844-N01）

> 对象：现场机台 **Z25844-N01**（电子纸模组 FPC/ACF 组装线）所用**汇川（Inovance）AutoShop / H5U 系列 PLC 工程**
> 内容：完整工程副本 + 逐程序还原的**分析手册**（含定义表、IO 点位表、IL 指令表、工位流程表、上位机通讯协议）
> 性质：**私有仓库**，仅供本人/团队内部学习与维护使用

---

## 1. 仓库结构

```
├─ analysis/                     ← 本轮分析成果（原创，11 篇 / 约 5700 行）
│   ├─ README.md                 总览：三分钟速览、阅读顺序、验证方法
│   ├─ 01-机台档案与硬件拓扑.md
│   ├─ 02-程序架构-主控状态机初始化与报警.md
│   ├─ 03-专题A-PLC与上位机通讯.md          ← 视觉/ACF/机器人/扫码/Modbus/OPC UA/EIP/FTP
│   ├─ 04-专题B-气路阀门气缸真空.md          ← 36 气缸逐个点名 + 气缸_FB/真空_FB 内部逻辑
│   ├─ 05-专题C-PLC与运动控制-伺服步进电缸.md  ← 运动控制卡 vs PLC 内置运动、Axis_FB、三种控制层级
│   ├─ 06-专题D-PLC编程方法与工程规范.md
│   ├─ 07-工艺流程与输送.md                  ← 19 个自动程序 / 318 个步号的动作表
│   ├─ 08-PLC入门与四周学习路线.md           ← 零基础入门 + 学习计划 + 5 个动手练习
│   ├─ 09-附录-点位表与符号清单.md           ← X 88 / Y 197 点表、36 气缸表、44 条报警、地址地图
│   └─ 10-C工程-把梯形图变成可调试代码.md     ← IL→C 重建流水线、ST 源码提取、类型推断与保真度
│
├─ cproject/                     ← **IL/ST → C 工程**（可编译、可单步；用来读程序比梯形图快）
│   ├─ include/  src/  sim/  Makefile  README.md
│   └─ 生成命令：python tools/il2c_project.py
│
├─ project/                      ← PLC 工程本体（AutoShop 工程目录，明文副本）
│   ├─ 临时工程/                 工作副本（*.LD/*.FB/*.gvt/*.stru、il_log.log、VarNameAndAddr.csv、Compile/、PLC/）
│   └─ UpLoad/                   从 PLC 上传的副本（2026-09-08；其中 6 个程序块为加密/加扰状态）
│
├─ artifacts/                    ← 本次分析生成的可复用中间产物
│   ├─ il/                       按程序切分的 IL 指令表（00-MAIN … 35-FB_BODIES + INDEX.md）
│   ├─ st/                       从工程文件提取的 **ST 块真实源码**（STB76…STB128）
│   ├─ text/                     工程表/程序 → UTF-8 文本（*.csv.txt、*.strings.txt）
│   ├─ dive/                     六个专题的原始深入稿件
│   └─ definitions/symbols.csv|json   **6009 个符号 → 绝对地址/位长/注释**（上位机对接用）
│
└─ tools/                        ← 复现脚本（全链路可重跑）
    ├─ dump_strings.py           二进制工程文件 → 可打印串（含中文注释）
    ├─ split_il.py               il_log.log → 按程序切分
    ├─ export_symbols.py         符号地址字典
    ├─ il2c.py                   IL → C（逐指令）
    ├─ st2c.py                   ST → C（逐行，保留原文注释）
    └─ il2c_project.py           生成完整 C 工程（类型推断/FB 绑定/实例/扫描调度/仿真侧）
```

## 2. 这是什么设备（速览）

| 项 | 内容 |
|---|---|
| PLC | 汇川 **H5U 系列**（AutoShop，EtherCAT 主站），PLC IP `192.168.1.88` |
| EtherCAT 从站 | 1× 汇川 **InoSV630N 伺服**（下料Y轴）+ 5× **SMC JXCE1 电缸**（FL左X/Y/Z、FL右Y/Z）+ 10× GL20 远程 IO（160 DI / 160 DO） |
| 机器人 | FANUC **R-30iB Plus ×2**，EtherNet/IP（`.60/.61`）+ GL20 硬线任务号 |
| 上位机 | PC 视觉（AOI1/AOI2）+ 产线系统 ACF：请求/应答码 `10/20/30`；另有 OPC UA(4840)、SFTP、扫码枪 TCP(:2001)、8 路压力 Modbus |
| 气动 | **36 个气缸**、4 组真空、10 条皮带、10 个电缸（5 台总线 + 5 台并行 IO 点位码） |
| 程序规模 | 36 个梯形图程序（MAIN + 35 子程序）、23 个功能块（12 在用 / 11 库存）、6009 个符号 |

## 2.5 本机存放位置（2026-09-24 起）

| 内容 | 位置 |
|---|---|
| **本仓库**（分析文档 + 工程 + 派生数据） | `D:\Obsidian Vault\PLC\Z25844 EPD模组FPC插接组装线\inovance-h5u-plc-analysis` |
| 分析工作区（含解压出的厂商资料 1.2 GB，仅供本地查阅） | `D:\Obsidian Vault\PLC\Z25844 EPD模组FPC插接组装线\分析工作区` |
| 分析文档快照（与 `analysis/` 相同） | `D:\Obsidian Vault\PLC\Z25844 EPD模组FPC插接组装线\分析手册` |
| 原始压缩包（未改动，709 MB） | `E:\Desktop\Inovance Control.zip` |

> 说明：`analysis/` 与 `artifacts/` 下的文档中，指令表引用统一写作 `artifacts/il/…`（如 `artifacts/il/30-SBR_电缸控制.il.txt`）、
> 文本导出写作 `artifacts/text/…`，都是**仓库内相对路径**，克隆后可直接打开。
> 若要看未入库的厂商资料（AutoShop 安装目录、官方手册），去同级的 `分析工作区\Inovance Control\`。

## 3. 怎么用

- **零基础**：`analysis/08-PLC入门与四周学习路线.md` → 再按 `01 → 02 → 07 → 03/04/05/06` 阅读
- **上位机对接**：`analysis/03` + `artifacts/definitions/symbols.csv`（用符号名而不要硬编码地址）
- **现场排故**：`analysis/02`（报警体系）、`analysis/04`（气缸不动怎么办）、`analysis/09`（点位表）
- **打开工程**：AutoShop → 打开 `project/临时工程/临时工程.hcp`（或指向该目录）

## 4. 重要说明（请先读）

1. **本仓库不含汇川厂商软件与手册**（AutoShop 安装程序、PDF/CHM 手册约 1.2 GB）——属第三方商业软件版权范围，且无法通过 GitHub 体积限制，故排除。详见 `NOTICE.md`。
2. **已排除口令文件** `LoginPassowrd.dat`（工程/HMI 登录口令），未入库以免凭据进入 git 历史。
3. `project/UpLoad/` 与 `project/临时工程/` **不是同一版本**（编译 2026-07-04 / 上传 2026-09-08），分析以 `临时工程` 为主、两者 IO 表已合并。
4. 工程内个别程序块（`SBR_电缸控制` 等的上传副本、`设备状态.FB`）是**厂商 know-how 保护**的加密块；分析以编译后指令表 `il_log.log` 为准。
5. 机台程序与符号命名可能涉及**设备厂商/客户**的商业信息，请勿将本仓库转为公开（public）或外发。

## 5. 分析是怎么做的（可复现）

1. 解压厂商资料包，识别出两套工程副本（上传版 / 工作版）；
2. `tools/dump_strings.py`：把 AutoShop 二进制工程文件里的可打印串（含中文注释、FB 引脚注释）导出为文本；
3. `tools/split_il.py`：把编译输出 `il_log.log`（17862 条指令）按程序与 FB 切分，并按符号签名自动命名；
4. 交叉验证：IL ⇄ `.LD` 源码注释 ⇄ `VarNameAndAddr.csv` ⇄ `.gvt` 变量表 ⇄ `CrossTable.crs` 交叉引用；
5. `tools/export_symbols.py`：导出符号地址字典。

**已知修正**：本工程 `TONR/TON` 的时间单位是 **1 ms**（`K2000`=复位保持 2 s、`K120000`=回原超时 120 s 佐证），
`.LD` 里定时器元素后的 `0.02` 是 AutoShop 元素属性，不是时间基准。
